<?php include 'inc/header.php'; ?>

<div class="page-area">
  <div class="breadcumb-overlay"></div>
  <div class="container">
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="breadcrumb">
          <div class="bread-inner">
            <div class="section-headline white-headline">
              <h2>Australia Point  <span class="color"> System</span></h2>
            </div>
            <ul class="breadcrumb-bg">
              <li class="home-bread"><a href="index.php">Home</a></li>
              <li>Australia Point System</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="team-area bg-color pd-35">
  <div class="container">
    <!-- section head -->
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="section-headline text-center">
          <h3>Australia Point  <span class="color"> System</span></h3>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-8 col-sm-8 col-xs-12" style="box-shadow: 5px 3px 10px rgb(0 0 0 / 10%);">
        <div class='text-justify innerpage-text'>
          <h2>Australia Permanent Residency (PR) Points System&nbsp;for&nbsp;189/190/491</h2>
          <p>The myriad Australia immigration Programs have been conceptualised to strategically select only the most qualified applicants. Certain filters have been designed to ensure that only desirable profiles that can significantly contribute to the economy are invited to pursue the <strong><a href="../australia-visa.html" target="_blank">Australia PR Process</a></strong>. One such tool is the Australia points calculator, which allocates points to the candidate based on several factors to determine their potential. This tool is also useful for immigration aspirants to estimate their ability to fulfil the <strong><a href="../australia/Australian-Immigration-Requirements-2.html" target="_blank">Australia PR requirements</a></strong>. Candidates who can score 65 or more Australia PR points may lodge their application in SkillSelect &ndash; the Australian government portal that determines eligibility of applicants.&nbsp;<br />
            &nbsp;</p>
          <p><strong>Points-tested Visa Categories</strong><br />
            <br />
            There are four visa subclasses that evaluate the eligibility of applicants based on the <strong><a href="check-your-eligibility-for-australia.html" target="_blank">Australia PR Points Calculator</a></strong>. Two of these points-tested visa categories are direct pathways to permanent residency Australia, while two are provisional visas which can eventually lead to securing Australia PR.</p>
          <ul>
            <li><strong><a href="australia-business-innovation-investment-provisional-subclass-188-visa.html" target="_blank">Business Innovation and Investment (Provisional) Visa (Subclass 188)</a></strong></li>
            <li><strong><a href="australia-skilled-independent-sub-class-189-immigration-visa.html" target="_blank">Skilled Independent visa (Subclass 189)</a></strong></li>
            <li><strong><a href="australia-skilled-nominated-subclass-190-immigration-visa.html" target="_blank">Skilled Nominated Visa (Subclass 190)</a></strong></li>
            <li><a href="skilled-work-regional-provisional-visa-491.html" target="_blank"><strong>Skilled Work Regional (Provisional) visa (Subclass 491)</strong></a></li>
          </ul>
          <p><img alt="Australia PR Points Calculator System" src="img/31102018Australia%20PR%20Point%20System.webp" style="width: 100%; height: 350px;" title="Australia PR Points Calculator System" /></p>
          <p><br />
            <a href="check-your-eligibility-for-australia.html" style="color: rgb(255, 255, 255); padding: 7px 5px; line-height: 24px; border-radius: 5px; margin-bottom: 6px; width: 140px; background: rgb(255, 0, 0) !important;" target="_blank" title="Check Your Eligibility">Check Your Eligibility</a></p>
          <p><br />
            <strong>Selection Factors of the Australia Point System</strong><br />
            <br />
            The criteria under each points-tested visa subclass is distinct, designed specifically to assess the aspirant&rsquo;s ability to fulfil the purpose for which they are being granted a visa. Under each stream, points are granted based on targeted parameters which determine the potential of an applicant to contribute to the local and national economy.&nbsp;The assessment criteria and minimum requirements of the point system are detailed below:</p>
          <h3>Australia Permanent Residency Points Table:</h3>
          <table border="1" bordercolor="#0099ff" cellpadding="5" cellspacing="0" height="100%" width="90%">
            <tbody>
              <tr bgcolor="#F00" style="color:#FFF">
                <td valign="top" width="30%"><strong>Factor</strong></td>
                <td valign="top" width="56%"><strong>Description</strong></td>
                <td valign="top" width="14%"><strong>Points</strong></td>
              </tr>
              <tr>
                <td rowspan="5" valign="top"><strong>Age:</strong></td>
                <td valign="top">18-24</td>
                <td valign="top">25 points</td>
              </tr>
              <tr>
                <td valign="top">25-32</td>
                <td valign="top">30 points</td>
              </tr>
              <tr>
                <td valign="top">33-39</td>
                <td valign="top">25 points</td>
              </tr>
              <tr>
                <td valign="top">40-44</td>
                <td valign="top">15 points</td>
              </tr>
              <tr>
                <td valign="top">45-49</td>
                <td valign="top">0 points</td>
              </tr>
              <tr>
                <td rowspan="3" valign="top"><strong>English Language:</strong></td>
                <td valign="top"><strong>Competent English - </strong>IELTS 6 in each<br />
                  <strong>TOEFL iBT </strong>Listening &ndash; 12, Reading &ndash; 13, Writing &ndash; 21 and Speaking &ndash; 18<br />
                  <strong>PTE Academic</strong> -&nbsp; Listening &ndash; 50, Reading &ndash; 50, Writing &ndash; 50 and Speaking &ndash; 50</td>
                <td valign="top">0 points</td>
              </tr>
              <tr>
                <td valign="top"><strong>Proficient English - </strong>IELTS 7 in each<br />
                  <strong>TOEFL iBT</strong> Listening &ndash; 24, Reading &ndash; 24, Writing &ndash; 27 and Speaking &ndash; 23<br />
                  <strong>PTE Academic </strong>-&nbsp; Listening &ndash; 65, Reading &ndash; 65, Writing &ndash; 65 and Speaking &ndash; 65</td>
                <td valign="top">10 points</td>
              </tr>
              <tr>
                <td valign="top"><strong>Superior English - </strong>IELTS 8 in each<br />
                  <strong>TOEFL iBT Listening </strong>&ndash; 28, Reading &ndash; 29, Writing &ndash; 30 and Speaking &ndash; 26<br />
                  <strong>PTE Academic</strong> -&nbsp; Listening &ndash; 79, Reading &ndash; 79, Writing &ndash; 79 and Speaking &ndash; 79</td>
                <td valign="top">20 points</td>
              </tr>
              <tr>
                <td rowspan="3" valign="top"><strong>Australian Work Experience</strong> in nominated occupation or a closely related occupation</td>
                <td valign="top">One year Australian (of past two years)</td>
                <td valign="top">5 points</td>
              </tr>
              <tr>
                <td valign="top">Three years Australian (of past five years)</td>
                <td valign="top">10 points</td>
              </tr>
              <tr>
                <td valign="top">Five years Australian (of past seven years)</td>
                <td valign="top">15 points</td>
              </tr>
              <tr>
                <td rowspan="3" valign="top"><strong>Overseas Work Experience</strong> in nominated occupation or a closely related occupation</td>
                <td valign="top">Three years overseas (of past five years)</td>
                <td valign="top">5 points</td>
              </tr>
              <tr>
                <td valign="top">Five years overseas (of past seven years)</td>
                <td valign="top">10 points</td>
              </tr>
              <tr>
                <td valign="top">Eight years overseas (of past 10 years)</td>
                <td valign="top">15 points</td>
              </tr>
              <tr>
                <td rowspan="3" valign="top"><strong>Qualifications</strong><br />
                  (Australian or recognised overseas)</td>
                <td valign="top">Offshore recognised apprenticeship<br />
                  AQFIII/IV completed in Australia<br />
                  Diploma completed in Australia</td>
                <td valign="top">10 points</td>
              </tr>
              <tr>
                <td valign="top">Bachelor Degree (including a Bachelor degree with Honours or Masters)</td>
                <td valign="top">15 points</td>
              </tr>
              <tr>
                <td valign="top">Ph.D</td>
                <td valign="top">20 points</td>
              </tr>
              <tr>
                <td valign="top"><strong>Recognition of Australian Study</strong></td>
                <td valign="top">Minimum two years fulltime (Australian study requirement)</td>
                <td valign="top">5 points</td>
              </tr>
              <tr>
                <td valign="top"><strong>Designated Language</strong></td>
                <td align="right" colspan="2" valign="top">5 points</td>
              </tr>
              <tr>
                <td valign="top"><strong>Partner Skills</strong></td>
                <td align="right" colspan="2" valign="top">5 points</td>
              </tr>
              <tr>
                <td valign="top"><strong>Professional Year</strong></td>
                <td align="right" colspan="2" valign="top">5 points</td>
              </tr>
              <tr>
                <td valign="top"><strong>Sponsorship by State or Territory Government</strong></td>
                <td align="right" colspan="2" valign="top">5 points</td>
              </tr>
              <tr>
                <td valign="top"><strong>Sponsorship by Family or State or Territory Government to Regional Australia</strong></td>
                <td align="right" colspan="2" valign="top">10 points</td>
              </tr>
              <tr>
                <td valign="top"><strong>Study in a Regional Area</strong></td>
                <td align="right" colspan="2" valign="top">5 points</td>
              </tr>
            </tbody>
          </table>
          <p>&nbsp;</p>
          <p><strong><u>Australia Points System Changes </u></strong></p>
          <p>With effect from 16<sup>th</sup> Nov 2019, the Points System for Australian General Skilled Migration Visas (Subclass 189 visa, Subclass 190 visa and Subclass 491 visa) experienced certain changes. Below are the changes:</p>
          <ul>
            <li><strong>Specialist education qualification</strong>: Candidates with Master&rsquo;s Degree by research / Doctorate degree from an Australian educational institution, can obtain <strong>10 points</strong> now. Earlier, it was <strong>5 points</strong>.</li>
            <li><strong>Partner skills: </strong>Candidates having skilled spouse under the age of 45 can acquire two set of points:
              <ul>
                <li><strong><em>Spouse Language &amp; Skill Assessment: </em></strong><em>If you spouse competent is having competent language skills and positive skill assessment along with his/her occupation falling under Skilled Occupation List (SOL), can get <strong>10 points</strong>. Earlier, it was <strong>5 points</strong>.</em></li>
                <li><strong><em>Spouse language proficiency:</em></strong><em> If your spouse or de facto partner is having competent language skills, then you can get additional <strong>5 points</strong>.</em></li>
              </ul>
            </li>
            <li><strong>Spouse Adaptability</strong><strong>:</strong> There is two-fold points change in the Spouse Adaptability:
              <ul>
                <li><em>If you are single, then you are entitled for <strong>additional 10 points. </strong>Earlier, there were <strong>no points </strong>for single applicant.</em></li>
                <li><em>If you have a spouse or de facto partner with either Australian citizenship or Australia permanent residency, then you are entitled for <strong>additional 10 points</strong>. Earlier, there were <strong>no points </strong>for Australian Citizen or PR Spouse.</em></li>
              </ul>
            </li>
            <li><strong>State Nomination/Sponsorship:</strong> If you obtain nomination by a state/territory or sponsorship by a family member, you can get <strong>15 points</strong>. Earlier, it was <strong>10 points.</strong> Currently, the 15 points criteria are applicable to Subclass 491 visa and Subclass 190 visa only.<br />
              &nbsp;</li>
          </ul>
          <p><strong><u>Australia Permanent Residency Points Table Changes:</u></strong></p>
          <p>&nbsp;</p>
          <table border="1" bordercolor="#0099ff" cellpadding="5" cellspacing="0" height="100%" width="90%">
            <tbody>
              <tr bgcolor="#F00" style="color:#FFF">
                <td style="width:396px;"><p><strong>Particulars</strong></p></td>
                <td style="width:120px;"><p align="center"><strong>Previous Points</strong></p></td>
                <td style="width:108px;"><p align="center"><strong>New Points</strong></p></td>
              </tr>
              <tr>
                <td style="width:396px;"><p><strong>Specialist education qualification</strong></p></td>
                <td style="width:120px;"><p align="center">5</p></td>
                <td style="width:108px;"><p align="center">10</p></td>
              </tr>
              <tr>
                <td style="width:396px;height:20px;"><p><strong>Spouse with Competent Language &amp; Positive Skill Assessment</strong></p></td>
                <td style="width:120px;height:20px;"><p align="center">0</p></td>
                <td style="width:108px;height:20px;"><p align="center">10</p></td>
              </tr>
              <tr>
                <td style="width:396px;height:20px;"><p><strong>Spouse with Competent Language only</strong></p></td>
                <td style="width:120px;height:20px;"><p align="center">0</p></td>
                <td style="width:108px;height:20px;"><p align="center">10</p></td>
              </tr>
              <tr>
                <td style="width:396px;height:19px;"><p><strong>Single Applicant</strong></p></td>
                <td style="width:120px;height:19px;"><p align="center">0</p></td>
                <td style="width:108px;height:19px;"><p align="center">10</p></td>
              </tr>
              <tr>
                <td style="width:396px;height:19px;"><p><strong>Spouse with Australian Citizenship &amp; PR</strong></p></td>
                <td style="width:120px;height:19px;"><p align="center">0</p></td>
                <td style="width:108px;height:19px;"><p align="center">10</p></td>
              </tr>
              <tr>
                <td style="width:396px;height:19px;"><p><strong>State Nomination</strong></p></td>
                <td style="width:120px;height:19px;"><p align="center">10</p></td>
                <td style="width:108px;height:19px;"><p align="center">15</p></td>
              </tr>
            </tbody>
          </table>
          <p><br />
            It is important to note that the point system is merely one of the many <strong><a href="../australia-immigration.html" target="_blank">Australia immigration</a></strong> requirements that must be satisfied. Obtaining an Australian visa for Indians can open the doors to a wide array of opportunities. After ensuring that all conditions can be fulfilled, the aspirant can file an application via SkillSelect. Upon due review of the application, the candidate may be invited to apply for the relevant visa subclass. Ascertaining the point score is the first step towards securing a positive outcome in the pursuit of immigration.<br />
            &nbsp;</p>
        </div>
      </div>
      <div class="col-md-4 col-sm-4 col-xs-12">
        <?php include('enquiry-form.php')?>
      </div>
    </div>
  </div>
</div>
</div>
</div>
<?php include 'inc/footer.php'; ?>
