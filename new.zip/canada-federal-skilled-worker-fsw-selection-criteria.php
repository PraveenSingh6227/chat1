<?php include 'inc/header.php'; ?>
<div class="page-area">
    <div class="breadcumb-overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="breadcrumb">
                    <div class="bread-inner">
                        <div class="section-headline white-headline">
                            <h2>Canada PR Visa Application  <span class="color"> Process and Processing Time</span></h2>
                        </div>
                        <ul class="breadcrumb-bg">
                            <li class="home-bread"><a href="index.php">Home</a></li>
                            <li>Canada PR Visa Application Process and Processing Time</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="team-area bg-color pd-35">
    <div class="container">
        <!-- section head -->
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-headline text-center">
                    <h3>Canada PR Visa Application  <span class="color"> Process and Processing Time</span></h3>
                </div>
            </div>
        </div>
        <div class="row">
		 <div class="col-md-8 col-sm-8 col-xs-12" style="box-shadow: 5px 3px 10px rgb(0 0 0 / 10%);">
<div class='text-justify innerpage-text'><p><strong>Citizenship and Immigration Canada</strong> has officially announced that it will start accepting applications under the <a href="canada-express-entry.html" target="_blank"><u>Express Entry Program for Skilled Professionals</u></a> interested in migrating to Canada, starting from January 1st, 2015. Candidates whose applications are picked up from Express Entry Pool must also meet the requirements of selection criteria under the federal skilled worker program in which he filing the application. One can file under one of the three programs:<br />
&nbsp;</p>
<ul>
<li>Federal Skilled Worker Class</li>
<li>Federal Skilled Trades Class</li>
<li>Canadian Experience Class</li>
</ul>
<p><br />
Remember this selection criteria is applicable AFTER the candidates application has been successfully picked up from the express entry pool. It is also true that unless the candidate does not meet FSW selection criteria, an invite to apply will NOT be issued to the Candidate. Please do not confuse the selection criteria and pass-mark under the FSW with point system under <u><a href="express-entry-comprehensive-ranking-system-criteria.html" target="_blank">Comprehensive Ranking System (CRS)</a></u>&nbsp;- Express Entry points Criteria. Purpose of CRS and points mentioned therein is limited to ranking the candidate against other prospective migrants and choosing the best possible suited to.<br />
<br />
<a href="authorized-representative-canada.html" style="padding:7px 5px ;background: #f00 !important; color: #fff; line-height: 24px; border-radius: 5px; margin-bottom: 6px;  width: 140px;" target="_blank" title="Our Canada RCIC Agent">Our Canada RCIC Agent</a><br />
<br />
Here is the applicable point system and related selection Criteria which candidates chosen from the Express Entry Pool MUST meet:<br />
<br />
<strong><u>Language - Principal Applicant (Maximum 28 Points)</u></strong><br />
<br />
Out of the possible 28 points, one can claim up-to 24 points under English language factor and remaining 4 points under French Language factor. This is under a situation where the applicant is filing the application with English as the first language. Applicants with high level (proven by high IELTS band score) of English language proficiency can claim all the 24 points.</p>
<ul>
<li>An applicant must prove a minimum proficiency in each of the four language abilities, speaking, listening, reading and writing - Canadian Language Benchmark 7 (CLB 7) level for English in order to qualify for the Federal Skilled Worker Class (FSWC) program.</li>
<li>For the English language requirement, <strong>CLB 7 is equivalent to scoring 6 bands in each of the 4 abilities on the IELTS</strong> GENERAL pattern examination.</li>
<li>For the French language requirement, NCLC 7 is equivalent to scoring 309, 248, 206 and 309 on the speaking, listening, reading and writing modules of the Test d&#39;evaluation de francais (TEF), respectively.</li>
<li>4 points are awarded for each of the four language abilities, meaning that all candidates that meet the mandatory minimums on all language abilities will have at least 16 points.</li>
<li>Applicants will be awarded one extra point foreach language ability for which they score CLB 8 or NCLC 8 and two extra points if they score CLB 9 or NCLC 9 (for a maximum of 24 points under English language factor).</li>
<li>The IELTS equivalent to CLB 8 is 7.5, 6.5, 6.5 and 6.5 on Listening, Reading, Writing, and Speaking. The TEF equivalent to NCLC 8 is 280-297, 233-247, 349-370 and 349-370 on Listening, Reading, Writing, and Speaking, respectively. Getting these scores will mean that 5 points are awarded for each of the four language abilities, meaning that all candidates that meet these criteria can claim a maximum of 20 points.</li>
<li>The IELTS equivalent to CLB 9 is 8.0, 7.0 , 7.0 , and 7.0 on Listening, Reading, Writing, and Speaking. The TEF equivalent to NCLC 9 is 298-315, 248-262, 371-392 and 371-392 on Listening, Reading, Writing, and Speaking, respectively. This means that to claim 24 points under the English language factor, the applicant MUST claim AT LEAST 8.0, 7.0, 7.0, and 7.0 on Listening, Reading, Writing, and Speaking, respectively. 6 points are awarded for each of the four language abilities, meaning that all candidates that meet these criteria can claim a maximum of 24 points.</li>
</ul>
<p><br />
One can also have various combinations of scores and accordingly credit points under the factor. Just remember that the MINIMUM requirement of at least 6.0 should be met to qualify.<br />
<br />
With specific reference to <strong><u>Comprehensive Ranking System (CRS)</u></strong> under Express Entry points program, it will make sense for both the spouses to appear in the IELTS test and provide score sheets. Higher the score in the ranking for both the spouses, more then number of points under CRS and higher will the application move into the overall rankings.<br />
<br />
<strong>Examples:</strong></p>
<table border="1" cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td style="width:56px;">
<p style="text-align: center;"><strong>Listening</strong></p>
</td>
<td style="width:56px;">
<p style="text-align: center;"><strong>Reading</strong></p>
</td>
<td style="width:56px;">
<p style="text-align: center;"><strong>Writing</strong></p>
</td>
<td style="width:56px;">
<p style="text-align: center;">&nbsp;<strong>Speaking</strong></p>
</td>
<td style="width:56px;">
<p style="text-align: center;">&nbsp;<strong>Total Points</strong></p>
</td>
</tr>
<tr>
<td>
<p style="text-align: center;">8.0</p>
</td>
<td>
<p style="text-align: center;">7.0</p>
</td>
<td>
<p style="text-align: center;">7.0</p>
</td>
<td>
<p style="text-align: center;">7.0</p>
</td>
<td>
<p style="text-align: center;">24 points</p>
</td>
</tr>
<tr>
<td>
<p style="text-align: center;">7.5</p>
</td>
<td>
<p style="text-align: center;">6.5</p>
</td>
<td>
<p style="text-align: center;">6.5</p>
</td>
<td>
<p style="text-align: center;">6.5</p>
</td>
<td>
<p style="text-align: center;">20 points</p>
</td>
</tr>
<tr>
<td>
<p style="text-align: center;">6.0</p>
</td>
<td> 
<p style="text-align: center;">6.0</p>
</td>
<td>
<p style="text-align: center;">6.0</p>
</td>
<td>
<p style="text-align: center;">6.0</p>
</td>
<td>
<p style="text-align: center;">16 points</p>
</td>
</tr>
<tr>
<td>
<p style="text-align: center;">8.0</p>
</td>
<td>
<p style="text-align: center;">6.5</p>
</td>
<td>
<p style="text-align: center;">7.0</p>
</td>
<td>
<p style="text-align: center;">6.5</p>
</td>
<td>
<p style="text-align: center;">22 points</p>
</td>
</tr>
<tr>
<td>
<p style="text-align: center;">7.5</p>
</td>
<td>
<p style="text-align: center;">7.0</p>
</td>
<td>
<p style="text-align: center;">7.0</p>
</td>
<td>
<p style="text-align: center;">7.0</p>
</td>
<td>
<p style="text-align: center;">23 points</p>
</td>
</tr>
<tr>
<td>
<p style="text-align: center;">8.0</p>
</td>
<td>
<p style="text-align: center;">7.0</p>
</td>
<td>
<p style="text-align: center;">6.0</p>
</td>
<td>
<p style="text-align: center;">6.0</p>
</td>
<td>
<p style="text-align: center;">20 points</p>
</td>
</tr>
</tbody>
</table>
<p><br />
<strong><u>Second Official Language:</u></strong><br />
<br />
The number of points awarded for proficiency in a second official language will be reduced from 8 to 4, making focusing on studying a single language a more viable strategy for those seeking to qualify for immigration to Canada. Our understanding is that in almost all instances, French will be the second official language.<br />
<br />
<strong><u>Age - Principal Applicant (Maximum 12 Points)</u></strong><br />
<br />
The preferential age will be redefined from 18 to 35 bands under the recommended point&#39;s criteria, which will be allotted a maximum of 12 points. An applicant above 47 years and getting Zero points for age can still file a petition, if he/she meets the minimum pass-mark requirements of 67 under other selection factors.</p>
<ul>
<li>18 to 35 years - 12 points</li>
</ul>
<p>After this age band, points are deducted on basis of age in years</p>
<ul>
<li>36 years - 11 points</li>
<li>Age 37 years - 10 points</li>
<li>Age 38 years - 9 points</li>
<li>And so on till&nbsp;Age 46 years - 1 point</li>
<li>47 and above - 0 points&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</li>
</ul>
<p><br />
<strong>Points for Employment Experience (Maximum 15 Points)</strong><br />
<br />
Score allocation</p>
<ul>
<li>1 year - 9 points</li>
<li>2-3 years - 11 points</li>
<li>4-5 years - 13 points</li>
<li>6 years - 15 points</li>
</ul>
<p>Above allocation indicates the following:</p>
<ul>
<li>Minimum experience of at least a year, in an occupation on O, A and B category is a MUST. To review the list of occupations that fall under these 3 categories,</li>
<li>Higher the experience, more points the principal applicant can claim under the employment experience factor.</li>
<li>Clearly outlining ones experience profile - as per NOC descriptions - in one of the permitted occupations under O, A and B category will determine whether or not an application under Canada FSW will be accepted or not. Hence taking an experienced immigration consultants&#39; help will be useful for your all important life objective to immigrate to Canada. For a free of charge assessment, you can also simply send across your and (if applicable), the spousal resume to <u><a href="../cdn-cgi/l/email-protection.html" class="__cf_email__" data-cfemail="3f485a5d7f5e5d5756515e49115c5052">[email&#160;protected]</a></u> for immediate contact from our business executives.</li>
</ul>
<p><br />
<strong>Educational and Professional Qualifications (Maximum 25 Points)</strong><br />
<br />
Under ECA (Educational Credential assessment), current educational and professional qualifications of the principal applicant will be assessed by a Canadian credential assessment agency. Such an assessment will confirm the equivalency of the principal applicant&#39;s qualifications with similar Canadian qualifications.&nbsp; Only the principal applicants getting positive assessment of their educational and professional qualifications will be permitted to file the application for permanent resident visa under federal skilled worker category.<br />
<br />
The credential assessment has therefore, become single most important step in achieving ones&#39; dreams to immigrate to Canada as a skilled professional. Just like Australia, a professional presentation of one&#39;s&#39; academic, professional and related experience credentials will therefore become very important for anybody who wishes to file for a permanent resident visa application under federal skilled worker category. Taking help of a professional in meeting this requirement has thus become very important. For a free of charge assessment, you can also simply send across your and (if applicable), the spousal resume to <u><a href="../cdn-cgi/l/email-protection.html#97e0f2f5d7f6f5fffef9f6e1b9f4f8fa"><span class="__cf_email__" data-cfemail="7c0b191e3c1d1e1415121d0a521f1311">[email&#160;protected]</span></a></u> for immediate contact from our business executives.<br />
&nbsp;</p>
<table border="1" cellpadding="0" cellspacing="0" style="width:750px;">
<tbody>
<tr>
<td style="width:680px;">Doctoral level</td>
<td style="width:66px;">25 points</td>
</tr>
<tr>
<td style="width:680px;">Master&#39;s level or professional degree</td>
<td style="width:66px;">23 points</td>
</tr>
<tr>
<td style="width:680px;">Two or more post-secondary credentials, one of which is a three-year or longer post-secondary credential</td>
<td style="width:66px;">22 points</td>
</tr>
<tr>
<td style="width:680px;">Three-year or longer post-secondary credential</td>
<td style="width:66px;">21 points</td>
</tr>
<tr>
<td style="width:680px;">Two-year post-secondary credential</td>
<td style="width:66px;">19 points</td>
</tr>
<tr>
<td style="width:680px;">One-year post-secondary credential</td>
<td style="width:66px;">15 points</td>
</tr>
<tr>
<td style="width:680px;">Secondary school</td>
<td style="width:66px;">05 points</td>
</tr>
</tbody>
</table>
<p><br />
<strong>Arranged Employment (Maximum 10 Points)</strong><br />
<br />
After the implementation of the new procedural recommendations labor market opinion - LMO will be superseding Arranged Employment Opinion - AEO. Employers would need to apply to the HRSDC for an LMO. This will bring down events of fictitious job offers and promote credibility of the scheme, establish the validity of the job offers in light of labor pool goals, and offer escalated LMO procedure to employers having a strict adherence track record.<br />
<br />
<strong>Adaptability (Maximum 10 Points)</strong><br />
<br />
A maximum score of 10 could be allocated to a migrant with employment experience in Canada.<br />
<br />
Or Education in Canada can get up to 5 points,&nbsp;<br />
Or Education AND experience in Canada can get up to 10 points!<br />
Or&nbsp;Spousal education qualifications will no longer get any points but a spouse with CLB level 4 in English language can help the principal applicant 5 adaptability factor points! This also means that to claim bonus points for spouse; she will need to appear in the IELTS test.<br />
Or Even a blood relation in Canada can help the principal applicant gain additional 5 points under the adaptability factor. The blood relation can be 18 years and above; and can be Father, Mother, Brother, Sister, Uncle, Aunt, Niece, Nephew. The blood relation can belong to either of the spouses and either of the parents.<br />
<br />
<strong>Total marks are 100 and current pass-mark is 67 points. This selection criteria as well pass-mark may change without notice.</strong></p>
</div>
</div>
		 <div class="col-md-4 col-sm-4 col-xs-12">
		 <?php include('enquiry-form.php')?>
		 </div>
                
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>