<?php include 'inc/header.php'; ?>

<div class="page-area">
  <div class="breadcumb-overlay"></div>
  <div class="container">
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="breadcrumb">
          <div class="bread-inner">
            <div class="section-headline white-headline">
              <h2>Australian Capital Territory  <span class="color"> Occupation List</span></h2>
            </div>
            <ul class="breadcrumb-bg">
              <li class="home-bread"><a href="index.php">Home</a></li>
              <li>Australian Capital Territory Occupation List</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="team-area bg-color pd-35">
  <div class="container">
    <!-- section head -->
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="section-headline text-center">
          <h3>Australian Capital Territory  <span class="color"> Occupation List</span></h3>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-8 col-sm-8 col-xs-12" style="box-shadow: 5px 3px 10px rgb(0 0 0 / 10%);">
        <div class='text-justify innerpage-text'>
          <p><strong>An Overview Australian Capital Territory Occupation List</strong><br>
            <br>
            The Australia Capital Territory (ACT) Skilled Occupation List&nbsp;encompasses the occupations that have demand in Canberra to suffice the labour market needs. The occupation list predominantly grants the opportunity for the subclass 190 and subclass 489 candidates who want to apply for ACT state nomination. Eligibility for ACT can be checked for both skilled visas and employer nomination scheme. Australia Capital Territory (ACT) nomination gives the provision for the skilled workforce and business professionals to migrate to Canberra. Below are the pathways for the state nomination:<br>
            &nbsp;</p>
          <ul>
            <li><strong>Skilled Visas</strong> – Consisting of the ACT nomination of a <a href="australia-skilled-nominated-subclass-190-immigration-visa.html" target="_blank">skilled nominated subclass 190 visa</a> which is a permanent visa that allows an individual to live and work in Canberra.</li>
            <li><a href="australia-employer-nomination-scheme-subclass-186.html" target="_blank"><strong>Employer Nomination</strong></a> – Prospective Employer take the support of Regional Certifying Body to nominate skilled workers under the <a href="regional-sponsored-migration-scheme.html" target="_blank">Regional Sponsored Migration Scheme</a>.</li>
          </ul>
          <h2>Australian Capital Territory (ACT) Occupation List – 1<sup>st</sup>&nbsp;July 2019</h2>
          <table width="90%" height="100%" cellspacing="0" cellpadding="8" bordercolor="#CCC" border="1">
            <tbody>
              <tr style="color:#FFF" bgcolor="#F00">
                <td><strong>ANZSCO</strong></td>
                <td><strong>Occupation</strong></td>
                <td><strong>Status</strong></td>
              </tr>
              <tr>
                <td>131112</td>
                <td>Sales &amp; Marketing Manager</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>131113</td>
                <td>Advertising Manager</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>132511</td>
                <td>Research and development manager **</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>225311</td>
                <td>Public Relations Professional</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>232111</td>
                <td>Architect</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>232112</td>
                <td>Landscape Architect</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>232411</td>
                <td>Graphic Designer</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>232412</td>
                <td>Illustrator</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>232414</td>
                <td>Web Designer</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>232611</td>
                <td>Urban &amp; Regional Planner</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>233211</td>
                <td>Civil Engineer</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>233212</td>
                <td>Geotechnical Engineer</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>233213</td>
                <td>Quantity Surveyor</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>233214</td>
                <td>Structural Engineer</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>233911</td>
                <td>Aeronautical Engineer</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>233912</td>
                <td>Agricultural Engineer</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>233913</td>
                <td>Biomedical Engineer</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>233914</td>
                <td>Engineering Technologist</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>233915</td>
                <td>Environmental Engineer</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>233999</td>
                <td>Engineering Professionals nec</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>233916</td>
                <td>Naval Architect**</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>234111</td>
                <td>Agricultural Consultant**</td>
                <td valign="top">Open</td>
              </tr>
              <tr>
                <td>234112</td>
                <td>Agricultural Scientist**</td>
                <td valign="top">Open</td>
              </tr>
              <tr>
                <td>234211</td>
                <td>Chemist **</td>
                <td valign="top">Open</td>
              </tr>
              <tr>
                <td>234312</td>
                <td>Environmental Consultant **</td>
                <td valign="top">Open</td>
              </tr>
              <tr>
                <td>234313</td>
                <td>Environmental Research Scientist **</td>
                <td valign="top">Open</td>
              </tr>
              <tr>
                <td>234399</td>
                <td>Environmental Scientists nec **</td>
                <td valign="top">Open</td>
              </tr>
              <tr>
                <td>234411</td>
                <td>Geologist **</td>
                <td valign="top">Open</td>
              </tr>
              <tr>
                <td>234412</td>
                <td>Geophysicist **</td>
                <td valign="top">Open</td>
              </tr>
              <tr>
                <td>234413</td>
                <td>Hydrogeologist **</td>
                <td valign="top">Open</td>
              </tr>
              <tr>
                <td>234511</td>
                <td>Life Scientist (general) **</td>
                <td valign="top">Open</td>
              </tr>
              <tr>
                <td>234513</td>
                <td>Biochemist **</td>
                <td valign="top">Open</td>
              </tr>
              <tr>
                <td>234514</td>
                <td>Biotechnologist **</td>
                <td valign="top">Open</td>
              </tr>
              <tr>
                <td>234515</td>
                <td>Botanist**</td>
                <td valign="top">Open</td>
              </tr>
              <tr>
                <td>234516</td>
                <td>Marine Biologist**</td>
                <td valign="top">Open</td>
              </tr>
              <tr>
                <td>241111</td>
                <td>Early Childhood (Pre-Primary School) Teacher</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>242111</td>
                <td>University Lecturer ##</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>251211</td>
                <td>Medical Diagnostic Radiographer</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>251212</td>
                <td>Medical Radiation Therapist</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>251213</td>
                <td>Nuclear Medicine Technologist</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>251214</td>
                <td>Sonographer</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>251511</td>
                <td>Hospital Pharmacist ##</td>
                <td valign="top">Open</td>
              </tr>
              <tr>
                <td>251512</td>
                <td>Industrial Pharmacist ##</td>
                <td valign="top">Open</td>
              </tr>
              <tr>
                <td>251513</td>
                <td>Retail Pharmacist ##</td>
                <td valign="top">Open</td>
              </tr>
              <tr>
                <td>252411</td>
                <td>Occupational Therapist</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>252511</td>
                <td>Physiotherapist</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>252711</td>
                <td>Audiologist</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>252712</td>
                <td>Speech Pathologist</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>253111</td>
                <td>General Practitioner</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>253112</td>
                <td>Resident Medical Officer</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>254111</td>
                <td>Midwife</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>254311</td>
                <td>Nurse Manager</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>254411</td>
                <td>Nurse Practitioner</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>254412</td>
                <td>Registered Nurse (Aged Care)</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>254413</td>
                <td>Registered Nurse (Child &amp; Family Health)</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>254414</td>
                <td>Registered Nurse (Community Health)</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>254415</td>
                <td>Registered Nurse (Critical Care &amp; Emergency)</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>254416</td>
                <td>Registered Nurse (Developmental Disability)</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>254417</td>
                <td>Registered Nurse (Disability &amp; Rehabilitation)</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>254418</td>
                <td>Registered Nurse (Medical)</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>254421</td>
                <td>Registered Nurse (Medical Practice)</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>254422</td>
                <td>Registered Nurse (Mental Health)</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>254423</td>
                <td>Registered Nurse (Perioperative)</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>254424</td>
                <td>Registered Nurse (Surgical)</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>254425</td>
                <td>Registered Nurse (Paediatrics)</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>254499</td>
                <td>Registered Nurses (<em>nec</em>)</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>261111</td>
                <td>ICT Business Analyst **</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>261112</td>
                <td>Systems Analyst**</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>261211</td>
                <td>Multimedia Specialist</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>261212</td>
                <td>Web Developer</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>261311</td>
                <td>Analyst Programmer**</td>
                <td valign="top">Open</td>
              </tr>
              <tr>
                <td>261312</td>
                <td>Developer Programmer**</td>
                <td valign="top">Open</td>
              </tr>
              <tr>
                <td>261313</td>
                <td>Software Engineer**</td>
                <td valign="top">Open</td>
              </tr>
              <tr>
                <td>261314</td>
                <td>Software Tester**</td>
                <td valign="top">Open</td>
              </tr>
              <tr>
                <td>261399</td>
                <td>Software and Applications Programmers nec**</td>
                <td valign="top">Open</td>
              </tr>
              <tr>
                <td>262111</td>
                <td>Database Administrator**</td>
                <td valign="top">Open</td>
              </tr>
              <tr>
                <td>262112</td>
                <td>ICT Security Specialist**</td>
                <td valign="top">Open</td>
              </tr>
              <tr>
                <td>262113</td>
                <td>Systems Administrator**</td>
                <td valign="top">Open</td>
              </tr>
              <tr>
                <td>263111</td>
                <td>Computer Network &amp; Systems Engineer**</td>
                <td valign="top">Open</td>
              </tr>
              <tr>
                <td>263112</td>
                <td>Network Administrator**</td>
                <td valign="top">Open</td>
              </tr>
              <tr>
                <td>263113</td>
                <td>Network Analyst**</td>
                <td valign="top">Open</td>
              </tr>
              <tr>
                <td>263211</td>
                <td>ICT Quality Assurance Engineer**</td>
                <td valign="top">Open</td>
              </tr>
              <tr>
                <td>263212</td>
                <td>ICT Support Engineer**</td>
                <td valign="top">Open</td>
              </tr>
              <tr>
                <td>263213</td>
                <td>ICT Systems Test Engineer**</td>
                <td valign="top">Open</td>
              </tr>
              <tr>
                <td>263299</td>
                <td>ICT Support and Test Engineers (nec)**</td>
                <td valign="top">Open</td>
              </tr>
              <tr>
                <td>263311</td>
                <td>Telecommunications Engineer**</td>
                <td valign="top">Open</td>
              </tr>
              <tr>
                <td>272311</td>
                <td>Clinical Psychologist</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>272312</td>
                <td>Educational Psychologist</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>272313</td>
                <td>Organisational Psychologist</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>272314</td>
                <td>Psychotherapist</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>272399</td>
                <td>Psychologists (<em>nec</em>)</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>272511</td>
                <td>Social Worker</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>272612</td>
                <td>Recreation Officer</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>272613</td>
                <td>Welfare Worker</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>321211</td>
                <td>Motor Mechanic (General)</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>321212</td>
                <td>Diesel Motor Mechanic</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>321213</td>
                <td>Motorcycle Mechanic</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>321214</td>
                <td>Small Engine Mechanic</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>322311</td>
                <td>Metal Fabricator</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>322313</td>
                <td>Welder (First Class)</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>324111</td>
                <td>Panel beater</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>331111</td>
                <td>Bricklayer</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>331112</td>
                <td>Stonemason</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>332211</td>
                <td>Painting Trades Workers</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>333211</td>
                <td>Fibrous Plasterer</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>333212</td>
                <td>Solid Plasterer</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>334111</td>
                <td>Plumber (General) ^^</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>334112</td>
                <td>Aircon. &amp; Mechanical Services Plumber &nbsp;^^</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>334113</td>
                <td>Drainer &nbsp;^^</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>334114</td>
                <td>Gasfitter &nbsp;^^</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>334115</td>
                <td>Roof Plumber &nbsp;^^</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>341111</td>
                <td>Electrician (General) ^^</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>341112</td>
                <td>Electrician (Special Class) ^^</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>341113</td>
                <td>Lift Mechanic &nbsp;^^</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>342111</td>
                <td>Air-conditioning &amp; Refrigeration Mechanic &nbsp;^^</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>391111</td>
                <td>Hairdresser</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>394111</td>
                <td>Cabinetmaker</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>411411</td>
                <td>Enrolled Nurse</td>
                <td>Open</td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td><em>^^&nbsp; Registration or licencing is required </em></td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td>** <em>Employment Caveat. Minimum one year ACT employment contract (in the nominated occupation). The employment must be with a medium to large enterprise (50 plus employees) located in the ACT; or an academic appointment at an ACT tertiary institution.</em></td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>&nbsp;</td>
                <td><em>## Minimum one year employment contract with an ACT employer in the nominated occupation.</em></td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td colspan="3">If you wish to nominate an ‘open’ occupation but you cannot comply with a ‘caveat’, the occupation is deemed to be ‘closed’.</td>
              </tr>
            </tbody>
          </table>
          <table width="90%" height="100%" cellspacing="0" cellpadding="8" bordercolor="#CCC" border="1">
            <tbody>
              <tr style="color:#FFF" bgcolor="#F00">
                <td colspan="3" width="577" valign="bottom"><p align="center"><strong>CLOSED OCCUPATIONS</strong></p></td>
              </tr>
              <tr>
                <td valign="bottom"><p align="center"><strong>ANZSCO</strong></p></td>
                <td valign="bottom"><p><strong>Occupation</strong></p></td>
                <td valign="bottom"><p align="center"><strong>Status</strong></p></td>
              </tr>
              <tr>
                <td><p align="center">121212</p></td>
                <td><p>Flower Grower</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">121215</p></td>
                <td><p>Grape Grower</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">121221</p></td>
                <td><p>Vegetable Grower</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">121311</p></td>
                <td><p>Apiarist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">121321</p></td>
                <td><p>Poultry Farmer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">132111</p></td>
                <td><p>Corporate Services Manager</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">132211</p></td>
                <td><p>Finance Manager</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">132311</p></td>
                <td><p>Human Resource Manager</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">133111</p></td>
                <td><p>Construction Project Manager</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">133211</p></td>
                <td><p>Engineering Manager</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">133411</p></td>
                <td><p>Manufacturer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">133511</p></td>
                <td><p>Production Manager (Forestry)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">133512</p></td>
                <td><p>Production Manager (Manufacturing)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">133513</p></td>
                <td><p>Production Manager (Mining)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">133611</p></td>
                <td><p>Supply and Distribution Manager</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">134111</p></td>
                <td><p>Child Care Centre Manager</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">134212</p></td>
                <td><p>Nursing Clinical Director</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">134213</p></td>
                <td><p>Primary Health Organisation Manager</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">134214</p></td>
                <td><p>Welfare Centre Manager</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">134299</p></td>
                <td><p>Health &amp; Welfare Services Managers (<em>nec</em>)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">134311</p></td>
                <td><p>School Principal</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">134499</p></td>
                <td><p>Education Managers (<em>nec</em>)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">135112</p></td>
                <td><p>ICT Project Manager</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">135199</p></td>
                <td><p>ICT Managers (<em>nec</em>)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">139911</p></td>
                <td><p>Arts Administrator or Manager</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">139912</p></td>
                <td><p>Environmental Manager</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">139913</p></td>
                <td><p>Laboratory Manager</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">139914</p></td>
                <td><p>Quality Assurance Manager</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">139999</p></td>
                <td><p>Specialist Managers nec</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">141111</p></td>
                <td><p>Cafe or Restaurant Manager</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">141311</p></td>
                <td><p>Hotel or Motel Manager</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">141999</p></td>
                <td><p>Accommodation and Hospitality Managers nec</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">149212</p></td>
                <td><p>Customer Service Manager</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">149311</p></td>
                <td><p>Conference &amp; Event Organiser</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">149413</p></td>
                <td><p>Transport Company Manager</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">149913</p></td>
                <td><p>Facilities Manager</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">211112</p></td>
                <td><p>Dancer or Choreographer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">211212</p></td>
                <td><p>Music Director</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">211213</p></td>
                <td><p>Musician (Instrumental)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">211299</p></td>
                <td><p>Music Professionals (nec)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">211311</p></td>
                <td><p>Photographer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">212111</p></td>
                <td><p>Artistic Director</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">212212</p></td>
                <td><p>Book or Script Editor</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">212312</p></td>
                <td><p>Director (Film, Television, Radio or Stage)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">212314</p></td>
                <td><p>Film &amp; Video Editor</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">212315</p></td>
                <td><p>Program Director (Television or Radio)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">212316</p></td>
                <td><p>Stage Manager</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">212317</p></td>
                <td><p>Technical Director</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">212318</p></td>
                <td><p>Video Producer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">212411</p></td>
                <td><p>Copywriter</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">212412</p></td>
                <td><p>Newspaper or Periodical Editor</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">212413</p></td>
                <td><p>Print Journalist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">212415</p></td>
                <td><p>Technical Writer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">212416</p></td>
                <td><p>Television Journalist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">212499</p></td>
                <td><p>Journalist &amp; other writers (nec)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">221111</p></td>
                <td><p>Accountant (General)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">221112</p></td>
                <td><p>Management Accountant</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">221113</p></td>
                <td><p>Taxation Accountant</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">221211</p></td>
                <td><p>Company Secretary</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">221213</p></td>
                <td><p>External Auditor</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">221214</p></td>
                <td><p>Internal Auditor</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">222111</p></td>
                <td><p>Commodities Trader</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">222112</p></td>
                <td><p>Finance Broker</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">222113</p></td>
                <td><p>Insurance Broker</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">222199</p></td>
                <td><p>Financial Brokers (<em>nec</em>)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">222211</p></td>
                <td><p>Financial Market Dealer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">222213</p></td>
                <td><p>Stockbroking Dealer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">222299</p></td>
                <td><p>Financial Dealers (<em>nec</em>)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">222311</p></td>
                <td><p>Financial Investment Adviser</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">222312</p></td>
                <td><p>Financial Investment Manager</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">223112</p></td>
                <td><p>Recruitment Consultant</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">223211</p></td>
                <td><p>ICT Trainer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">224111</p></td>
                <td><p>Actuary</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">224112</p></td>
                <td><p>Mathematician</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">224113</p></td>
                <td><p>Statistician</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">224212</p></td>
                <td><p>Gallery or Museum Curator</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">224213</p></td>
                <td><p>Health Information Manager</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">224214</p></td>
                <td><p>Records Manager</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">224311</p></td>
                <td><p>Economist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">224511</p></td>
                <td><p>Land Economist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">224512</p></td>
                <td><p>Valuer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">224611</p></td>
                <td><p>Librarian</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">224711</p></td>
                <td><p>Management Consultant</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">224712</p></td>
                <td><p>Organisation &amp; Methods Analyst</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">224914</p></td>
                <td><p>Patents Examiner</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">224999</p></td>
                <td><p>Information and Org. Professionals<em>&nbsp;(nec)</em></p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">225111</p></td>
                <td><p>Advertising Specialist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">225113</p></td>
                <td><p>Marketing Specialist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">225211</p></td>
                <td><p>ICT Account Manager</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">225212</p></td>
                <td><p>ICT Business Development Manager</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">225213</p></td>
                <td><p>ICT Sales Representative</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">225499</p></td>
                <td><p>Technical Sales Representatives (<em>nec)</em>&nbsp;</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">232212</p></td>
                <td><p>Surveyor</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">232213</p></td>
                <td><p>Cartographer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">232214</p></td>
                <td><p>Other Spatial Scientist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">232311</p></td>
                <td><p>Fashion Designer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">232312</p></td>
                <td><p>Industrial Designer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">232313</p></td>
                <td><p>Jewellery Designer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">232511</p></td>
                <td><p>Interior Designer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">233111</p></td>
                <td><p>Chemical Engineer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">233112</p></td>
                <td><p>Materials Engineer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">233215</p></td>
                <td><p>Transport Engineer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">233311</p></td>
                <td><p>Electrical Engineer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">233411</p></td>
                <td><p>Electronics Engineer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">233511</p></td>
                <td><p>Industrial Engineer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">233512</p></td>
                <td><p>Mechanical Engineer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">233513</p></td>
                <td><p>Production or plant engineer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">233611</p></td>
                <td><p>Mining Engineer (excluding Petroleum)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">233612</p></td>
                <td><p>Petroleum Engineer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">234113</p></td>
                <td><p>Forester</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">234711</p></td>
                <td><p>Veterinarian</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">234911</p></td>
                <td><p>Conservator</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">234912</p></td>
                <td><p>Metallurgist</p></td>
                <td valign="top"><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">234913</p></td>
                <td><p>Meteorologist</p></td>
                <td valign="top"><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">234914</p></td>
                <td><p>Physicist</p></td>
                <td valign="top"><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">234999</p></td>
                <td><p>Natural and Physical Science Professionals nec</p></td>
                <td valign="top"><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">241311</p></td>
                <td><p>Middle School Teacher</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">241411</p></td>
                <td><p>Secondary School Teacher</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">241213</p></td>
                <td><p>Primary School Teacher</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">241511</p></td>
                <td><p>Special Needs Teacher</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">241512</p></td>
                <td><p>Teacher of the Hearing Impaired</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">241513</p></td>
                <td><p>Teacher of the Sight Impaired</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">241599</p></td>
                <td><p>Special Education Teachers (<em>nec</em>)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">249111</p></td>
                <td><p>Education Adviser</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">249211</p></td>
                <td><p>Art Teacher (Private Tuition)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">249212</p></td>
                <td><p>Dance Teacher (Private Tuition)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">249214</p></td>
                <td><p>Music Teacher (Private Tuition)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">249299</p></td>
                <td><p>Private Tutors &amp; Teachers (<em>nec</em>)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">249311</p></td>
                <td><p>Teacher of English to speakers of other languages</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">251111</p></td>
                <td><p>Dietitian</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">251112</p></td>
                <td><p>Nutritionist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">251312</p></td>
                <td><p>Occupational Health and Safety Adviser</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">251411</p></td>
                <td><p>Optometrist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">251412</p></td>
                <td><p>Orthopist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">251911</p></td>
                <td><p>Health Promotion Officer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">251912</p></td>
                <td><p>Orthotist or Prosthetist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">251999</p></td>
                <td><p>Health Diagnostic &amp; Promotion Prof.</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">252111</p></td>
                <td><p>Chiropractor</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">252112</p></td>
                <td><p>Osteopath</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">252211</p></td>
                <td><p>Acupuncturist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">252213</p></td>
                <td><p>Naturopath</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">252214</p></td>
                <td><p>Traditional Chinese Medicine Practitioner</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">252299</p></td>
                <td><p>Complementary Health Therapists (<em>nec</em>)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">252311</p></td>
                <td><p>Dental Specialist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">252611</p></td>
                <td><p>Podiatrist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">253311</p></td>
                <td><p>Specialist Physician (General Medicine)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">253312</p></td>
                <td><p>Cardiologist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">253313</p></td>
                <td><p>Clinical Haematologist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">253314</p></td>
                <td><p>Medical Oncologist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">253315</p></td>
                <td><p>Endocrinologist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">253316</p></td>
                <td><p>Gastroenterologist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">253317</p></td>
                <td><p>Intensive Care Specialist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">253318</p></td>
                <td><p>Neurologist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">253321</p></td>
                <td><p>Paediatrician</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">253322</p></td>
                <td><p>Renal Medicine Specialist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">253323</p></td>
                <td><p>Rheumatologist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">253324</p></td>
                <td><p>Thoracic Medicine Specialist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">253399</p></td>
                <td><p>Specialist Physicians (<em>nec</em>)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">253411</p></td>
                <td><p>Psychiatrist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">253511</p></td>
                <td><p>Surgeon (General)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">253512</p></td>
                <td><p>Cardiothoracic Surgeon</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">253513</p></td>
                <td><p>Neurosurgeon</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">253514</p></td>
                <td><p>Orthopaedic Surgeon</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">253515</p></td>
                <td><p>Otorhinolaryngologist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">253516</p></td>
                <td><p>Paediatric Surgeon</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">253517</p></td>
                <td><p>Plastic &amp; Reconstructive Surgeon</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">253518</p></td>
                <td><p>Urologist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">253521</p></td>
                <td><p>Vascular Surgeon</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">253911</p></td>
                <td><p>Dermatologist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">253912</p></td>
                <td><p>Emergency Medicine Specialist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">253913</p></td>
                <td><p>Obstetrician &amp; Gynaecologist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">253914</p></td>
                <td><p>Ophthalmologist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">253915</p></td>
                <td><p>Pathologist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">253917</p></td>
                <td><p>Diagnostic &amp; Interventional Radiologist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">253918</p></td>
                <td><p>Radiation Oncologist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">253999</p></td>
                <td><p>Medical Practitioners (<em>nec</em>)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">254211</p></td>
                <td><p>Nurse Educator</p></td>
                <td valign="bottom"><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">254212</p></td>
                <td><p>Nurse Researcher</p></td>
                <td valign="bottom"><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">271111</p></td>
                <td><p>Barrister</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">271311</p></td>
                <td><p>Solicitor</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">271299</p></td>
                <td><p>Judicial &amp; Other Legal Professionals (<em>nec</em>)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">272111</p></td>
                <td><p>Careers Counsellor</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">272112</p></td>
                <td><p>Drug &amp; Alcohol Counsellor</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">272113</p></td>
                <td><p>Family &amp; Marriage Counsellor</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">272114</p></td>
                <td><p>Rehabilitation Counsellor</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">272115</p></td>
                <td><p>Student Counsellor</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">272199</p></td>
                <td><p>Counsellors (<em>nec</em>)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">272412</p></td>
                <td><p>Interpreter</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">272499</p></td>
                <td><p>Social Professionals (<em>nec</em>)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">311211</p></td>
                <td><p>Anaesthetic Technician</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">311212</p></td>
                <td><p>Cardiac Technician</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">311213</p></td>
                <td><p>Medical Laboratory Technician</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">311215</p></td>
                <td><p>Pharmacy Technician</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">311299</p></td>
                <td><p>Medical Technicians (<em>nec</em>)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">311312</p></td>
                <td><p>Meat Inspector</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">311399</p></td>
                <td><p>Primary Products Inspectors nec</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">311411</p></td>
                <td><p>Chemistry Technician</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">311412</p></td>
                <td><p>Earth Science Technician</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">311413</p></td>
                <td><p>Life Science Technician</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">311499</p></td>
                <td><p>Science Technicians (<em>nec</em>)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">312111</p></td>
                <td><p>Architectural Draftsperson</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">312113</p></td>
                <td><p>Building Inspector</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">312199</p></td>
                <td><p>Arch, Building &amp; Surveying Technicians (<em>nec</em>)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">312211</p></td>
                <td><p>Civil Engineering Draftsperson</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">312212</p></td>
                <td><p>Civil Engineering Technician</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">312311</p></td>
                <td><p>Electrical Engineering Draftsperson</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">312312</p></td>
                <td><p>Electrical Engineering Technician</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">312512</p></td>
                <td><p>Mechanical Engineering Technician</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">312912</p></td>
                <td><p>Metallurgical or Materials Technician</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">312913</p></td>
                <td><p>Mine Deputy</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">313111</p></td>
                <td><p>Hardware Technician</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">313112</p></td>
                <td><p>ICT Customer Support Officer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">313113</p></td>
                <td><p>Web Administrator</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">313199</p></td>
                <td><p>?ICT Support Technicians (nec)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">313211</p></td>
                <td><p>Radio Communications Technician</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">313212</p></td>
                <td><p>Telecommunications Field Engineer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">313213</p></td>
                <td><p>Telecommunications network planner</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">313214</p></td>
                <td><p>Tele. Technical Officer or Technologist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">321111</p></td>
                <td><p>Automotive Electrician</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">322113</p></td>
                <td><p>Farrier</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">322211</p></td>
                <td><p>Sheet metal Trades Worker</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">322312</p></td>
                <td><p>&nbsp;Pressure welder</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">323111</p></td>
                <td><p>Aircraft Maintenance Engineer (Avionics)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">323112</p></td>
                <td><p>Aircraft Maintenance Engineer (Mechanical)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">323113</p></td>
                <td><p>Aircraft Maintenance Engineer (Structures)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">323211</p></td>
                <td><p>Fitter (General)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">323212</p></td>
                <td><p>Fitter &amp; Turner</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">323213</p></td>
                <td><p>Fitter-Welder</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">323214</p></td>
                <td><p>Metal Machinist (First Class)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">323299</p></td>
                <td><p>Metal Fitters &amp; Machinists (<em>nec</em>)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">323313</p></td>
                <td><p>Locksmith</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">323314</p></td>
                <td><p>Precision Instrument Maker &amp; Repairer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">323412</p></td>
                <td><p>Toolmaker</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">324211</p></td>
                <td><p>Vehicle Body Builder</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">324212</p></td>
                <td><p>Vehicle Trimmer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">331211</p></td>
                <td><p>Carpenter &amp; Joiner</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">331212</p></td>
                <td><p>Carpenter</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">331213</p></td>
                <td><p>Joiner</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">333111</p></td>
                <td><p>Glazier</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">333311</p></td>
                <td><p>Roof Tiler</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">333411</p></td>
                <td><p>Wall &amp; Floor Tiler</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">342212</p></td>
                <td><p>Technical Cable Jointer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">342311</p></td>
                <td><p>Business Machine Mechanic</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">342313</p></td>
                <td><p>Electronic Equipment Trades Worker</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">342314</p></td>
                <td><p>Electronic Instrument Tr. Worker (General)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">342315</p></td>
                <td><p>Elect.&nbsp; Instr. Trades Worker (Special Class)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">342411</p></td>
                <td><p>Cabler (Data &amp; Telecommunications)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">342413</p></td>
                <td><p>Telecommunications Lines worker</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">351111</p></td>
                <td><p>Baker</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">351112</p></td>
                <td><p>Pastry cook</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">351211</p></td>
                <td><p>Butcher or Smallgoods Maker</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">351311</p></td>
                <td><p>Chef</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">351411</p></td>
                <td><p>Cook</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">361111</p></td>
                <td><p>Dog Handler or Trainer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">361112</p></td>
                <td><p>Horse Trainer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">361199</p></td>
                <td><p>Animal Attendants &amp; Trainers (<em>nec</em>)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">361311</p></td>
                <td><p>Veterinary Nurse</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">362111</p></td>
                <td><p>Florist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">362211</p></td>
                <td><p>Gardener (General)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">362212</p></td>
                <td><p>Arborist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">362213</p></td>
                <td><p>Landscape Gardener</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">362311</p></td>
                <td><p>Greenkeeper</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">392111</p></td>
                <td><p>Print Finisher</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">392311</p></td>
                <td><p>Printing Machinist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">393213</p></td>
                <td><p>Dressmaker or Tailor</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">393311</p></td>
                <td><p>Upholsterer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">394211</p></td>
                <td><p>Furniture Finisher</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">394213</p></td>
                <td><p>Wood Machinist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">394299</p></td>
                <td><p>Wood Machinists &amp; Other Wood Trades (<em>nec</em>)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">399111</p></td>
                <td><p>Boat Builder &amp; Repairer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">399112</p></td>
                <td><p>Shipwright</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">399213</p></td>
                <td><p>Power Generation Plant Operator</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">399411</p></td>
                <td><p>Jeweller</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">399512</p></td>
                <td><p>Camera Operator (Film, Television or Video)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">399514</p></td>
                <td><p>Make Up Artist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">399516</p></td>
                <td><p>Sound Technician</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">399599</p></td>
                <td><p>Performing Arts Technicians (<em>nec</em>)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">399611</p></td>
                <td><p>Sign writer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">411111</p></td>
                <td><p>Ambulance Officer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">411112</p></td>
                <td><p>Intensive Care Ambulance Paramedic</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">411213</p></td>
                <td><p>Dental Technician</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">411311</p></td>
                <td><p>Diversional Therapist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">411611</p></td>
                <td><p>Massage Therapist</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">411711</p></td>
                <td><p>Community Worker</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">411712</p></td>
                <td><p>Disabilities Services Officer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">411713</p></td>
                <td><p>Family Support Worker</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">411715</p></td>
                <td><p>Residential Care Officer</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">411716</p></td>
                <td><p>Youth Worker</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">452311</p></td>
                <td><p>Diving Instructor (Open Water)</p></td>
                <td><p align="center">Closed</p></td>
              </tr>
              <tr>
                <td><p align="center">452312</p></td>
                <td><p>Gymnastics Coach or Instructor</p></td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div class="col-md-4 col-sm-4 col-xs-12">
        <?php include('enquiry-form.php')?>
      </div>
    </div>
  </div>
</div>
</div>
</div>
<?php include 'inc/footer.php'; ?>
