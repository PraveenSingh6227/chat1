<?php include 'inc/header.php'; ?>
<div class="page-area">
    <div class="breadcumb-overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="breadcrumb">
                    <div class="bread-inner">
                        <div class="section-headline white-headline">
                            <h2>Personal <span class="color"> Branding</span></h2>
                        </div>
                        <ul class="breadcrumb-bg">
                            <li class="home-bread"><a href="index.php">Home</a></li>
                            <li>Personal Branding</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="team-area bg-color pd-35">
    <div class="container">
        <!-- section head -->
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-headline text-center">
                    <h3>Personal <span class="color"> Branding</span></h3>
                </div>
            </div>
        </div>
        <div class="row">
		 <div class="col-md-8 col-sm-8 col-xs-12" style="box-shadow: 5px 3px 10px rgb(0 0 0 / 10%);">
<div class='text-justify innerpage-text'><ol>
<li><strong>Resume: </strong>An immaculate outline and expression of your Professional Contour encompassing all your Experience, Competencies and Merits gained over the years. Resume is crafted defining your career story to reach any destination where you wish to land.<br />
&nbsp;</li>
<li><strong>Cover Letter:</strong> A perfect companion for your Resume detailing your Profile and Endeavors targeting the Global employers and determining what more you can bring to the table.<br />
&nbsp;</li>
<li><strong>LinkedIn:</strong> A Profile designed for Global Outreach focusing on Domain Keywords enhancing the visibility and extent of your Profile. The profile is drafted to meet the industry trends and bridge the gap between you and the employer.<br />
&nbsp;</li>
<li><strong>Slideshare Resume: </strong>A Creative brush up on the resume making it more visually Interactive and virtually innovative. In this world of technology only creativity and innovation keeps you ahead of the curve and slideshare is one of those example.</li>
</ol>
<p><br />
<a href="authorized-representative-canada.html" style="padding:7px 5px ;background: #f00 !important; color: #fff; line-height: 24px; border-radius: 5px; margin-bottom: 6px;  width: 140px;" target="_blank" title="Our Canada RCIC Agent">Our Canada RCIC Agent</a><br />
&nbsp;</p>
<h4><strong>How we help?</strong></h4>
<ol>
<li>In this modern era of competition we aim to deliver career&ndash;oriented quality service to achieve one&rsquo;s professional goals.</li>
<li>These products will make you stand&ndash;out in the crowd and pave the way for the whole new world of opportunities.</li>
<li>They are specially designed to meet the industry standards and requirements making you the right candidate for the desired occupation.</li>
<li>Resume and cover letters are the best tools to magnify your career highlights, and we as an expert in the industry add perfection into the services to grab immediate attention of the employers.</li>
<li>LinkedIn is world&rsquo;s largest Professional Networking Site with an ocean of innumerable profiles, and we simply make your profile more visible, illustrative, domain-centric, keyword-specialized and impactful.</li>
<li>Creativity and inventiveness never goes out of style and Slideshare Resume empowers you to showcase your talent in a broader canvas.</li>
</ol>
</div>
</div>
		 <div class="col-md-4 col-sm-4 col-xs-12">
		 <?php include('enquiry-form.php')?>
		 </div>
                
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>