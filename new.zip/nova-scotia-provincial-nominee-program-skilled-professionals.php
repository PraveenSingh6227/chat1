<?php include 'inc/header.php'; ?>
<div class="page-area">
    <div class="breadcumb-overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="breadcrumb">
                    <div class="bread-inner">
                        <div class="section-headline white-headline">
                            <h2>Nova Scotia <span class="color"> PNP</span></h2>
                        </div>
                        <ul class="breadcrumb-bg">
                            <li class="home-bread"><a href="index.php">Home</a></li>
                            <li>Nova Scotia PNP</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="team-area bg-color pd-35">
    <div class="container">
        <!-- section head -->
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-headline text-center">
                    <h3>Nova Scotia <span class="color"> PNP</span></h3>
                </div>
            </div>
        </div>
        <div class="row">
		 <div class="col-md-8 col-sm-8 col-xs-12" style="box-shadow: 5px 3px 10px rgb(0 0 0 / 10%);">
<div class='text-justify innerpage-text'><p>Nova Scotia Provincial Nominee Program is one of the most popular pathways to migrate to Canada. The program allows skilled foreign workers and recently graduated international students to live and work in Nova Scotia.</p>
<p>The provincial government of Nova Scotia runs the following programs to invite skilled immigrants:</p>
<ul>
<li>Nova Scotia Labor Market Priorities</li>
<li>Labor Market Priorities for Physicians</li>
<li>Physician</li>
<li>Entrepreneur</li>
<li>International Graduate Entrepreneur</li>
<li>Skilled Worker</li>
<li>Occupations-in-demand</li>
<li>Nova Scotia Experience- Express Entry</li>
</ul>
<p>The program only invites workers who have the necessary skills and experience to contribute to the provincial economy. Nova Scotia is an immigration-friendly province featuring a comprehensive ranking system to filter candidates across various streams.</p>
<p><a href="../check-your-eligibility.html" style="color: rgb(255, 255, 255); padding: 7px 5px; line-height: 24px; border-radius: 5px; margin-bottom: 6px; width: 140px; background: rgb(255, 0, 0) !important;" target="_blank" title="Check Your Eligibility">Check Your Eligibility</a></p>
<p><strong>Nova Scotia Provincial Nominee Program- Streams</strong></p>
<p><strong>Nova Scotia Labor Market Priorities- </strong>The program selects eligible applicants through the federal express entry system who meet the local labor market needs. The government sends nominations to individuals who meet the minimum work-experience requirements and show sufficient funds to establish themselves in Nova Scotia successfully.</p>
<p><strong>Who is eligible?</strong></p>
<p>To be eligible, you must:</p>
<ul>
<li>Be 21-55 years of age.</li>
<li>Be able to secure a valid full-time permanent job offer from an employer in Nova Scotia.</li>
<li>Have at least one year of professional work experience in the related job. Semi-skilled or low-skilled workers must demonstrate a minimum of six months of work experience.</li>
<li>Have a high-school diploma.</li>
<li>Have the training, skills, and accreditation for the job.</li>
<li>Prove language ability equal to Canadian Language Benchmark (CLB) Level 5 if you are a skilled worker. For low-skilled workers, meeting CLB level 4 would get the invite.&nbsp;</li>
<li>Show sufficient financial sources and funds to settle in Nova Scotia.</li>
</ul>
<p><br />
<a href="authorized-representative-canada.html" style="padding:7px 5px ;background: #f00 !important; color: #fff; line-height: 24px; border-radius: 5px; margin-bottom: 6px;  width: 140px;" target="_blank" title="Our Canada RCIC Agent">Our Canada RCIC Agent</a><br />
&nbsp;</p>
<p><strong>Labor Market Priorities for Physicians- </strong>The stream is designed for Physicians who wish to migrate to Nova Scotia through the federal Express Entry system. The pathway is only available for physicians who have secured a letter of approval from the Nova Scotia Health Authority or the IWK Health Centre and receive a Letter of Interest from the Nova Scotia Office of Immigration.</p>
<p><strong>Who is eligible?</strong></p>
<p>To be eligible, you must:</p>
<ul>
<li>Have an approved opportunity from the NSHA or IWK as either a general practitioner and family physician (NOC 3112) or a specialist physician (NOC 3111);</li>
<li>Provide a copy of a signed Return for Service Agreement with the Nova Scotia Department of Health and Wellness indicating commitment to live and work in Nova Scotia for a minimum period of two years;</li>
<li>Receive a Letter of Interest from the Nova Scotia Nominee Program within the Express Entry system;</li>
<li>Submit your application within 30 calendar days of the date on which your Letter of Interest was issued;</li>
<li>Meet the minimum work-experience requirements of the Express Entry stream for which you have qualified;</li>
<li>Demonstrate sufficient funds to establish yourself and your family in Nova Scotia successfully.</li>
</ul>
<p>The physician stream assists the provincial authorities in hiring general practitioners, family physicians, and specialist physicians to live and work in Nova Scotia. The stream aims at supporting the NSHA and IWK to recruit and retain physicians with the required skills for positions that they could not fill with a permanent resident or Canadian citizen.</p>
<p><strong>Who is eligible?</strong></p>
<p>To be eligible, you must:</p>
<ul>
<li>Be signed and dated by a person authorized to hire physicians at the NSHA or IWK</li>
<li>Be signed and dated by the applicant who is accepting the opportunity</li>
<li>Indicate eligibility for licensure with the College of Physicians and Surgeons of NS</li>
<li>Indicate that the applicant is eligible to apply for privileges and credentials with NSHA and the IWK</li>
</ul>
<p><a href="../expressyourinterest.html" style="color: rgb(255, 255, 255); padding: 7px 5px; line-height: 24px; border-radius: 5px; margin-bottom: 6px; width: 220px; background: rgb(255, 0, 0) !important;" target="_blank" title="Immigration Visa Enquiry Form">Free Profile Assessment and Visa Guidance</a></p>
<p>&nbsp;</p>
<p><strong>Entrepreneur- </strong>The pathway aims to welcome experienced business owners or senior managers to Nova Scotia and allow them to set up a business in the province. With this stream, entrepreneurs can establish a new business or buy an existing one. After operating the business successfully for a year, the entrepreneur may apply for permanent resident status.</p>
<p><strong>Who is eligible?</strong></p>
<p>To be eligible, you must:</p>
<ul>
<li>Be 21 years of age or older;</li>
<li>Be genuinely interested in living permanently in Nova Scotia while owning and actively managing a business in Nova Scotia;</li>
<li>Have a net worth of at least CAD 600,000;</li>
<li>Be able to invest at least CAD 150,000 of your own money in establishing a business in Nova Scotia;</li>
<li>Have at least three years&rsquo; experience actively managing and owning a business (1/3 ownership minimum) or more than five years&rsquo; experience in a senior business management role;</li>
<li>Have a score of at least five on the Canadian Language Benchmark</li>
<li>Submit an Expression of Interest</li>
<li>Receive an Invitation to Apply from the Nova Scotia Office of Immigration.</li>
</ul>
<p><strong>International Graduate Entrepreneur- </strong>The stream is for the recent international graduates of Nova Scotia who intend to settle in Nova Scotia permanently. However, to do so, they must have started or bought a business in the province and operated it for at least one year.</p>
<p><strong>Who is eligible?</strong></p>
<p>To be eligible, you must:</p>
<ul>
<li>Be genuinely interested in settling in the province while carrying out business activities in Nova Scotia;</li>
<li>have at least one year&rsquo;s continuous experience actively managing and owning your current Nova Scotia business (33.33% ownership minimum);</li>
<li>Have completed a degree or diploma after at least two academic years of full-time, in-person study at a university in Nova Scotia or the Nova Scotia Community College;</li>
<li>Have a valid post-graduation work permit;</li>
<li>Have a score of at least seven on the Canadian Language Benchmark</li>
<li>Complete an online&nbsp;Expression of Interest&nbsp;and</li>
<li>Secure an Invitation to Apply from the provincial government.</li>
</ul>
<p><strong>Skilled Worker- </strong>the skilled worker stream allows employers in Nova Scotia to hire and retain foreign talent in the province. Foreign skilled workers and international graduates are eligible for this program. An employer can employ workers for job positions for which no local talent is available.</p>
<p><strong>Who is eligible?</strong></p>
<p>To be eligible, you must:</p>
<ul>
<li>Have a full-time permanent job offer from a Nova Scotia employer;</li>
<li>Have one year of work experience related to the job.</li>
<li>Be 21 to 55 years old;</li>
<li>Have a high school diploma;</li>
<li>Have the appropriate training, skills, and accreditation for the job;</li>
<li>Prove language ability equal to Canadian Language Benchmark (CLB) Level 5 if you are a skilled worker.</li>
<li>Show enough financial resources to settle in Nova Scotia successfully.</li>
</ul>
<p><strong>Occupations in Demand- </strong>This pathway targets individuals working across professions in massive demand in Nova Scotia. If your occupation is in demand in Nova Scotia, you may be eligible to apply for this stream.</p>
<p><strong>Who is eligible?</strong></p>
<p>To be eligible, you must:</p>
<ul>
<li>Have a full-time permanent job offer from a Nova Scotia employer in either NOC 3413 (Nurse Aides, orderlies, and patient service associates) or NOC 7511 (Transport truck drivers);</li>
<li>Have one year of work experience related to the job;</li>
<li>Be 21 to 55 years old;</li>
<li>Have a high school diploma;</li>
<li>Have the appropriate training, skills, and/or accreditation for the job;</li>
<li>Prove language ability equal to Canadian Language Benchmark (CLB) Level 4 even if your first language is English or French;</li>
<li>Show enough financial resources to settle in Nova Scotia successfully.</li>
</ul>
<p><strong>Nova Scotia Experience- Express Entry- </strong>the pathway is created for highly skilled individuals planning to live and work in Nova Scotia. To apply, applicants must have at least one year of experience working in Nova Scotia in a high skilled occupation.</p>
<p><strong>Who is eligible?</strong></p>
<p>To be eligible, you must:</p>
<ul>
<li>have at least one year of work experience in Nova Scotia;</li>
<li>be 21 to 55 years old;</li>
<li>have a Canadian high school credential or equivalent;</li>
<li>Prove language ability in English or French on the Canadian Language Benchmark (CLB).</li>
<li>have a profile in Canada&rsquo;s&nbsp;<a href="http://canada.ca/expressentry">Express Entry</a>&nbsp;system</li>
</ul>
<p><strong>Documents Required</strong></p>
<p>You will need several documents to complete your application. You will also have to get documents from third parties such as educational institutions and governments to complete your application. Some of them are described as follows:</p>
<ul>
<li>Documents related to your job offer</li>
<li>Documents related to your work experience. To prove that you have the work experience and skills needed for the job, you must include letters of reference from your employers.</li>
<li>a copy of your high school diploma</li>
<li>copies of the licenses or certificates required for the job you have been offered, if needed</li>
<li>IELTS test results</li>
<li>Copy of passports, which must include the following:
<ul style="list-style-type:circle;">
<li>the passport number</li>
<li>the date of issue and expiry</li>
<li>the photo of the passport holder</li>
<li>the name of the passport holder as well as their date and place of birth</li>
<li>any changes to the passport holder&rsquo;s name, date of birth, or other identifying information</li>
<li>any changes to the passport&rsquo;s expiry date</li>
<li>any visas or visits to Canada</li>
</ul>
</li>
<li>Documents related to your spouse and children</li>
<li>Banking statements from the past three months showing all account balances and transaction history</li>
</ul>
<p><strong>Processing time </strong></p>
<p>The processing time for Nova Scotia Provincial Nominee Program can be three months or more.</p>
</div>
</div>
		 <div class="col-md-4 col-sm-4 col-xs-12">
		 <?php include('enquiry-form.php')?>
		 </div>
                
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>