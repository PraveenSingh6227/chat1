<?php include 'inc/header.php'; ?>
<div class="solution-area">
    <div class="breadcumb-overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="breadcrumb">
                    <div class="bread-inner">
                        <div class="section-headline white-headline">
                            <h2>Our <span class="color">Solution</span></h2>
                        </div>
                        <ul class="breadcrumb-bg">
                            <li class="home-bread"><a href="index.php">Home</a></li>
                            <li class="home-bread"><a href="about.php">About us</a></li>
                            <li>Our Solution</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="team-area bg-color pd-35">
    <div class="container">
        <!-- section head -->
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-headline text-center">
                    <h3>Our<span class="color"> Solution</span></h3>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="team-member">
                <h3>Prime Immigration LLP is expert across the full range of solar power applications, ranging from stand-alone solar parks to complex projects with integrated energy storage. The decades of experience of the Prime Immigration LLP group in the thermal power sector, also makes us an ideal partner for hybrid applications, which combine the advantages of renewable energy sources with conventional power generation. Within the domain of electrical infrastructure, we have significant experience and engineering capability essential for the successful integration of solar power to the grid.</h3>
            </div>
        </div>
    </div>
</div>
<div class="about-page-area pd-35">
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-xs-12 col-sm-12 text-center">
                <h3>We apply our industry knowledge and engineering capacity to bring the potential of solar to the world</h3>
            </div>
            <div class="support-all">
                <!-- Start services -->
                <div class="col-md-3 col-sm-3 col-xs-12">
                    <div class="support-services">
                       <a class="support-images" href="#">01</a>
                        <div class="support-content">
                            <h4><a href="#">Utility Scale Solar Power</a></h4>
                        </div>
                    </div>
                </div>
                <!-- Start services -->
                <div class="col-md-3 col-sm-3 col-xs-12">
                    <div class="support-services">
                        <a class="support-images" href="#">02</a>
                        <div class="support-content">
                            <h4><a href="#">Electrical Infrastructure</a></h4>
                        </div>
                    </div>
                </div>
                <!-- Start services -->
                <div class="col-md-3 col-sm-3 col-xs-12">
                    <div class="support-services">
                        <a class="support-images" href="#">03</a>
                        <div class="support-content">
                            <h4><a href="#">Energy Storage</a></h4>
                        </div>
                    </div>
                </div>
                <!-- Start services -->
                <!-- Start services -->
                <div class="col-md-3 col-sm-3 col-xs-12">
                    <div class="support-services">
                        <a class="support-images" href="#">04</a>
                        <div class="support-content">
                            <h4><a href="#">Hybrid Systems</a></h4>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>