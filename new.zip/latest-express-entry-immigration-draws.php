<?php include 'inc/header.php'; ?>
<div class="page-area">
    <div class="breadcumb-overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="breadcrumb">
                    <div class="bread-inner">
                        <div class="section-headline white-headline">
                            <h2>Latest Draws Express <span class="color"> Entry Program</span></h2>
                        </div>
                        <ul class="breadcrumb-bg">
                            <li class="home-bread"><a href="index.php">Home</a></li>
                            <li>Latest Draws Express Entry Program</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="team-area bg-color pd-35">
    <div class="container">
        <!-- section head -->
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-headline text-center">
                    <h3>Latest Draws Express <span class="color"> Entry Program</span></h3>
                </div>
            </div>
        </div>
        <div class="row">
		 <div class="col-md-8 col-sm-8 col-xs-12" style="box-shadow: 5px 3px 10px rgb(0 0 0 / 10%);">
<div class='text-justify innerpage-text'><p>Canada Immigration department has been rolling out the Canada Express Entry Draw<strong> </strong>with full throttle and maximum opportunities. It has been witnessed that every month at least 2 CIC Points Draws are taking place by granting Invitation to Apply (ITA) to the eligible candidates under <strong><a href="canada-federal-skilled-workers-program-petition-process.html" target="_blank">Federal Skilled Worker Program</a></strong>. These eligible candidates have to submit their ITA Application for which they will receive the Canada PR Visa.<br />
&nbsp;</p>
<p><strong>What is the Latest Express Entry Draw 2022?</strong></p>
<p>As per the latest <strong><a href="../canada-immigration.html" target="_blank">Canada Immigration</a></strong> Levels for 2022, the govt. is aiming to invite 401,000 new immigrants from all around the world in the year of 2022. This year will witness an extraordinary surge in invitations in all the Canadian economic pathways. Canada Express Entry will grant the maximum number of invitations to foreign talents via Express Entry Draws. Below table entails the detailed list of Latest Canada Express Entry Draw trend in 2022:</p>
<p>&nbsp;</p>
<table border="0" cellspacing="3" width="90%">
<tbody>
<tr>
<th>Draw</th>
<th>Date</th>
<th>No. of Invitation</th>
<th>Lowest CRS Score</th>
</tr>
<tr>
<td><span style="color:#FF0000;">221</span></td>
<td><span style="color:#FF0000;">August 3, 2022</span></td>
<td><font color="#ff0000">2,000</font></td>
<td><span style="color:#FF0000;">533</span></td>
</tr>
<tr>
<td>220</td>
<td>July 20, 2022</td>
<td>1,750</td>
<td>542</td>
</tr>
<tr>
<td>219</td>
<td>July 6, 2022</td>
<td>1,500</td>
<td>557</td>
</tr>
<tr>
<td>218</td>
<td>July 6, 2022</td>
<td>1,500</td>
<td>557</td>
</tr>
<tr>
<td>217</td>
<td>June 22, 2022</td>
<td>636</td>
<td>752</td>
</tr>
<tr>
<td>216</td>
<td>June 8, 2022</td>
<td>932</td>
<td>796</td>
</tr>
<tr>
<td>215</td>
<td>May 25, 2022</td>
<td>590</td>
<td>741</td>
</tr>
<tr>
<td>214</td>
<td>May 11, 2022</td>
<td>545</td>
<td>753</td>
</tr>
<tr>
<td>213</td>
<td>April 27, 2022</td>
<td>829</td>
<td>772</td>
</tr>
<tr>
<td>212</td>
<td>April 13, 2022</td>
<td>787</td>
<td>782</td>
</tr>
<tr>
<td>211</td>
<td>March 30, 2022</td>
<td>919</td>
<td>785</td>
</tr>
<tr>
<td>210</td>
<td>March 16, 2022</td>
<td>924</td>
<td>754</td>
</tr>
<tr>
<td>209</td>
<td>March 2, 2022</td>
<td>1047</td>
<td>761</td>
</tr>
<tr>
<td>208</td>
<td>February 16, 2022</td>
<td>1082</td>
<td>710</td>
</tr>
<tr>
<td>207</td>
<td>February 2, 2022</td>
<td>1070</td>
<td>674</td>
</tr>
<tr>
<td>206</td>
<td>January 19, 2022</td>
<td>1036</td>
<td>745</td>
</tr>
<tr>
<td>205</td>
<td>January 5, 2022</td>
<td>392</td>
<td>808</td>
</tr>
<tr>
<td>204</td>
<td>December 22, 2021</td>
<td>746</td>
<td>720</td>
</tr>
<tr>
<td>203</td>
<td>December 10, 2021</td>
<td>1032</td>
<td>698</td>
</tr>
<tr>
<td>202</td>
<td>November 24, 2021</td>
<td>613</td>
<td>737</td>
</tr>
<tr>
<td>201</td>
<td>November 10, 2021</td>
<td>775</td>
<td>685</td>
</tr>
<tr>
<td>200</td>
<td>October 27, 2021</td>
<td>800</td>
<td>744</td>
</tr>
<tr>
<td>199</td>
<td>October 13, 2021</td>
<td>681</td>
<td>720</td>
</tr>
<tr>
<td>198</td>
<td>September 29, 2021</td>
<td>761</td>
<td>742</td>
</tr>
<tr>
<td>197</td>
<td>September 15, 2021</td>
<td>521</td>
<td>732</td>
</tr>
<tr>
<td>196</td>
<td>September 14, 2021</td>
<td>2000</td>
<td>462</td>
</tr>
<tr>
<td>195</td>
<td>September 1, 2021</td>
<td>635</td>
<td>764</td>
</tr>
<tr>
<td>194</td>
<td>August 19, 2021</td>
<td>3000</td>
<td>403</td>
</tr>
<tr>
<td>193</td>
<td>August 18, 2021</td>
<td>463</td>
<td>751</td>
</tr>
<tr>
<td>192</td>
<td>August 5, 2021</td>
<td>3000</td>
<td>404</td>
</tr>
<tr>
<td>191</td>
<td>August 4, 2021</td>
<td>512</td>
<td>760</td>
</tr>
<tr>
<td>190</td>
<td>July 22, 2021</td>
<td>4500</td>
<td>357</td>
</tr>
<tr>
<td>189</td>
<td>July 21, 2021</td>
<td>462</td>
<td>734</td>
</tr>
<tr>
<td>188</td>
<td>July 8, 2021</td>
<td>4500</td>
<td>369</td>
</tr>
<tr>
<td>187</td>
<td>July 7, 2021</td>
<td>627</td>
<td>760</td>
</tr>
<tr>
<td>186</td>
<td>June 24, 2021</td>
<td>6000</td>
<td>357</td>
</tr>
<tr>
<td>185</td>
<td>June 23, 2021</td> 
<td>1002</td>
<td>742</td>
</tr>
<tr>
<td>184</td>
<td>June 10, 2021</td>
<td>6000</td>
<td>368</td>
</tr>
<tr>
<td>183</td>
<td>June 9, 2021</td>
<td>940</td>
<td>711</td>
</tr>
<tr>
<td>182</td>
<td>May 31, 2021</td>
<td>5956</td>
<td>380</td>
</tr>
<tr>
<td>181</td>
<td>May 26, 2021</td>
<td>500</td>
<td>713</td>
</tr>
<tr>
<td>180</td>
<td>May 20, 2021</td>
<td>1842</td>
<td>397</td>
</tr>
<tr>
<td>179</td>
<td>May 13, 2021</td>
<td>4147</td>
<td>401</td>
</tr>
<tr>
<td>178</td>
<td>May 12, 2021</td>
<td>557</td>
<td>752</td>
</tr>
<tr>
<td>177</td>
<td>April 29, 2021</td>
<td>6000</td>
<td>400</td>
</tr>
<tr>
<td>176</td>
<td>April 28, 2021</td>
<td>381</td>
<td>717</td>
</tr>
<tr>
<td>175</td>
<td>April 16, 2021</td>
<td>6,000</td>
<td>417</td>
</tr>
<tr>
<td>175</td>
<td>April 14, 2021</td>
<td>266</td>
<td>753</td>
</tr>
<tr>
<td>174</td>
<td>March 18, 2021</td>
<td>5,000</td>
<td>449</td>
</tr>
<tr>
<td>173</td>
<td>March 17, 2021</td>
<td>183</td>
<td>739</td>
</tr>
<tr>
<td>172</td>
<td>March 08, 2021</td>
<td>671</td>
<td>739</td>
</tr>
<tr>
<td>171</td>
<td>February 13, 2021</td>
<td>27,332</td>
<td>75</td>
</tr>
<tr>
<td>170</td>
<td>February 10, 2021</td>
<td><span style="color: rgb(67, 69, 75); font-family: &quot;source sans pro&quot;, HelveticaNeue-Light, &quot;helvetica neue light&quot;, &quot;helvetica neue&quot;, Helvetica, Arial, &quot;lucida grande&quot;, sans-serif; font-size: 14px; background-color: rgb(249, 249, 249);">654</span></td>
<td>720</td>
</tr>
<tr>
<td>169</td>
<td>January 21, 2021</td>
<td>4,626</td>
<td>454</td>
</tr>
<tr>
<td>168</td>
<td>January 20, 2021</td>
<td>374</td>
<td>741</td>
</tr>
<tr>
<td>167</td>
<td>January 06, 2021</td>
<td>250</td>
<td>813</td>
</tr>
<tr>
<td>166</td>
<td>December 23, 2020</td>
<td>5,000</td>
<td>469</td>
</tr>
<tr>
<td>165</td>
<td>December 9, 2020</td>
<td>5,000</td>
<td>469</td>
</tr>
<tr>
<td>164</td>
<td>November 25, 2020</td>
<td>5,000</td>
<td>469</td>
</tr>
<tr>
<td>163</td>
<td>November 18, 2020</td>
<td>5,000</td>
<td>472</td>
</tr>
<tr>
<td>162</td>
<td>November 05, 2020</td>
<td>4,500</td>
<td>478</td>
</tr>
<tr>
<td>161</td>
<td>October 14, 2020</td>
<td>4,500</td>
<td>471</td>
</tr>
<tr>
<td>160</td>
<td>September 30, 2020</td>
<td>4,200</td>
<td>471</td>
</tr>
<tr>
<td>159</td>
<td>September 16, 2020</td>
<td>4,200</td>
<td>472</td>
</tr>
<tr>
<td>158</td>
<td>September 02, 2020</td>
<td>4,200</td>
<td>475</td>
</tr>
<tr>
<td>157</td>
<td>August 20, 2020</td>
<td>3,300</td>
<td>454</td>
</tr>
<tr>
<td>156</td>
<td>August 19, 2020</td>
<td>600</td>
<td>711</td>
</tr>
<tr>
<td>155</td>
<td>August 06, 2020</td>
<td>250</td>
<td>415</td>
</tr>
<tr>
<td>154</td>
<td>August 05, 2020</td>
<td>3,900</td>
<td>476</td>
</tr>
<tr>
<td>153</td>
<td>July 23, 2020</td>
<td>3,343</td>
<td>445</td>
</tr>
<tr>
<td>152</td>
<td>July 22, 2020</td>
<td>557</td>
<td>687</td>
</tr>
<tr>
<td>151</td>
<td>July 08, 2020</td>
<td>3,900</td>
<td>478</td>
</tr>
<tr>
<td>150</td>
<td>June 25, 2020</td>
<td>3,508</td>
<td>431</td>
</tr>
<tr>
<td>149</td>
<td>June 24, 2020</td>
<td>392</td>
<td>696</td>
</tr>
<tr>
<td>148</td>
<td>June 11, 2020</td>
<td>3,559</td>
<td>437</td>
</tr>
<tr>
<td>147</td>
<td>June 10, 2020</td>
 <td>341</td>
<td>743</td>
</tr>
<tr>
<td>146</td>
<td>May 28, 2020</td>
<td>3,515</td>
<td>440</td>
</tr>
<tr>
<td>145</td>
<td>May 27, 2020</td>
<td>385</td>
<td>757</td>
</tr>
<tr>
<td>144</td>
<td>May 15, 2020</td>
<td>3,371</td>
<td>447</td>
</tr>
<tr>
<td>143</td>
<td>May 14, 2020</td>
<td>529</td>
<td>718</td>
</tr>
<tr>
<td>142</td>
<td>May 01, 2020</td>
<td>3,311</td>
<td>452</td>
</tr>
<tr>
<td>141</td>
<td>April 29, 2020</td>
<td>589</td>
<td>692</td>
</tr>
<tr>
<td>140</td>
<td>April 16, 2020</td>
<td>3,782</td>
<td>455</td>
</tr>
<tr>
<td>139</td>
<td>April 15, 2020</td>
<td>118</td>
<td>808</td>
</tr>
<tr>
<td>138</td>
<td>April 09, 2020</td>
<td>3,294</td>
<td>464</td>
</tr>
<tr>
<td>137</td>
<td>April 09, 2020</td>
<td>606</td>
<td>698</td>
</tr>
<tr>
<td>136</td>
<td>March 23, 2020</td>
<td>3232</td>
<td>467</td>
</tr>
<tr>
<td>135</td>
<td>March 04, 2020</td>
<td>3900</td>
<td>471</td>
</tr>
<tr>
<td>134</td>
<td>February 19, 2020</td>
<td>4500</td>
<td>470</td>
</tr>
<tr>
<td>133</td>
<td>February 06, 2020</td>
<td>3500</td>
<td>472</td>
</tr>
<tr>
<td>132</td>
<td>January 22, 2020</td>
<td>3400</td>
<td>471</td>
</tr>
<tr>
<td>131</td>
<td>January 08, 2020</td>
<td>3400</td>
<td>473</td>
</tr>
<tr>
<td>130</td>
<td>December 19, 2019</td>
<td>3200</td>
<td>469</td>
</tr>
<tr>
<td>129</td>
<td>December 11, 2019</td>
<td>3200</td>
<td>472</td>
</tr>
<tr>
<td>128</td>
<td>November 27, 2019</td>
<td>3600</td>
<td>471</td>
</tr>
<tr>
<td>127</td>
<td>November 13, 2019</td>
<td>3600</td>
<td>472</td>
</tr>
<tr>
<td>126</td>
<td>October 30, 2019</td>
<td>3900</td>
<td>475</td>
</tr>
<tr>
<td>125</td>
<td>October 02, 2019</td>
<td>3900</td>
<td>464</td>
</tr>
<tr>
<td>124</td>
<td>September 18, 2019</td>
<td>3600</td>
<td>462</td>
</tr>
<tr>
<td>123</td>
<td>September 04, 2019</td>
<td>3600</td>
<td>463</td>
</tr>
<tr>
<td>122</td>
<td>August 20, 2019</td>
<td>3600</td>
<td>457</td>
</tr>
<tr>
<td>121</td>
<td>August 12, 2019</td>
<td>3600</td>
<td>466</td>
</tr>
<tr>
<td>120</td>
<td>July 24, 2019</td>
<td>3600</td>
<td>459</td>
</tr>
<tr>
<td>119</td>
<td>July 24, 2019</td>
<td>3600</td>
<td>460</td>
</tr>
<tr>
<td>118</td>
<td>June 26, 2019</td>
<td>3350</td>
<td>462</td>
</tr>
<tr>
<td>117</td>
<td>June 12, 2019</td>
<td>3350</td>
<td>465</td>
</tr>
<tr>
<td>116</td>
<td>May 29, 2019</td>
<td>3350</td>
<td>470</td>
</tr>
<tr>
<td>115</td>
<td>May 1, 2019</td>
<td>3350</td>
<td>450</td>
</tr>
<tr>
<td>114</td>
<td>April 17, 2019</td>
<td>3350</td>
<td>451</td>
</tr>
<tr>
<td>113</td>
<td>April 03, 2019</td>
<td>3350</td>
<td>451</td>
</tr>
<tr>
<td>112</td>
<td>March 20, 2019</td>
<td>3350</td>
<td>452</td>
</tr>
<tr>
<td>111</td>
<td>Feb 06, 2019</td>
<td>3350</td>
<td>454</td>
</tr>
<tr>
<td>110</td>
<td>Feb 20, 2019</td>
<td>3350</td>
<td>457</td>
</tr>
<tr>
<td>109</td>
<td>Jan 30, 2019</td>
<td>3350</td>
<td>438</td>
</tr>
<tr>
<td>108</td>
<td>Jan 23, 2019</td>
<td>3900</td>
<td>443</td>
</tr>
<tr>
<td>107</td>
<td>Jan 10, 2019</td>
<td>3900</td>
<td>449</td>
</tr>
</tbody>
</table>
<p>&nbsp;</p>
<p><a href="authorized-representative-canada.html" style="padding:7px 5px ;background: #f00 !important; color: #fff; line-height: 24px; border-radius: 5px; margin-bottom: 6px;  width: 140px;" target="_blank" title="Our Canada RCIC Agent">Our Canada RCIC Agent</a><br />
&nbsp;</p>
<p><strong>What is Canada Express Entry Draw?</strong></p>
<p>The technical explanation of Canada Express Entry Draw is that, it is a point-based system to select the best candidates suited for the Canada&rsquo;s labour market. In order to get selected, one needs to acquire high CRS score by declaring his/her age, educational qualifications, professional experience, language proficiency and adaptability factors. In simple terms, higher the CRS Score faster the chances of getting selection under <strong><a href="canada-express-entry.html" target="_blank">Express Entry</a></strong>.</p>
<p>&nbsp;</p>
<p><strong>How to get invitation to apply with low CRS Points?</strong></p>
<p>If a candidate has only managed to attain a low scoring CRS points in the <strong>Latest express entry draw</strong>, then he/she will have alternatives to choose from. Firstly, the candidate should try to improve his CRS points by the following ways:</p>
<ul>
<li>Re-appearing for the IELTS Examination can improve the scores when one understands the pattern of the examination.</li>
<li>Candidate&rsquo;s spouse can be beneficial for additional CRS points, if the spouse has more work experience, a high IELTS score and high qualifications.</li>
</ul>
<p>Consecutively, if the candidate does not wish to opt the aforementioned choices, the candidate will have other alternatives to rely on. Below are the options:</p>
<ul>
<li>The candidate should apply for the <a href="canada-pnp.html" target="_blank">Provincial Nominee Program</a>, if nominated then the he/she will receive 600 additional CRS points.</li>
</ul>
<ul>
<li>Having a valid job offer from a Canadian employer through Labour Market Impact Assessment (LMIA), can fetch 50 to 200 additional CRS Score which will be decided on the basis of candidates chosen NOC.</li>
</ul>
<p><strong>How to get Assistance from ICCRC Canada Migration Expert to apply Canada PR?</strong></p>
<p>As the ICCRC Regulated Canada Migration Expert, Abhinav Immigration does not compromise on the quality of our services, but maintain the utmost transparency and professionalism throughout the application procedure. We believe in imparting quality immigration solutions to our clients seeking immigration to their favorite destination. If you are confused, how to begin? Give us a call on - 08595 338 595 or you may reach us at <strong><a href="../cdn-cgi/l/email-protection.html#364153547657545e5f5857401855595b"><span class="__cf_email__" data-cfemail="9deaf8ffddfcfff5f4f3fcebb3fef2f0">[email&#160;protected]</span></a></strong>. Reach us to know more about Canada Express Entry Draw<strong>.</strong></p>
<h2>Latest Express Entry Immigration Draws are the invitations issued in 2018:</h2>
<table border="0" cellspacing="3" width="90%">
<tbody>
<tr>
<th>Draw</th>
<th>Date</th>
<th>No. of Invitation</th>
<th>Lowest CRS Score</th>
</tr>
<tr>
<td>106</td>
<td>Dec 19, 2018</td>
<td>3900</td>
<td>439</td>
</tr>
<tr>
<td>105</td>
<td>Dec 12, 2018</td>
<td>3900</td>
<td>445</td>
</tr>
<tr>
<td>104</td>
<td>Nov 28, 2018</td>
<td>3900</td>
<td>445</td>
</tr>
<tr>
<td>103</td>
<td>Nov 15, 2018</td>
<td>3900</td>
<td>449</td>
</tr>
<tr>
<td>102</td>
<td>Oct 29, 2018</td>
<td>3900</td>
<td>442</td>
</tr>
<tr>
<td>101</td>
<td>Oct 15, 2018</td>
<td>3900</td>
<td>440</td>
</tr>
<tr>
<td>100</td>
<td>Oct 03, 2018</td>
<td>3900</td>
<td>445</td>
</tr>
<tr>
<td>99</td>
<td>Sep 19, 2018</td>
<td>3500</td>
<td>441</td>
</tr>
<tr>
<td>98</td>
<td>Sep 05, 2018</td>
<td>3900</td>
<td>440</td>
</tr>
<tr>
<td>97</td>
<td>Aug 22, 2018</td>
<td>3750</td>
<td>440</td>
</tr>
<tr>
<td>96</td>
<td>Aug 08, 2018</td>
<td>3750</td>
<td>440</td>
</tr>
<tr>
<td>95</td>
<td>July 25, 2018</td>
<td>3750</td>
<td>441</td>
</tr>
<tr>
<td>94</td>
<td>July 11, 2018</td>
<td>3750</td>
<td>442</td>
</tr>
<tr>
<td>93</td>
<td>June 25, 2018</td>
<td>3750</td>
<td>442</td>
</tr>
<tr>
<td>92</td>
<td>June 13, 2018</td>
<td>3750</td>
<td>451</td>
</tr>
<tr>
<td>91</td>
<td>May 30, 2018</td>
<td>3500</td>
<td>440</td>
</tr>
<tr>
<td>90</td>
<td>May 23, 2018</td>
<td>3500</td>
<td>440</td>
</tr>
<tr>
<td>89</td>
<td>May 9, 2018</td>
<td>3500</td>
<td>441</td>
</tr>
<tr>
<td>88</td>
<td>April 25, 2018</td>
<td>3500</td>
<td>441</td>
</tr>
<tr>
<td>87</td>
<td>April 11, 2018</td>
<td>3500</td>
<td>444</td>
</tr>
<tr>
<td>86</td>
<td>March 26, 2018</td>
<td>3000</td>
<td>446</td>
</tr>
<tr>
<td>85</td>
<td>March&nbsp;14, 2018</td>
<td>3000</td>
<td>456</td>
</tr>
<tr>
<td>84</td>
<td>February 21, 2018</td>
<td>3000</td>
<td>442</td>
</tr>
<tr>
<td>83</td>
<td>February 7, 2018</td>
<td>3000</td>
<td>442</td>
</tr>
<tr>
<td>82</td>
<td>January 24, 2018</td>
<td>2750</td>
<td>444</td>
</tr>
<tr>
<td>81</td>
<td>January 10, 2018</td>
<td>2750</td>
<td>446</td>
</tr>
</tbody>
</table>
<h3>Express Entry Immigration Draws in 2017</h3>
<table border="0" cellspacing="3" width="90%">
<tbody>
<tr>
<th>Draw</th>
<th>Date</th>
<th>No. of Invitation</th>
<th>Lowest CRS Score</th>
</tr>
<tr>
<td>80</td>
<td>December 20, 2017</td>
<td>2750</td>
<td>446</td>
</tr>
<tr>
<td>79</td>
<td>December 6,&nbsp;2017</td>
<td>2750</td>
<td>452</td>
</tr>
<tr>
<td>78</td>
<td>November&nbsp;15,&nbsp;2017</td>
<td>2750</td>
<td>439</td>
</tr>
<tr>
<td>77</td>
<td>November 8, 2017</td>
<td>2000</td>
<td>458</td>
</tr>
<tr>
<td>76</td>
<td>November&nbsp;1,&nbsp;2017</td>
<td>505</td>
<td>241</td>
</tr>
<tr>
<td>75</td>
<td>November&nbsp;1,&nbsp;2017</td>
<td>290</td>
<td>673</td>
</tr>
<tr>
<td>74</td>
<td>October&nbsp;18,&nbsp;2017</td>
<td>2757</td>
<td>436</td>
</tr>
<tr>
<td>73</td>
<td>October 4, 2017</td>
<td>2801</td>
<td>438</td>
</tr>
<tr>
<td>72</td>
<td>September 20, 2017</td>
<td>2871</td>
<td>433</td>
</tr>
<tr>
<td>71</td>
<td>September 6, 2017</td>
<td>2772</td>
<td>435</td>
</tr>
<tr>
<td>70</td>
<td>August 23, 2017</td>
<td>3035</td>
<td>434</td>
</tr>
<tr>
<td>69</td>
<td>August 9, 2017</td>
<td>2991</td>
<td>433</td>
</tr>
<tr>
<td>68</td>
<td>August 2, 2017</td>
<td>3264</td>
<td>441</td>
</tr>
<tr>
<td>67</td>
<td>July 12, 2017</td>
<td>3202</td>
<td>440</td>
</tr>
<tr>
<td>66</td>
<td>June 28, 2017</td>
<td>3409</td>
<td>449</td>
</tr>
<tr>
<td>65</td>
<td>May 31, 2017</td>
<td>3877</td>
<td>413</td>
</tr>
<tr>
<td>64</td>
<td>May 26, 2017</td>
<td>400</td>
<td>199</td>
</tr>
<tr>
<td>63</td>
<td>May 26, 2017</td>
<td>143</td>
<td>775</td>
</tr>
<tr>
<td>62</td>
<td>May 17, 2017</td>
<td>3687</td>
<td>415</td>
</tr>
<tr>
<td>61</td>
<td>May 4, 2017</td>
<td>3796</td>
<td>423</td>
</tr>
<tr>
<td>60</td>
<td>April 19, 2017</td>
<td>3665</td>
<td>415</td>
</tr>
<tr>
<td>59</td>
<td>April 12, 2017</td>
<td>3923</td>
<td>423</td>
</tr>
<tr>
<td>58</td>
<td>April 5, 2017</td>
<td>3753</td>
<td>431</td>
</tr>
<tr>
<td>57</td>
<td>March 24, 2017</td>
<td>3749</td>
<td>441</td>
</tr>
<tr>
<td>56</td>
<td>March 1, 2017</td>
<td>3884</td>
<td>434</td>
</tr>
<tr>
<td>55</td>
<td>February 22, 2017</td>
<td>3611</td>
<td>441</td>
</tr>
<tr>
<td>54</td>
<td>February 8, 2017</td>
<td>3644</td>
<td>447</td>
</tr>
<tr>
<td>53</td>
<td>January 25, 2017</td>
<td>3508</td>
<td>453</td>
</tr>
<tr>
<td>52</td>
<td>January 11, 2017</td>
<td>3334</td>
<td>459</td>
</tr>
<tr>
<td>51</td>
<td>January 4, 2017</td>
<td>2902</td>
<td>468</td>
</tr>
</tbody>
</table>
<h3>Express Entry Immigration Draws in 2016</h3>
<table border="0" cellspacing="3" width="90%">
<tbody>
<tr>
<th>Draw</th>
<th>Date</th>
<th>No. of Invitation</th>
<th>Lowest CRS Score</th>
</tr>
<tr>
<td>50</td>
<td>December 22, 2016</td>
<td>2878</td>
<td>475</td>
</tr>
<tr>
<td>49</td>
<td>December 16, 2016</td>
<td>1936</td>
<td>497</td>
</tr>
<tr>
<td>48</td>
<td>November 30, 2016</td>
<td>559</td>
<td>786</td>
</tr>
<tr>
<td>47</td>
<td>November 16, 2016</td>
<td>2427</td>
<td>470</td>
</tr>
<tr>
<td>46</td>
<td>November 2, 2016</td>
<td>2080</td>
<td>472</td>
</tr>
<tr>
<td>45</td>
<td>October 19, 2016</td>
<td>1804</td>
<td>475</td>
</tr>
<tr>
<td>44</td>
<td>October 12, 2016</td>
<td>1518</td>
<td>484</td>
</tr>
<tr>
<td>43</td>
<td>September 21, 2016</td>
<td>1288</td>
<td>483</td>
</tr>
<tr>
<td>42</td>
<td>September 7, 2016</td>
<td>1000</td>
<td>491</td>
</tr>
<tr>
<td>41</td>
<td>August 24, 2016</td>
<td>750</td>
<td>538</td>
</tr>
<tr>
<td>40</td>
<td>August 10, 2016</td>
<td>754</td>
<td>490</td>
</tr>
<tr>
<td>39</td>
<td>July 27, 2016</td>
<td>755</td>
<td>488</td>
</tr>
<tr>
<td>38</td>
<td>July 13, 2016</td>
<td>747</td>
<td>482</td>
</tr>
<tr>
<td>37</td>
<td>June 29, 2016</td>
<td>773</td>
<td>482</td>
</tr>
<tr>
<td>36</td>
<td>June 15, 2016</td>
<td>752</td>
<td>488</td>
</tr>
<tr>
<td>35</td>
<td>June 1, 2016</td>
<td>762</td>
<td>483</td>
</tr>
<tr>
<td>34</td>
<td>May 18, 2016</td>
<td>763</td>
<td>484</td>
</tr>
<tr>
<td>33</td>
<td>May 6, 2016</td>
<td>799</td>
<td>534</td>
</tr>
<tr>
<td>32</td>
<td>April 20, 2016</td>
<td>1018</td>
<td>468</td>
</tr>
<tr>
<td>31</td>
<td>April 6, 2016</td>
<td>954</td>
<td>470</td>
</tr>
<tr>
<td>30</td>
<td>March 23, 2016</td>
<td>1014</td>
<td>470</td>
</tr>
<tr>
<td>29</td>
<td>March 9, 2016</td>
<td>1013</td>
<td>473</td>
</tr>
<tr>
<td>28</td>
<td>February 24, 2016</td>
<td>1484</td>
<td>453</td>
</tr>
<tr>
<td>27</td>
<td>February 10, 2016</td>
<td>1505</td>
<td>459</td>
</tr>
<tr>
<td>26</td>
<td>January 27, 2016</td>
<td>1468</td>
<td>457</td>
</tr>
<tr>
<td>25</td>
<td>January 13, 2016</td>
<td>1518</td>
<td>453</td>
</tr>
<tr>
<td>24</td>
<td>January 6, 2016</td>
<td>1463</td>
<td>461</td>
</tr>
</tbody>
</table>
<h3>Express Entry Immigration Draws in 2015</h3>
<table border="0" cellspacing="3" width="90%">
<tbody>
<tr>
<th>Draw</th>
<th>Date</th>
<th>No. of Invitation</th>
<th>Lowest CRS Score</th>
</tr>
<tr>
<td>23</td>
<td>December 18, 2015</td>
<td>1503</td>
<td>460</td>
</tr>
<tr>
<td>22</td>
<td>December 4, 2015</td>
<td>1451</td>
<td>461</td>
</tr>
<tr>
<td>21</td>
<td>November 27, 2015</td>
<td>1559</td>
<td>472</td>
</tr>
<tr>
<td>20</td>
<td>November 13, 2015</td>
<td>1506</td>
<td>484</td>
</tr>
<tr>
<td>19</td>
<td>October 23, 2015</td>
<td>1502</td>
<td>489</td>
</tr>
<tr>
<td>18</td>
<td>October 2, 2015</td>
<td>1530</td>
<td>450</td>
</tr>
<tr>
<td>17</td>
<td>September 18, 2015</td>
<td>1545</td>
<td>450</td>
</tr>
<tr>
<td>16</td>
<td>September 8, 2015</td>
<td>1517</td>
<td>459</td>
</tr>
<tr>
<td>15</td>
<td>August 21, 2015</td>
<td>1523</td>
<td>456</td>
</tr>
<tr>
<td>14</td>
<td>August 7, 2015</td>
<td>1402</td>
<td>471</td>
</tr>
<tr>
<td>13</td>
<td>July 17, 2015</td>
<td>1581</td>
<td>451</td>
</tr>
<tr>
<td>12</td>
<td>July 10, 2015</td>
<td>1516</td>
<td>463</td>
</tr>
<tr>
<td>11</td>
<td>June 26, 2015</td>
<td>1575</td>
<td>469</td>
</tr>
<tr>
<td>10</td>
<td>June 12, 2015</td>
<td>1501</td>
<td>482</td>
</tr>
<tr>
<td>09</td>
<td>May 22, 2015</td>
<td>1361</td>
<td>755</td>
</tr>
<tr>
<td>08</td>
<td>April 17, 2015</td>
<td>715</td>
<td>453</td>
</tr>
<tr>
<td>07</td>
<td>April 10, 2015</td>
<td>925</td>
<td>469</td>
</tr>
<tr>
<td>06</td>
<td>March 27, 2015</td>
<td>1637</td>
<td>453</td>
</tr>
<tr>
<td>05</td>
<td>March 20, 2015</td>
<td>1620</td>
<td>481</td>
</tr>
<tr>
<td>04</td>
<td>February 27, 2015</td>
<td>1187</td>
<td>735</td>
</tr>
<tr>
<td>03</td>
<td>February 20, 2015</td>
<td>849</td>
<td>808</td>
</tr>
<tr>
<td>02</td>
<td>February 7, 2015</td>
<td>779</td>
<td>818</td>
</tr>
<tr>
<td>01</td>
<td>January 31, 2015</td>
<td>779</td>
<td>886</td>
</tr>
</tbody>
</table>
<p>&nbsp;</p>
</div>
</div>
		 <div class="col-md-4 col-sm-4 col-xs-12">
		 <?php include('enquiry-form.php')?>
		 </div>
                
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>