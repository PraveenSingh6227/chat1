<?php include 'inc/header.php'; ?>
<div class="page-area">
    <div class="breadcumb-overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="breadcrumb">
                    <div class="bread-inner">
                        <div class="section-headline white-headline">
                            <h2>Authorized  <span class="color"> Representative-Canada</span></h2>
                        </div>
                        <ul class="breadcrumb-bg">
                            <li class="home-bread"><a href="index.php">Home</a></li>
                            <li>Authorized Representative-Canada</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="team-area bg-color pd-35">
    <div class="container">
        <!-- section head -->
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-headline text-center">
                    <h3>Authorized  <span class="color"> Representative-Canada</span></h3>
                </div>
            </div>
        </div>
        <div class="row">
		 <div class="col-md-8 col-sm-8 col-xs-12" style="box-shadow: 5px 3px 10px rgb(0 0 0 / 10%);">
<div class='text-justify innerpage-text'><p><strong>Immigration , Refugees and Citizenship Canada</strong> (<strong>IRCC</strong>) the Government of Canada, facilitates and regulates the arrival of immigrants to Canada, protects refugees and offers help to newcomers to Canada. If one hires a consultant to represent IRCC, such a representative must meet one of the criteria mentioned in the following link <a href="https://www.canada.ca/en/immigration-refugees-citizenship/services/immigration-citizenship-representative/choose/authorized.html" target="_blank">https://www.canada.ca/en/immigration-refugees-citizenship/services/immigration-citizenship-representative/choose/authorized.html</a></p>
<p><img alt="Sanjay Sharma" class="sanjaysharma" src="../images/sanjay-sharma-rcici-agent.png" class="sanjaysharma" style="float:right; padding-left:10px; height:250px" /></p>
<p><strong>Sanjay Sharma</strong> is a Registered Canadian Immigration Consultant (RCIC) and is based in the Ontario province of, Canada. A member in good standing with the College of Immigration and Citizenship Consultants (CICC), his registration number is R709081. Effective 1st April 2022, he is an authorized representative for <strong>ABHINAV</strong> clients.</p>
<p>Sanjay Sharma focuses his practice 100% on Canadian immigration law. He represents individuals, families, and companies to obtain various permanent and temporary visas such as Federal Skilled Immigration, PNP Applications, fianc&eacute;, and super visa for parents, students, trainees, start-up visas, entrepreneurs, Canadian Work Permit, etc. employment, among various other categories.</p>
<p>Sanjay Sharma, a first-generation Canadian immigrant, has been informally mentoring young and existing entrepreneurs in business and start-ups for years, sharing his small business experiences of encountering a long trail of successes and challenges. He has been living in Canada for over three decades. Being an entrepreneur in mainstream Canada and the USA, he is well versed in the business models, regulations, and practices of North America</p>
<p>Sanjay Sharma has a good grasp of banking, legal, and governing regulatory requirements to run a successful enterprise. He is familiar with the skills required to succeed in North America and avoid, overcome and navigate rough or choppy waters. Sanjay Sharma, RCIC, is comfortable and candid in discussing cross-cultural aspects and employability factors. Furthermore, He is always motivated to share his personal stories from past experiences to guide your journey.</p>
<p>As an RCIC agent, Sanjay specializes in skilled and business Immigration, and while assisting such clients, he became aware of the difficulties in obtaining and keeping foreign workers. Sanjay was born and bought up in India and has personally undergone the procedure of Canadian Skilled Immigration, which is an invaluable experience. He is a Canadian Citizen.</p>
<p>Sanjay and ABHINAV have now joined hands whereby he will act as an authorized representative for all categories of Immigration and visa clients. He brings on significant value addition to Abhinav clients and is in a position to offer case-specific recommendations for our express entry clients in the following ways</p>
<h2>For Express Entry Clients</h2>
<ul>
<li>Analyzing profiles, specifically for various <u>ongoing</u> and <u>upcoming</u> provincial nominee programs, and looking for possible customized options.</li>
<li>Advice possible small budgeted business options: Subject to eligibility, confirmation of expression of interest to go for this option, investment, and approval of the work permit, the clients may look forward to gaining additional points to get an ITA under the CRS ranking.</li>
<li>Possible affordable study abroad options: Subject to eligibility, going for this option can help qualified clients in gaining bonus points for Canadian qualifications, work permits, and in due course, points for their Canadian experience. Clients who can successfully follow the above process may gain additional points to get an ITA under the CRS ranking.</li>
</ul>
<h3>For Businessmen and Investors</h3>
<p>For Businessmen and high net worth individuals, Sanjay&rsquo;s management background with leading hospitality industry icons and being a small boutique retailer founder provides his insight to manage business applications of all kinds. This includes and is not limited to start-ups, entrepreneurs, Immigrant Investor Programs, owner-operators programs, Intra-company transfer programs. Sanjay Sharma and Team Abhinav can offer a comprehensive portfolio of business investment ideas of varied investment amounts per our client&rsquo;s capabilities, organize exploratory visits and offer all related services, including company incorporation, office space, accounting, and staffing.</p>
<h4>For All Clients</h4>
<p>Sanjay Sharma and Team Abhinav provide complete post-landing scale services and guidance, including temporary and regular accommodation arrangements, opening bank accounts, introduction to job search agencies, driving license, schooling for children, and city orientation. Above everything, Sanjay Sharma and team Abhinav provide Cultural and language affinity.</p>
</div>
</div>
		 <div class="col-md-4 col-sm-4 col-xs-12">
		 <?php include('enquiry-form.php')?>
		 </div>
                
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>