<?php include 'inc/header.php'; ?>
<div class="page-area">
    <div class="breadcumb-overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="breadcrumb">
                    <div class="bread-inner">
                        <div class="section-headline white-headline">
                            <h2>Occupation <span class="color"> List of Canada</span></h2>
                        </div>
                        <ul class="breadcrumb-bg">
                            <li class="home-bread"><a href="index.php">Home</a></li>
                            <li>Occupation List of Canada</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="team-area bg-color pd-35">
    <div class="container">
        <!-- section head -->
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-headline text-center">
                    <h3>Occupation <span class="color"> List of Canada</span></h3>
                </div>
            </div>
        </div>
        <div class="row">
		 <div class="col-md-8 col-sm-8 col-xs-12" style="box-shadow: 5px 3px 10px rgb(0 0 0 / 10%);">
<div class='text-justify innerpage-text'><h2>National Occupational Classification List</h2>
<p>Choosing the right occupation is vital to the Canada Immigration application. Your occupation holds the critical component to be eligible and score high points for the selection. All the eligible occupations for Canada PR are classified into Skilled Levels such as &lsquo;0&rsquo;, &lsquo;A,&rsquo; &lsquo;B,&rsquo; &lsquo;C&rsquo; &amp; &lsquo;D&rsquo;. These classifications have a different impact on the eligibility of the applicants.</p>
<p>&bull; Level &lsquo;0&rsquo; &ndash; Managerial Occupations<br />
&bull; Level &lsquo;A&rsquo; &ndash; Professional Occupations<br />
&bull; Level &lsquo;B&rsquo; &ndash; Technical Occupations<br />
&bull; Level &lsquo;C&rsquo; &ndash; Semi &amp; Low-Skilled Occupations<br />
&bull; Level &lsquo;D&rsquo; &ndash; Semi &amp; Low-Skilled Occupations</p>
<p>Currently, the occupations under Level &lsquo;0&rsquo;, &lsquo;A,&rsquo; and &lsquo;B&rsquo; are considered for the <a href="../canada-immigration.html" target="_blank">Canada Immigration</a> process. Below is the list of Open Occupations for Canada Immigration:</p>
<p><a href="../check-your-eligibility.html" style="padding:7px 5px ;background: #f00 !important; color: #fff; line-height: 24px; border-radius: 5px; margin-bottom: 6px;  width: 140px;" target="_blank" title="Check Your Eligibility">Check Your Eligibility</a></p>
<p><br />
<strong>NOC O Group Occupation List - Management Occupations (Skill level A)</strong></p>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">011 Administrative services managers</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../financial-managers-0111.html">0111 Financial managers</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../human-resources-managers-0112.html">0112 Human resources managers</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../purchasing-managers-0113.html">0113 Purchasing managers</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../other-administrative-services-managers-0114.html">0114 Other administrative services managers</a>&nbsp;</strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">012 Managers in financial and business services</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0121-insurance-real-estate-financial-brokerage-managers.html">0121 Insurance, real estate and financial brokerage managers</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0122-banking-credit-other-investment-managers.html">0122 Banking, credit and other investment managers&nbsp;</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0124-advertising-marketing-public-relations-managers.html">0124 Advertising, marketing and public relations managers</a><a href="../0124-advertising-marketing-public-relations-managers.html">&nbsp;</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0125-other-business-services-managers.html">0125 Other business services managers&nbsp;</a></strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">013 Managers in communication (except broadcasting)</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0131-Telecommunication-carriers-managers.html">0131 Telecommunication carriers managers</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0132-postal-courier-services-managers.html">0132 Postal and courier services managers&nbsp;</a></strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">021 Managers in engineering, architecture, science and information systems</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0211-engineering-managers.html">0211 Engineering managers</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0212-architecture-science-managers.html">0212 Architecture and science managers</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="express-entry-occupation-list.html">0213 Computer and information systems managers</a>&nbsp;</strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">031 Managers in health care</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0311-managers-health-care.html">0311Managers in health care</a></strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">041 Managers in public administration</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0411-government-managers-health-social-policy-development-program-administration.html">0411 Government Managers - Health and social policy development and program administration</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0412-government-managers-economic-analysis-policy-development-program-administration.html">0412 Government Managers - Economic analysis, policy development and program administration</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0413-government-managers-education-policy-development-program-administration.html">0413 Government Managers - Education policy development and program administration</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0414-otheranagers-in-public-administration.html">0414 Other Managers in public administration</a>&nbsp;</strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">042 Managers in education and social and community services</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0421-Administrators-post-secondary-education-vocational-training.html">0421 Administrators - post-secondary education and vocational training</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0422-school-principals-administrators-elementary-secondary-education.html">0422 School principals &amp; administrators of elementary and secondary education</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0423-managers-social-community-correctional-services.html">0423 Managers in social,community and correctional services</a>&nbsp;</strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">043 Managers in public protection services</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0431-commissioned-police-officers.html">0431 Commissioned police officers</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0432-fire-chiefs-senior-firefighting-officers.html">0432 Fire chiefs and senior firefighting officers</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0433-commissioned-officers-canadian-forces.html">0433 Commissioned officers of the Canadian Forces</a>&nbsp;</strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">051 Managers in art, culture, recreation and sport</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../051-library-archive-museum-art-gallery-managers.html">0511 Library, archive, museum and art gallery managers</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0512-managers-publishing-motion-pictures-broadcasting-performing-arts.html">0512 Managers - publishing, motion pictures, broadcasting and performing arts</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0513-recreation-sports-fitness-program-pervice-pirectors.html">0513 Recreation, sports and fitness program and service directors</a></strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">060 Corporate sales managers</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0601-corporate-sales-managers.html">0601 Corporate sales managers</a>&nbsp;</strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">062 Retail and wholesale trade managers</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0621-retail-wholesale-trade-managers.html">0621 Retail and wholesale trade managers</a>&nbsp;</strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">063 Managers in food service and accommodation</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0631-restaurant-food-service-managers.html">0631 Restaurant And Food Service Managers</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0632-accommodation-service-managers.html">0632 Accommodation Service Managers</a>&nbsp;</strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">065 Managers in customer and personal services, n.e.c.</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0651-managers-customer-personal-services.html">0651 Managers in customer and personal services, n.e.c.</a>&nbsp;</strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">071 Managers in construction and facility operation and maintenance</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0711-construction-managers.html">0711 Construction managers</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0712-home-building-renovation-managers.html">0712 Home building and renovation managers</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0714-facility-operation-maintenance-managers.html">0714 Facility operation and maintenance managers</a>&nbsp;</strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">073 Managers in transportation</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0731-Managers-transportation.html">0731 Managers in transportation</a>&nbsp;</strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">081 Managers in natural resources production and fishing</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0811-managers-natural-resources-production-fishing.html">0811 Managers in natural resources production and fishing</a>&nbsp;</strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">082 Managers in agriculture, horticulture and aquacultureure</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0821-managers-agriculture.html">0821 Managers in agriculture</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0822-managers-horticulture.html">0822 Managers in horticulture</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0823-managers-aquaculture.html">0823 Managers in aquaculture</a>&nbsp;</strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">091 Managers in manufacturing and utilities</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0911-manufacturing-managers.html">0911 Manufacturing managers</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../0912-utilities-managers.html">0912 Utilities managers</a>&nbsp;</strong></li>
</ul>
</div>
<p>&nbsp;</p>
<p><a href="../expressyourinterest.html" style="padding:7px 5px ;background: #f00 !important; color: #fff; line-height: 24px; border-radius: 5px; margin-bottom: 6px;  width: 220px;" target="_blank" title="Immigration Visa Enquiry Form">Free Profile Assessment and Visa Guidance</a></p>
<p><br />
<strong>NOC A Group Occupation List - (Occupations Usually Require University Education)</strong></p>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">111 Auditors, accountants and investment professionals</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../1111-financial-auditors-accountants.html"> 1111 Financial auditors and accountants </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../1112-financial-investment-analysts.html"> 1112 Financial and investment analysts</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../1113-securities-agents-investment-dealers-brokers.html"> 1113 Securities agents, investment dealers and brokers</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../1114-other-financial-officers.html"> 1114 Other financial officers</a><a href="#"> </a></strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">112 Human resources and business service professionals</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../1121-human-resources-professionals.html"> 1121 Human resources professionals</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../1122-professional-occupations-business-management-consulting.html"> 1122 Professional occupations in business management consulting</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../1123-professional-occupations-advertising-marketing-publicrelations.html"> 1123 Professional occupations in advertising, marketing and public relations</a><a href="#"> </a></strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">211 Physical science professionals</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2111-physicists-astronomers.html"> 2111 Physicists and astronomers</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2112-chemists.html"> 2112 Chemists</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2113-geoscientists-oceanographers.html"> 2113 Geoscientists and oceanographers</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2114-Meteorologists-climatologists.html"> 2114 Meteorologists and climatologists</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2115-other-professional-occupations-physical-sciences.html"> 2115 Other professional occupations in physical sciences</a><a href="#"> </a></strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">212 Life science professionals</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2121-biologists-related-scientists.html"> 2121 Biologists and related scientists</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2122-forestry-professionals.html"> 2122 Forestry professionals</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2123-agricultural-representatives-consultants-specialists.html"> 2123 Agricultural representatives, consultants and specialists</a><a href="#"> </a></strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">213 Civil, mechanical, electrical and chemical engineers</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2131-civil-engineers.html"> 2131 Civil engineers</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2132-mechanical-engineers.html"> 2132 Mechanical engineers</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2133-electrical-electronics-engineers.html"> 2133 Electrical and electronics engineers</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2134-chemical-engineers.html"> 2134 Chemical engineers</a><a href="#"> </a></strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">214 Other engineers</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2141-industrial-manufacturing-engineers.html">2141 Industrial and manufacturing engineers</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2142-metallurgical-materials-engineers.html">2142 Metallurgical and materials engineers</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2143-mining-engineers.html">2143 Mining engineers</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2144-geological-engineers.html">2144 Geological engineers</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2145-petroleum-engineers.html">2145 Petroleum engineers</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2146-aerospace-engineers.html">2146 Aerospace engineers</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2147-computer-engineers.html">2147 Computer engineers (except software engineers and designers)</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2148-other-professional-engineers.html">2148 Other professional engineers, n.e.c. </a></strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">215 Architects, urban planners and land surveyors</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2151-architects.html"> 2151 Architects</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2152-landscape-architects.html"> 2152 Landscape architects</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2153-urban-land-use-planners.html"> 2153 Urban and land use planners</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2154-land-surveyors.html"> 2154 Land surveyors</a><a href="#"> </a></strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">216 Mathematicians, statisticians and actuaries</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2161-mathematicians-statisticians-actuaries.html"> 2161 Mathematicians, statisticians and actuaries</a><a href="#"> </a></strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">217 Computer and information systems professionals</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2171-information-systems-analysts-consultants.html"> 2171 Information systems analysts and consultants </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2172-database-analysts-data-administrators.html"> 2172 Database analysts and data administrators</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2173-software-engineers-designers.html"> 2173 Software engineers and designers</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2174-computer-programmers-interactive-media-developers.html"> 2174 Computer programmers and interactive media developers</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2175-web-designers-developers.html"> 2175 Web designers and developers</a><a href="#"> </a></strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">311 Physicians, dentists and veterinarians</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../3111-specialist-physicians.html"> 3111 Specialist physicians</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../3112-general-practitioners-family-physicians.html"> 3112 General practitioners and family physicians</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../3113-dentists.html"> 3113 Dentists</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../3114-veterinarians.html"> 3114 Veterinarians</a><a href="#"> </a></strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">312 Optometrists, chiropractors and other health diagnosing and treating professionals</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../3121-optometrists.html">3121 Optometrists</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../3122-chiropractors.html">3122 Chiropractors</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../3124-allied-primary-health-practitioners.html">3124 Allied primary health practitioners</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../3125-other-professional-occupations-health-diagnosing-treating.html">3125 Other professional occupations in health diagnosing and treating</a>&nbsp;</strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">313 Pharmacists, dietitians and nutritionists</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../3131-pharmacists.html">3131 Pharmacists</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../3132-dietitians-nutritionists.html">3132 Dietitians and nutritionists</a>&nbsp;</strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">314 Therapy and assessment professionals</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../3141-audiologists-speech-language-pathologists.html">3141 Audiologists and speech-language pathologists</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../3142-physiotherapists.html">3142 Physiotherapists</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../3143-occupational-therapists.html">3143 Occupational therapists</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../3144-other-professional-occupations-therapy-assessment.html">3144 Other professional occupations in therapy and assessment</a>&nbsp;</strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">411 Judges, lawyers and Quebec notaries</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../4111-judges.html">4111 Judges</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../4112-lawyers-quebec-notaries.html">4112 Lawyers and Quebec notaries</a>&nbsp;</strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">415 Social and community service professionals</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../4151-psychologists.html"> 4151 Psychologists </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../4152-social-workers.html"> 4152 Social workers </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../4153-family-marriage-other-related-counsellors.html"> 4153 Family, marriage and other related counsellors </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../4154-professional-occupations-religion.html"> 4154 Professional occupations in religion </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../4155-probation-parole-officers-related-occupations.html"> 4155 Probation and parole officers and related occupations </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../4156-employment-counsellors.html"> 4156 Employment counsellors </a></strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">416 Policy and program researchers, consultants and officers</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../4161-natural-applied-science-policy-researchers-consultants-program-officers.html"> 4161 Natural and applied science policy researchers, consultants and program officers </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../4162-economists-economic-policy-researchers-analysts.html"> 4162 Economists and economic policy researchers and analysts </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../4163-business-development-officers-marketing-researchers-consultants.html"> 4163 Business development officers and marketing researchers and consultants </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../4164-social-policy-researchers-consultants-program-officers.html"> 4164 Social policy researchers, consultants and program officers</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../4165-health-policy-researchers-consultants-program-officers.html"> 4165 Health policy researchers, consultants and program officers </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../4166-education-policy-researchers-consultants-program-officers.html"> 4166 Education policy researchers, consultants and program officers </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../4167-recreation-sports-fitness-policy-researchers-consultants-program-officers.html"> 4167 Recreation, sports and fitness policy researchers, consultants and program officers</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../4168-program-officers-unique-government.html"> 4168 Program officers unique to government</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../4169-other-professional-occupations-social-science-n-e-c.html"> 4169 Other professional occupations in social science, n.e.c. </a></strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">511 Librarians, archivists, conservators and curators</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../5111-librarians.html"> 5111 Librarians</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../5112-conservators-curators.html"> 5112 Conservators and curators </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../5113-archivists.html"> 5113 Archivists </a></strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">512 Writing, translating and related communications professionals</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../5121-authors-writers.html"> 5121 Authors and writers</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../5122-editors.html"> 5122 Editors</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../5123-journalists.html"> 5123 Journalists</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../5125-translators-terminologists-interpreters.html"> 5125 Translators, terminologists and interpreters</a><a href="#"> </a></strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">513 Creative and performing artists</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../5131-producers-directors-choreographers-related-occupations.html"> 5131 Producers, directors, choreographers and related occupations</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../5132-conductors-composers-arrangers.html"> 5132 Conductors, composers and arrangers</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../5133-musicians-singers.html"> 5133 Musicians and singers</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../5134-dancers.html"> 5134 Dancers</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../5135-actors-comedians.html"> 5135 Actors and comedians</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../5136-painters-sculptors-other-visual-artists.html"> 5136 Painters, sculptors and other visual artists</a><a href="#"> </a></strong></li>
</ul>
</div>
<p><br />
<a href="authorized-representative-canada.html" style="padding:7px 5px ;background: #f00 !important; color: #fff; line-height: 24px; border-radius: 5px; margin-bottom: 6px;  width: 140px;" target="_blank" title="Our Canada RCIC Agent">Our Canada RCIC Agent</a></p>
<p><br />
<strong>NOC B Group Occupation List -&nbsp;(Occupations Usually Require College Education or Apprenticeship Training)</strong></p>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">121 Administrative services supervisors</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../1211supervisors-general-office-administrative-support-workers.html">1211 Supervisors, general office and administrative support workers</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../1212-supervisors-finance-insurance-office-workers.html">1212 Supervisors, finance and insurance office workers</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../1213-supervisors-library-correspondence-related-information-workers.html">1213 Supervisors, library, correspondence and related information workers</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../1214-supervisors-mail-message-distribution-occupations.html">1214 Supervisors, mail and message distribution occupations</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../1215-supervisors-supply-chain-tracking-scheduling-co-ordination-occupations.html">1215 Supervisors, supply chain, tracking and scheduling co-ordination occupations</a></strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">122 Administrative and regulatory occupations</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../1221-administrative-officers.html">1221 Administrative officers</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../1222-executive-assistants.html">1222 Executive assistants</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../1223-human-resources-recruitment-officers.html">1223 Human resources and recruitment officers</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../1224-property-administrators.html">1224 Property administrators</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../1225-purchasing-agents-officers.html">1225 Purchasing agents and officers</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../1226-conference-event-planners.html">1226 Conference and event planners</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../1227-court-officers-justices-peace.html">1227 Court officers and justices of the peace</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../1228-employment-insurance-immigration-border-services-revenue-officers.html">1228 Employment insurance, immigration, border services and revenue officers</a></strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">124 Office administrative assistants - general, legal and medical</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../1241-administrative-assistants.html">1241 Administrative assistants</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../1242-legal-administrative-assistants.html">1242 Legal administrative assistants</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../1243-medical-administrative-assistants.html">1243 Medical administrative assistants</a>&nbsp;</strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">125 Court reporters, transcriptionists, records management technicians and statistical officers</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../1251-court-reporters-medical-transcriptionists-related-occupations.html">1251 Court reporters, medical transcriptionists and related occupations</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../1252-health-information-management-occupations.html">1252 Health information management occupations</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../1253-records-management-technicians.html">1253 Records management technicians</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../1254-statistical-officers-related-research-support-occupations.html">1254 Statistical officers and related research support occupations</a>&nbsp;</strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">131 Finance, insurance and related business administrative occupations</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../1311-accounting-technicians-bookkeepers.html">1311 Accounting technicians and bookkeepers</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../1312-insurance-adjusters-claims-examiners.html">1312 Insurance adjusters and claims examiners</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../1313-insurance-underwriters.html">1313 Insurance underwriters</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../1314-assessors-valuators-appraisers.html">1314 Assessors, valuators and appraisers</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../1315-customs-ship-other-brokers.html">1315 Customs, ship and other brokers</a>&nbsp;</strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">221 Technical occupations in physical sciences</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2211-chemical-technologists-technicians.html"> 2211 Chemical technologists and technicians</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2212-geological-mineral-technologists-technicians.html"> 2212 Geological and mineral technologists and technicians</a> &nbsp;</strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">222 Technical occupations in life sciences</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2221-biological-technologists-technicians.html"> 2221 Biological technologists and technicians</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2222-agricultural-fish-products-inspectors.html"> 2222 Agricultural and fish products inspectors</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2223-forestry-technologists-technicians.html"> 2223 Forestry technologists and technicians</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2224-conservation-fishery-officers.html"> 2224 Conservation and fishery officers</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2225-landscape-horticulture-technicians-specialists.html"> 2225 Landscape and horticulture technicians and specialists</a> </strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">223 Technical occupations in civil, mechanical and industrial engineering</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2231-civil-engineering-technologists-technicians.html">2231 Civil engineering technologists and technicians</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2232-mechanical-engineering-technologists-technicians.html">2232 Mechanical engineering technologists and technicians</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2233-industrial-engineering-manufacturing-technologists-technicians.html">2233 Industrial engineering and manufacturing technologists and technicians</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2234-construction-estimators.html">2234 Construction estimators</a></strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">224 Technical occupations in electronics and electrical engineering</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2241-electrical-electronics-engineering-technologists-technicians.html"> 2241 Electrical and electronics engineering technologists and technicians </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2242-electronic-service-technicians-household-business-equipment.html"> 2242 Electronic service technicians (household and business equipment)</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2243-industrial-instrument-technicians-mechanics.html"> 2243 Industrial instrument technicians and mechanics</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2244-aircraft-instrument-electrical-avionics-mechanics-technicians-inspectors.html"> 2244 Aircraft instrument, electrical and avionics mechanics, technicians and inspectors</a><a href="#"> </a></strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">225 Technical occupations in architecture, drafting, surveying, geomatics and meteorology</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2251-architectural-technologists-technicians.html"> 2251 Architectural technologists and technicians</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2252-industrial-designers.html"> 2252 Industrial designers</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2253-drafting-technologists-technicians.html"> 2253 Drafting technologists and technicians</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2254-land-survey-technologists-technicians.html"> 2254 Land survey technologists and technicians</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2255-technical-occupations-geomatics-meteorology.html"> 2255 Technical occupations in geomatics and meteorology</a><a href="#"> </a></strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">226 Other technical inspectors and regulatory officers</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2261-non-destructive-testers-inspection-technicians.html">2261 Non-destructive testers and inspection technicians</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2262-engineering-inspectors-regulatory-officers.html">2262 Engineering inspectors and regulatory officers</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2263-inspectors-public-environmental-health-occupational-health-safety.html">2263 Inspectors in public and environmental health and occupational health and safety</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2264-construction-inspectors.html">2264 Construction inspectors</a>&nbsp;</strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">227 Transportation officers and controllers</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2271-air-pilots-flight-engineers-flying-instructors.html"> 2271 Air pilots, flight engineers and flying instructors </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2272-air-traffic-controllers-related-occupations.html"> 2272 Air traffic controllers and related occupations </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2273-deck-officers-water-transport.html"> 2273 Deck officers, water transport</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2274-engineer-officers-water-transport.html"> 2274 Engineer officers, water transport </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2275-railway-traffic-controllers-marine-traffic-regulators.html"> 2275 Railway traffic controllers and marine traffic regulators</a><a href="#"> </a></strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">228 Technical occupations in computer and information systems</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2281-computer-network-technicians.html">2281 Computer network technicians</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2282-user-support-technicians.html">2282 User support technicians</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../2283-information-systems-testing-technicians.html">2283 Information systems testing technicians</a></strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">321 Medical technologists and technicians (except dental health)</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../3211-medical-laboratory-technologists.html">3211 Medical laboratory technologists</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../3212-medical-laboratory-technicians-pathologists-assistants.html">3212 Medical laboratory technicians and pathologists&#39; assistants</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../3213-animal-health-technologists-veterinary-technicians.html">3213 Animal health technologists and veterinary technicians</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../3214-respiratory-therapists-clinical-perfusionists-cardiopulmonary-technologists.html">3214 Respiratory therapists, clinical perfusionists and cardiopulmonary technologists</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../3215-medical-radiation-technologists.html">3215 Medical radiation technologists</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../3216-medical-sonographers.html">3216 Medical sonographers</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../3217-cardiology-technologists-electrophysiological-diagnostic-technologists-n-e-c..html">3217 Cardiology technologists and electrophysiological diagnostic technologists, n.e.c.</a>&nbsp;</strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../3219-other-medical-technologists-technicians-except-dental-health.html">3219 Other medical technologists and technicians (except dental health)</a>&nbsp;</strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">322 Technical occupations in dental health care</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../3221-denturists.html">3221 Denturists</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../3222-dental-hygienists-dental-therapists.html">3222 Dental hygienists and dental therapists</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../3223-dental-technologists-technicians-laboratory-assistants.html">3223 Dental technologists, technicians and laboratory assistants</a></strong></li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">323 Other technical occupations in health care</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../3231-opticians.html">3231 Opticians</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../3232-practitioners-natural-healing.html">3232 Practitioners of natural healing</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../3233-licensed-practical-nurses.html">3233 Licensed practical nurses</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../3234-paramedical-occupations.html">3234 Paramedical occupations</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../3236-massagetherapists.html">3236 Massage therapists</a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../3237-othertechnical-occupations-therapy-assessment.html">3237 Other technical occupations in therapy and assessment</a></strong><br />
&nbsp;</li>
</ul>
</div>
<p><strong><a href="express-entry-occupation-list.html" onClick="if (!window.__cfRLUnblockHandlers) return false; $(this).parent().parent().next('div').toggle();return false;" data-cf-modified-5ac4df3d84c84f2093356cad-="">421 Paraprofessional occupations in legal, social, community and education services</a></strong></p>
<div class="lihide" style="display:none">
<ul>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../4211-paralegalandrelatedoccupations.html"> 4211 Paralegal and related occupations</a><a href="#"> </a></strong></li>
<li class="menu2" style="margin-left: 10px;"><strong>&raquo; <a href="../4212-social-community-service-workers.html"> 4212 Social and community service workers</a></strong></li>
</ul>
</div>
</div>
</div>
		 <div class="col-md-4 col-sm-4 col-xs-12">
		 <?php include('enquiry-form.php')?>
		 </div>
                
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>