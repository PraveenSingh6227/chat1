<?php include 'inc/header.php'; ?>
<div class="page-area">
    <div class="breadcumb-overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="breadcrumb">
                    <div class="bread-inner">
                        <div class="section-headline white-headline">
                            <h2>New South Wales Occupation List  <span class="color">  for Subclass 190</span></h2>
                        </div>
                        <ul class="breadcrumb-bg">
                            <li class="home-bread"><a href="index.php">Home</a></li>
                            <li>New South Wales Occupation List for Subclass 190</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="team-area bg-color pd-35">
    <div class="container">
        <!-- section head -->
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-headline text-center">
                    <h3>New South Wales Occupation List  <span class="color">  for Subclass 190</span></h3>
                </div>
            </div>
        </div>
        <div class="row">
		 <div class="col-md-8 col-sm-8 col-xs-12" style="box-shadow: 5px 3px 10px rgb(0 0 0 / 10%);">
<div class='text-justify innerpage-text'><p>New South Wales has begun the intake for skilled immigration program for Financial Year 2018-19. The NSW 190 invitation round is expected to receive qualified immigrants with high scores in the occupations summarized on NSW 190 occupation list 2018. In order to gain more highly&nbsp;<a href="../australia-immigration/australia-skilled-nominated-subclass-190-immigration-visa.html" target="_blank">skilled immigrants under subclass 190</a>, the state is open throughout the year for selection of candidates under the New South Wales Nomination Program (190).<br />
<br />
Candidates whose profile is in high demand in NSW, can match up with the skills required in NSW as shown in the New South Wales Occupation List (190), would receive the invite from the state for nomination under the subclass 190 (skilled nominated visa).<br />
<br />
New South Wales has a selection-based invitation process, where the state elects and invites suitable immigrants from Skill Select to apply for state nominations under the NSW Occupation List - 190 to ensure right allocation of resources is done according to the need of the state economy.<br />
<br />
You can match your profile against the available job-list in below mentioned NSW 190 Occupation List, which includes the priority occupations through which the state invites candidates under visa subclass 190.<br />
&nbsp;</p>
<table border="0" bordercolor="#CCC" cellpadding="0" cellspacing="0">
<tbody>
<tr bgcolor="#F00" style="color: rgb(255, 255, 255);">
<td><strong>ANZSCO Code</strong></td>
<td><strong>Nominated Occupation</strong></td>
<td><strong>Field</strong></td>
</tr>
<tr>
<td>133111</td>
<td>Construction Project Manager</td>
<td>Other</td>
</tr>
<tr>
<td>133211</td>
<td>Engineering Manager</td>
<td>Other</td>
</tr>
<tr>
<td>134111</td>
<td>Child Care Centre Manager</td>
<td>Education</td>
</tr>
<tr>
<td>134212</td>
<td>Nursing Clinical Director</td>
<td>Health</td>
</tr>
<tr>
<td>134214</td>
<td>Welfare Centre Manager</td>
<td>Health</td>
</tr>
<tr>
<td>221111</td>
<td>Accountant (General)</td>
<td>Business &amp; Finance</td>
</tr>
<tr>
<td>221112</td>
<td>Management Accountant</td>
<td>Business &amp; Finance</td>
</tr>
<tr>
<td>221113</td>
<td>Taxation Accountant</td>
<td>Business &amp; Finance</td>
</tr>
<tr>
<td>221213</td>
<td>External Auditor</td>
<td>Business &amp; Finance</td>
</tr>
<tr>
<td>221214</td>
<td>Internal Auditor</td>
<td>Business &amp; Finance</td>
</tr>
<tr>
<td>224111</td>
<td>Actuary</td>
<td>Business &amp; Finance</td>
</tr>
<tr>
<td>224511</td>
<td>Land Economist</td>
<td>Other</td>
</tr>
<tr>
<td>224512</td>
<td>Valuer</td>
<td>Other</td>
</tr>
<tr>
<td>224711</td>
<td>Management Consultant</td>
<td>Business &amp; Finance</td>
</tr>
<tr>
<td>232111</td>
<td>Architect</td>
<td>Other</td>
</tr>
<tr>
<td>232112</td>
<td>Landscape Architect</td>
<td>Engineers</td>
</tr>
<tr>
<td>233111</td>
<td>Chemical Engineer</td>
<td>Engineers</td>
</tr>
<tr>
<td>233211</td>
<td>Civil Engineer</td>
<td>Engineers</td>
</tr>
<tr>
<td>233212</td>
<td>Geotechnical Engineer</td>
<td>Engineers</td>
</tr>
<tr>
<td>233213</td>
<td>Quantity Surveyor</td>
<td>Engineers</td>
</tr>
<tr>
<td>233214</td>
<td>Structural Engineer</td>
<td>Engineers</td>
</tr>
<tr>
<td>233215</td>
<td>Transport Engineer</td>
<td>Engineers</td>
</tr>
<tr>
<td>233311</td>
<td>Electrical Engineer</td>
<td>Engineers</td>
</tr>
<tr>
<td>233411</td>
<td>Electronics Engineer</td>
<td>Engineers</td>
</tr>
<tr>
<td>233511</td>
<td>Industrial Engineer</td>
<td>Engineers</td>
</tr>
<tr>
<td>233512</td>
<td>Mechanical Engineer</td>
<td>Engineers</td>
</tr>
<tr>
<td>233513</td>
<td>Production or Plant Engineer</td>
<td>Engineers</td>
</tr>
<tr>
<td>233911</td>
<td>Aeronautical Engineer</td>
<td>Engineers</td>
</tr>
<tr>
<td>233913</td>
<td>Biomedical Engineer</td>
<td>Engineers</td>
</tr>
<tr>
<td>233915</td>
<td>Environmental Engineer</td>
<td>Engineers</td>
</tr>
<tr>
<td>233916</td>
<td>Naval Architect</td>
<td>Engineers</td>
</tr>
<tr>
<td>234112</td>
<td>Agricultural Scientist</td>
<td>Science</td>
</tr>
<tr>
<td>234611</td>
<td>Medical Laboratory Scientist</td>
<td>Science</td>
</tr>
<tr>
<td>234711</td>
<td>Veterinarian</td>
<td>Science</td>
</tr>
<tr>
<td>234914</td>
<td>Physicist (medical physicist only)</td>
<td>Science</td>
</tr>
<tr>
<td>241111</td>
<td>Early Childhood (Pre-Primary School) Teacher</td>
<td>Education</td>
</tr>
<tr>
<td>241411</td>
<td>Secondary School&nbsp; Teacher</td>
<td>Education</td>
</tr>
<tr>
<td>251211</td>
<td>Medical Diagnostic Radiographer</td>
<td>Health</td>
</tr>
<tr>
<td>251212</td>
<td>Medical Radiation Therapist</td>
<td>Health</td>
</tr>
<tr>
<td>251213</td>
<td>Nuclear Medicine Technologist</td>
<td>Health</td>
</tr>
<tr>
<td>251214</td>
<td>Sonographer</td>
<td>Health</td>
</tr>
<tr>
<td>251411</td>
<td>Optometrist</td>
<td>Health</td>
</tr>
<tr>
<td>252411</td>
<td>Occupational Therapist</td>
<td>Health</td>
</tr>
<tr>
<td>252511</td>
<td>Physiotherapist</td>
<td>Health</td>
</tr>
<tr>
<td>252611</td>
<td>Podiatrist</td>
<td>Health</td>
</tr>
<tr>
<td>253411</td>
<td>Psychiatrist</td>
<td>Health</td>
</tr>
<tr>
<td>253912</td>
<td>Emergency Medicine Specialist</td>
<td>Health</td>
</tr>
<tr>
<td>253915</td>
<td>Pathologist</td>
<td>Health</td>
</tr>
<tr>
<td>253917</td>
<td>Diagnostic and Interventional Radiologist</td>
<td>Health</td>
</tr>
<tr>
<td>254111</td>
<td>Midwife</td>
<td>Health</td>
</tr>
<tr>
<td>254412</td>
<td>Registered Nurse (Aged Care)</td>
<td>Health</td>
</tr>
<tr>
<td>254413</td>
<td>Registered Nurse (Child and Family Health)</td>
<td>Health</td>
</tr>
<tr>
<td>254414</td>
<td>Registered Nurse (Community Health)</td>
<td>Health</td>
</tr>
<tr>
<td>254415</td>
<td>Registered Nurse (Critical Care and Emergency)</td>
<td>Health</td>
</tr>
<tr>
<td>254417</td>
<td>Registered Nurse (Disability and Rehabilitation)</td>
<td>Health</td>
</tr>
<tr>
<td>254418</td>
<td>Registered Nurse (Medical)</td>
<td>Health</td>
</tr>
<tr>
<td>254421</td>
<td>Registered Nurse (Medical Practice)</td>
<td>Health</td>
</tr>
<tr>
<td>254422</td>
<td>Registered Nurse (Mental Health)</td>
<td>Health</td>
</tr>
<tr>
<td>254423</td>
<td>Registered Nurse (Perioperative)</td>
<td>Health</td>
</tr>
<tr>
<td>254424</td>
<td>Registered Nurse (Surgical)</td>
<td>Health</td>
</tr>
<tr>
<td>254425</td>
<td>Registered Nurse (Paediatric)</td>
<td>Health</td>
</tr>
<tr>
<td>254499</td>
<td>Registered Nurses nec</td>
<td>Health</td>
</tr>
<tr>
<td>261111</td>
<td>ICT business Analyst</td>
<td>ICT</td>
</tr>
<tr>
<td>261112</td>
<td>Systems Analyst</td>
<td>ICT</td>
</tr>
<tr>
<td>261311</td>
<td>Analyst Programmer</td>
<td>ICT</td>
</tr>
<tr>
<td>261312</td>
<td>Developer Programmer</td>
<td>ICT</td>
</tr>
<tr>
<td>261313</td>
<td>Software Engineer</td>
<td>ICT</td>
</tr>
<tr>
<td>262112</td>
<td>ICT Security Specialist</td>
<td>ICT</td>
</tr>
<tr>
<td>263111</td>
<td>Computer Network and Systems Engineer</td>
<td>ICT</td>
</tr>
<tr>
<td>263311</td>
<td>Telecommunications Engineer</td>
<td>ICT</td>
</tr>
<tr>
<td>263312</td>
<td>Telecommunications Network Engineer</td>
<td>ICT</td>
</tr>
<tr>
<td>271111</td>
<td>Barrister</td>
<td>Business &amp; Finance</td>
</tr>
<tr>
<td>271311</td>
<td>Solicitor</td>
<td>Business &amp; Finance</td>
</tr>
<tr>
<td>272311</td>
<td>Clinical Psychologist</td>
<td>Social &amp; Welfare Professionals</td>
</tr>
<tr>
<td>272312</td>
<td>Educational Psychologist</td>
<td>Social &amp; Welfare Professionals</td>
</tr>
<tr>
<td>272399</td>
<td>Psychologists nec</td>
<td>Health</td>
</tr>
<tr>
<td>272511</td>
<td>Social Worker</td>
<td>Social &amp; Welfare Professionals</td>
</tr>
<tr>
<td>312211</td>
<td>Civil Engineering Draftsperson</td>
<td>Engineers</td>
</tr>
<tr>
<td>312212</td>
<td>Civil Engineering Technician</td>
<td>Engineers</td>
</tr>
<tr>
<td>312311</td>
<td>Electrical Engineering Draftsperson</td>
<td>Engineers</td>
</tr>
<tr>
<td>312312</td>
<td>Electrical Engineering Technician</td>
<td>Engineers</td>
</tr>
<tr>
<td>321111</td>
<td>Automotive Electrician</td>
<td>Automotive Trades</td>
</tr>
<tr>
<td>321211</td>
<td>Motor Mechanic (General)</td>
<td>Automotive Trades</td>
</tr>
<tr>
<td>321212</td>
<td>Diesel Motor Mechanic</td>
<td>Automotive Trades</td>
</tr>
<tr>
<td>321213</td>
<td>Motorcycle Mechanic</td>
<td>Automotive Trades</td>
</tr>
<tr>
<td>321214</td>
<td>Small Engine Mechanic</td>
<td>Automotive Trades</td>
</tr>
<tr>
<td>322211</td>
<td>Sheetmetal Trades Worker</td>
<td>Metal Trades</td>
</tr>
<tr>
<td>322311</td>
<td>Metal Fabricator</td>
<td>Metal Trades</td>
</tr>
<tr>
<td>322313</td>
<td>Welder (First Class)</td>
<td>Metal Trades</td>
</tr>
<tr>
<td>323211</td>
<td>Fitter (General)</td>
<td>Metal Trades</td>
</tr>
<tr>
<td>323212</td>
<td>Fitter and Turner</td>
<td>Metal Trades</td>
</tr>
<tr>
<td>323213</td>
<td>Fitter-Welder</td>
<td>Metal Trades</td>
</tr>
<tr>
<td>323214</td>
<td>Metal Machinist (First Class)</td>
<td>Metal Trades</td>
</tr>
<tr>
<td>323313</td>
<td>Locksmith</td>
<td>Metal Trades</td>
</tr>
<tr>
<td>324111</td>
<td>Panelbeater</td>
<td>Automotive Trades</td>
</tr>
<tr>
<td>331111</td>
<td>Bricklayer</td>
<td>Building Trades</td>
</tr>
<tr>
<td>331112</td>
<td>Stonemason</td>
<td>Building Trades</td>
</tr>
<tr>
<td>331211</td>
<td>Carpenter and Joiner</td>
<td>Building Trades</td>
</tr>
<tr>
<td>331212</td>
<td>Carpenter</td>
<td>Building Trades</td>
</tr>
<tr>
<td>331213</td>
<td>Joiner</td>
<td>Building Trades</td>
</tr>
<tr>
<td>332211</td>
<td>Painting trades workers</td>
<td>Building Trades</td>
</tr>
<tr>
<td>333111</td>
<td>Glazier</td>
<td>Other</td>
</tr>
<tr>
<td>333211</td>
<td>Fibrous Plasterer</td>
<td>Building Trades</td>
</tr>
<tr>
<td>333212</td>
<td>Solid Plasterer</td>
<td>Building Trades</td>
</tr>
<tr>
<td>333411</td>
<td>Wall and Floor Tiler</td>
<td>Building Trades</td>
</tr>
<tr>
<td>334111</td>
<td>Plumber (General)</td>
<td>Building Trades</td>
</tr>
<tr>
<td>334112</td>
<td>Airconditioning and Mechanical Services Plumber</td>
<td>Building Trades</td>
</tr>
<tr>
<td>334113</td>
<td>Drainer</td>
<td>Building Trades</td>
</tr>
<tr>
<td>334114</td>
<td>Gasfitter</td>
<td>Building Trades</td>
</tr>
<tr>
<td>334115</td>
<td>Roof plumber</td>
<td>Building Trades</td>
</tr>
<tr>
<td>341111</td>
<td>Electrician (General)</td>
<td>Building Trades</td>
</tr>
<tr>
<td>341113</td>
<td>Lift Mechanic</td>
<td>Building Trades</td>
</tr>
<tr>
<td>342111</td>
<td>Airconditioning and Refrigeration Mechanic</td>
<td>Building Trades</td>
</tr>
<tr>
<td>342212</td>
<td>Technical Cable Jointer</td>
<td>Other</td>
</tr>
<tr>
<td>342313</td>
<td>Electronic Equipment Trades Worker</td>
<td>Other</td>
</tr>
<tr>
<td>351111</td>
<td>Baker</td>
<td>Tourism &amp; Hospitality</td>
</tr>
<tr>
<td>351311</td>
<td>Chef (excludes positions in Fast Food or Takeaway Food Service)</td>
<td>Tourism &amp; Hospitality</td>
</tr>
<tr>
<td>394111</td>
<td>Cabinetmaker</td>
<td>Building Trades</td>
</tr>
<tr>
<td>411411</td>
<td>Enrolled Nurse</td>
<td>Health</td>
</tr>
</tbody> 
</table>
<p>&nbsp;</p>
</div>
</div>
		 <div class="col-md-4 col-sm-4 col-xs-12">
		 <?php include('enquiry-form.php')?>
		 </div>
                
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>