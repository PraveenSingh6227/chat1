<?php include 'inc/header.php'; ?>
<div class="page-area">
    <div class="breadcumb-overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="breadcrumb">
                    <div class="bread-inner">
                        <div class="section-headline white-headline">
                            <h2>South Australia Supplementary  <span class="color">  Skilled List</span></h2>
                        </div>
                        <ul class="breadcrumb-bg">
                            <li class="home-bread"><a href="index.php">Home</a></li>
                            <li>South Australia Supplementary Skilled List</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="team-area bg-color pd-35">
    <div class="container">
        <!-- section head -->
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-headline text-center">
                    <h3>South Australia Supplementary  <span class="color">  Skilled List</span></h3>
                </div>
            </div>
        </div>
        <div class="row">
		 <div class="col-md-8 col-sm-8 col-xs-12" style="box-shadow: 5px 3px 10px rgb(0 0 0 / 10%);">
<div class='text-justify innerpage-text'><h2>State Nominated Occupation Lists (Supplementary Skilled List)</h2>
<p>List current as of 12 March 2021<br />
<br />
The Supplementary Skilled List reflects all occupations available on the Commonwealth&rsquo;s Consolidated Sponsored Occupations List (CSOL) that are not available on <a href="../australia-immigration/south-australia-state-nominated-occupation-list.html" target="_blank">South Australia State Nomination Skilled Occupation List</a>. These occupations are only available if you meet the additional requirements detailed on the Skilled Nomination Requirements Page.<br />
<br />
Please note that some occupations in this list may have certain barriers to being immediately eligible for employment. Please research your employment opportunities thoroughly. It is your responsibility to determine if your occupation requires further training, or if it has registration, licencing, residency or other requirements before you can work in South Australia. You may also be able to use your skills in related skilled occupations.</p>
<table border="1" bordercolor="#CCC" cellpadding="8" cellspacing="0" height="100%" width="90%">
<tbody>
<tr bgcolor="#F00" style="color:#FFF">
<td width="183">ANZSCO Code</td>
<td width="373">Occupation</td>
<td width="1493">Additional Requirements</td>
<td width="64">Skills Assessment Authority</td>
</tr>
<tr>
<td colspan="4"><strong>12 Farmers and Farm Managers</strong></td>
</tr>
<tr>
<td>121111</td>
<td>Aquaculture Farmer</td>
<td>Competent English; Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>121311</td>
<td>Apiarist</td>
<td>Competent English; Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>121314</td>
<td>Deer Farmer</td>
<td>Competent English; Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>121315</td>
<td>Goat Farmer</td>
<td>Competent English; Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>121316</td>
<td>Horse Breeder</td>
<td>Competent English; Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>121399</td>
<td>Livestock Farmers nec</td>
<td>Competent English; Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td colspan="4"><strong>13 Specialist Managers</strong></td>
</tr>
<tr>
<td>132411</td>
<td>Policy and Planning Manager</td>
<td>Proficient English (or Proficient Plus overall); Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>134111</td>
<td>Child Care Centre Manager</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>TRA</td>
</tr>
<tr>
<td>134311</td>
<td>School Principal</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>134412</td>
<td>Regional Education Manager</td>
<td>Proficient English (or Proficient Plus overall); Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>134499</td>
<td>Education Managers nec</td>
<td>Proficient English (or Proficient Plus overall); Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>139912</td>
<td>Environmental Manager</td>
<td>Proficient English (or Proficient Plus overall); Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>139913</td>
<td>Laboratory Manager</td>
<td>Proficient English (or Proficient Plus overall); Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>139915</td>
<td>Sports Administrator</td>
<td>Proficient English (or Proficient Plus overall); Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td colspan="4"><strong>14 Hospitality, Retail &amp; Service Managers</strong></td>
</tr>
<tr>
<td>141211</td>
<td>Caravan Park and Camping Ground Manager</td>
<td>Competent Plus English (or Proficient overall); Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>142115</td>
<td>Post Office Manager</td>
<td>Competent Plus English (or Proficient overall); Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>149111</td>
<td>Amusement Centre Manager</td>
<td>Competent Plus English (or Proficient overall); Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>149112</td>
<td>Fitness Centre Manager</td>
<td>Competent Plus English (or Proficient overall); Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>149113</td>
<td>Sports Centre Manager</td>
<td>Competent Plus English (or Proficient overall); Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>149413</td>
<td>Transport Company Manager</td>
<td>Competent Plus English (or Proficient overall); Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>149912</td>
<td>Cinema or Theatre Manager</td>
<td>Competent Plus English (or Proficient overall); Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td colspan="4"><strong>21 Arts &amp; Media Professionals</strong></td>
</tr>
<tr>
<td>211112</td>
<td>Dancer or Choreographer</td>
<td>Competent English</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>211212</td>
<td>Music Director</td>
<td>Competent English</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>211213</td>
<td>Musician (Instrumental)</td>
<td>Competent English; Offshore applicants Provisional 489 visa only; Preparedness to self-employ</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>211299</td>
<td>Music Professionals nec</td>
<td>Competent English; Offshore applicants Provisional 489 visa only; Preparedness to self-employ</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>212111</td>
<td>Artistic Director</td>
<td>Competent English</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>212212</td>
<td>Book or Script Editor</td>
<td>Proficient Plus English (or Superior overall)</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>212312</td>
<td>Director (Film, Television, Radio or Stage)</td>
<td>Competent English</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>212315</td>
<td>Program Director (Television or Radio)</td>
<td>Competent English</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>212316</td>
<td>Stage Manager</td>
<td>Competent English</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>212317</td>
<td>Technical Director</td>
<td>Competent English</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>212318</td>
<td>Video Producer</td>
<td>Competent English</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>212411</td>
<td>Copywriter</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>212412</td>
<td>Newspaper or Periodical Editor</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>212413</td>
<td>Print Journalist</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>212415</td>
<td>Technical Writer</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>212416</td>
<td>Television Journalist</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>212499</td>
<td>Journalists and Other Writers nec</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>VETASSESS</td>
</tr>
<tr>
<td colspan="4"><strong>22 Business, Human Resource &amp; Marketing Professionals</strong></td>
</tr>
<tr>
<td>221111</td>
<td>Accountant (General)</td>
<td>Competent Plus English (or Proficient overall); Offshore applicants Provisional 489 visa only; 3 years&#39; work experience in field; South Australian graduates must be currently working in their field in South Australia for the last 12 months</td>
<td>CPA / CA / IPA</td>
</tr>
<tr>
<td>221112</td>
<td>Management Accountant</td>
<td>Competent Plus English (or Proficient overall); Offshore applicants Provisional 489 visa only; 3 years&#39; work experience in field; South Australian graduates must be currently working in their field in South Australia for the last 12 months</td>
<td>CPA / CA / IPA</td>
</tr>
<tr>
<td>221113</td>
<td>Taxation Accountant</td>
<td>Competent Plus English (or Proficient overall); Offshore applicants Provisional 489 visa only; 3 years&#39; work experience in field; South Australian graduates must be currently working in their field in South Australia for the last 12 months</td>
<td>CPA / CA / IPA</td>
</tr>
<tr>
<td>221211</td>
<td>Company Secretary</td>
<td>Competent Plus English (or Proficient overall); Offshore applicants Provisional 489 visa only; 3 years&#39; work experience in field; South Australian graduates must be currently working in their field in South Australia for the last 12 months</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>221213</td>
<td>External Auditor</td>
<td>Competent Plus English (or Proficient overall); Offshore applicants Provisional 489 visa only; 3 years&#39; work experience in field; South Australian graduates must be currently working in their field in South Australia for the last 12 months</td>
<td>CPA / CA / IPA</td>
</tr>
<tr>
<td>221214</td>
<td>Internal Auditor</td>
<td>Competent Plus English (or Proficient overall); Offshore applicants Provisional 489 visa only; 3 years&#39; work experience in field; South Australian graduates must be currently working in their field in South Australia for the last 12 months</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>222111</td>
<td>Commodities Trader</td>
<td>Competent Plus English (or Proficient overall); Research job opportunities for your particular specialisation</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>222199</td>
<td>Financial Brokers nec</td>
<td>Competent Plus English (or Proficient overall); Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>222211</td>
<td>Financial Market Dealer</td>
<td>Competent Plus English (or Proficient overall)</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>222213</td>
<td>Stockbroking Dealer</td>
<td>Competent Plus English (or Proficient overall)</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>222299</td>
<td>Financial Dealers nec</td>
<td>Competent Plus English (or Proficient overall)</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>222311</td>
<td>Financial Investment Adviser</td>
<td>Competent Plus English (or Proficient overall)</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>222312</td>
<td>Financial Investment Manager</td>
<td>Competent Plus English (or Proficient overall)</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>223111</td>
<td>Human Resource Adviser</td>
<td>Proficient English (or Proficient Plus overall); Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>223113</td>
<td>Workplace Relations Adviser</td>
<td>Proficient English (or Proficient Plus overall); Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>223211</td>
<td>ICT Trainer</td>
<td>Proficient English (or Proficient Plus overall); Offshore applicants Provisional 489 visa only; See additional instructions; 75 points required</td>
<td>ACS</td>
</tr>
<tr>
<td>224111</td>
<td>Actuary</td>
<td>Competent Plus English (or Proficient overall)</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>224212</td>
<td>Gallery or Museum Curator</td>
<td>Competent Plus English (or Proficient overall)</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>224213</td>
<td>Health Information Manager</td>
<td>Competent Plus English (or Proficient overall); Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>224412</td>
<td>Policy Analyst</td>
<td>Competent Plus English (or Proficient overall); Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>224511</td>
<td>Land Economist</td>
<td>Competent Plus English (or Proficient overall)</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>224512</td>
<td>Valuer</td>
<td>Competent Plus English (or Proficient overall)</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>224611</td>
<td>Librarian</td>
<td>Competent Plus English (or Proficient overall)</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>224914</td>
<td>Patents Examiner</td>
<td>Competent Plus English (or Proficient overall)</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>225112</td>
<td>Market Research Analyst</td>
<td>Competent Plus English (or Proficient overall); Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>225113</td>
<td>Marketing Specialist</td>
<td>Competent Plus English (or Proficient overall); Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td colspan="4"><strong>23 Design, Engineering, Science &amp; Transport Professionals</strong></td>
</tr>
<tr>
<td>231111</td>
<td>Aeroplane Pilot</td>
<td>Proficient English (or Proficient Plus overall); Provisional 489 visa only</td>
<td>CASA</td>
</tr>
<tr>
<td>231113</td>
<td>Flying Instructor</td>
<td>Proficient English (or Proficient Plus overall); Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>231114</td>
<td>Helicopter Pilot</td>
<td>Proficient English (or Proficient Plus overall); Provisional 489 visa only</td>
<td>CASA</td>
</tr>
<tr>
<td>232112</td>
<td>Landscape Architect</td>
<td>Competent Plus English (or Proficient overall)</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>232213</td>
<td>Cartographer</td>
<td>Competent Plus English (or Proficient overall)</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>232214</td>
<td>Other Spatial Scientist</td>
<td>Competent Plus English (or Proficient overall)</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>232311</td>
<td>Fashion Designer</td>
<td>Competent English; Offshore applicants Provisional 489 visa only; Preparedness to self-employ</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>232313</td>
<td>Jewellery Designer</td>
<td>Competent English; Offshore applicants Provisional 489 visa only; Preparedness to self-employ</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>232511</td>
<td>Interior Designer</td>
<td>Competent English; Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>233112</td>
<td>Materials Engineer</td>
<td>Proficient English (or Proficient Plus overall); Offshore applicants Provisional 489 visa only; 3 years&#39; work experience in field</td>
<td>Engineers Australia</td>
</tr>
<tr>
<td>233911</td>
<td>Aeronautical Engineer</td>
<td>Proficient English (or Proficient Plus overall); Offshore applicants Provisional 489 visa only; 3 years&#39; work experience in field</td>
<td>Engineers Australia</td>
</tr>
<tr>
<td>233912</td>
<td>Agricultural Engineer</td>
<td>Proficient English (or Proficient Plus overall); Offshore applicants Provisional 489 visa only; 3 years&#39; work experience in field</td>
<td>Engineers Australia</td>
</tr>
<tr>
<td>233913</td>
<td>Biomedical Engineer</td>
<td>Proficient English (or Proficient Plus overall); Offshore applicants Provisional 489 visa only; 3 years&#39; work experience in field</td>
<td>Engineers Australia</td>
</tr>
<tr>
<td>233914</td>
<td>Engineering Technologist</td>
<td>Proficient English (or Proficient Plus overall); Offshore applicants Provisional 489 visa only; 3 years&#39; work experience in field</td>
<td>Engineers Australia</td>
</tr>
<tr>
<td>233915</td>
<td>Environmental Engineer</td>
<td>Proficient English (or Proficient Plus overall); Offshore applicants Provisional 489 visa only; 3 years&#39; work experience in field</td>
<td>Engineers Australia</td>
</tr>
<tr>
<td>233916</td>
<td>Naval Architect</td>
<td>Proficient English (or Proficient Plus overall); Offshore applicants Provisional 489 visa only; 3 years&#39; work experience in field</td>
<td>Engineers Australia</td>
</tr>
<tr>
<td>234311</td>
<td>Conservation Officer</td>
<td>Competent English; Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>234312</td>
<td>Environmental Consultant</td>
<td>Proficient English (or Proficient Plus overall); Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>234313</td>
<td>Environmental Research Scientist</td>
<td>Proficient English (or Proficient Plus overall); Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>234399</td>
<td>Environmental Scientists nec</td>
<td>Proficient English (or Proficient Plus overall); Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>234711</td>
<td>Veterinarian</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>AVBC</td>
</tr>
<tr>
<td>234911</td>
<td>Conservator</td>
<td>Proficient English (or Proficient Plus overall); Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>234912</td>
<td>Metallurgist</td>
<td>Proficient English (or Proficient Plus overall); Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>234913</td>
<td>Meteorologist</td>
<td>Proficient English (or Proficient Plus overall); Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>234915</td>
<td>Exercise Physiologist</td>
<td>Competent Plus English (or Proficient overall); Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>234999</td>
<td>Natural and Physical Science Professionals nec</td>
<td>Proficient English (or Proficient Plus overall); Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td colspan="4"><strong>24 Education Professionals</strong></td>
</tr>
<tr>
<td>241213</td>
<td>Primary School Teacher</td>
<td>Proficient English (or Proficient Plus overall); Offshore applicants Provisional 489 visa only</td>
<td>AITSL</td>
</tr>
<tr>
<td>241311</td>
<td>Middle School Teacher</td>
<td>Proficient English (or Proficient Plus overall); Offshore applicants Provisional 489 visa only</td>
<td>AITSL</td>
</tr>
<tr>
<td>241411</td>
<td>Secondary School Teacher</td>
<td>Proficient English (or Proficient Plus overall); Offshore applicants Provisional 489 visa only</td>
<td>AITSL</td>
</tr>
<tr>
<td>242111</td>
<td>University Lecturer</td>
<td>Proficient English (or Proficient Plus overall); Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>242211</td>
<td>Vocational Education Teacher (Non-Trades)</td>
<td>Proficient English (or Proficient Plus overall); Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>249111</td>
<td>Education Adviser</td>
<td>Proficient English (or Proficient Plus overall); Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>249211</td>
<td>Art Teacher (Private Tuition)</td>
<td>Competent Plus English (or Proficient overall); Offshore applicants Provisional 489 visa only; Preparedness to self-employ</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>249311</td>
<td>Teacher of English to Speakers of Other Languages</td>
<td>Proficient English (or Proficient Plus overall); Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td colspan="4"><strong>25 Health Professionals</strong></td>
</tr>
<tr>
<td>251111</td>
<td>Dietitian</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>DAA</td>
</tr>
<tr>
<td>251112</td>
<td>Nutritionist</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>251212</td>
<td>Medical Radiation Therapist</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>ASMIRT</td>
</tr>
<tr>
<td>251213</td>
<td>Nuclear Medicine Technologist</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>ANZSNM</td>
</tr>
<tr>
<td>251311</td>
<td>Environmental Health Officer</td>
<td>Proficient English (or Proficient Plus overall); Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>251412</td>
<td>Orthoptist</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>251511</td>
<td>Hospital Pharmacist</td>
<td>Proficient English (or Proficient Plus overall); Offshore applicants Provisional 489 visa only</td>
<td>APharmC</td>
</tr>
<tr>
<td>251512</td>
<td>Industrial Pharmacist</td>
<td>Proficient English (or Proficient Plus overall); Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>251513</td>
<td>Retail Pharmacist</td>
<td>Proficient English (or Proficient Plus overall); Offshore applicants Provisional 489 visa only</td>
<td>APharmC</td>
</tr>
<tr>
<td>251912</td>
<td>Orthotist or Prosthetist</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>AOPA</td>
</tr>
<tr>
<td>251999</td>
<td>Health Diagnostic and Promotion Professionals nec</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>252112</td>
<td>Osteopath</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>ANZOC</td>
</tr>
<tr>
<td>252211</td>
<td>Acupuncturist</td>
<td>Proficient English (or Proficient Plus overall); Offshore applicants Provisional 489 visa only</td>
<td>Chinese Medicine Board Of Australia</td>
</tr>
<tr>
<td>252213</td>
<td>Naturopath</td>
<td>Proficient English (or Proficient Plus overall); Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>252214</td>
<td>Traditional Chinese Medicine Practitioner</td>
<td>Proficient English (or Proficient Plus overall); Offshore applicants Provisional 489 visa only</td>
<td>Chinese Medicine Board Of Australia</td>
</tr>
<tr>
<td>252299</td>
<td>Complementary Health Therapists nec</td>
<td>Proficient English (or Proficient Plus overall); Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>252311</td>
<td>Dental Specialist</td>
<td>Proficient English (or Proficient Plus overall); 3 years&#39; work experience in field</td>
<td>ADC</td>
</tr>
<tr>
<td>252312</td>
<td>Dentist</td>
<td>Proficient English (or Proficient Plus overall); Provisional 489 visa only; 3 years&#39; work experience in field</td>
<td>ADC</td>
</tr>
<tr>
<td>253311</td>
<td>Specialist Physician (General Medicine)</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>Medical Board of Australia</td>
</tr>
<tr>
<td>253312</td>
<td>Cardiologist</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>Medical Board of Australia</td>
</tr>
<tr>
<td>253313</td>
<td>Clinical Haematologist</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>Medical Board of Australia</td>
</tr>
<tr>
<td>253314</td>
<td>Medical Oncologist</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>Medical Board of Australia</td>
</tr>
<tr>
<td>253315</td>
<td>Endocrinologist</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>Medical Board of Australia</td>
</tr>
<tr>
<td>253316</td>
<td>Gastroenterologist</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>Medical Board of Australia</td>
</tr>
<tr>
<td>253317</td>
<td>Intensive Care Specialist</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>Medical Board of Australia</td>
</tr>
<tr>
<td>253318</td>
<td>Neurologist</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>Medical Board of Australia</td>
</tr>
<tr>
<td>253322</td>
<td>Renal Medicine Specialist</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>Medical Board of Australia</td>
</tr>
<tr>
<td>253323</td>
<td>Rheumatologist</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>Medical Board of Australia</td>
</tr>
<tr>
<td>253324</td>
<td>Thoracic Medicine Specialist</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>Medical Board of Australia</td>
</tr>
<tr>
<td>253512</td>
<td>Cardiothoracic Surgeon</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>Medical Board of Australia</td>
</tr>
<tr>
<td>253513</td>
<td>Neurosurgeon</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>Medical Board of Australia</td>
</tr>
<tr>
<td>253515</td>
<td>Otorhinolaryngologist</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>Medical Board of Australia</td>
</tr>
<tr>
<td>253516</td>
<td>Paediatric Surgeon</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>Medical Board of Australia</td>
</tr>
<tr>
<td>253517</td>
<td>Plastic and Reconstructive Surgeon</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>Medical Board of Australia</td>
</tr>
<tr>
<td>253518</td>
<td>Urologist</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>Medical Board of Australia</td>
</tr>
<tr>
<td>253521</td>
<td>Vascular Surgeon</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>Medical Board of Australia</td>
</tr>
<tr>
<td>253911</td>
<td>Dermatologist</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>Medical Board of Australia</td>
</tr>
<tr>
<td>253912</td>
<td>Emergency Medicine Specialist</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>Medical Board of Australia</td>
</tr>
<tr>
<td>253913</td>
<td>Obstetrician and Gynaecologist</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>Medical Board of Australia</td>
</tr>
<tr>
<td>253914</td>
<td>Ophthalmologist</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>Medical Board of Australia</td>
</tr>
<tr>
<td>253915</td>
<td>Pathologist</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>Medical Board of Australia</td>
</tr>
<tr>
<td>253917</td>
<td>Diagnostic and Interventional Radiologist</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>Medical Board of Australia</td>
</tr>
<tr>
<td>253918</td>
<td>Radiation Oncologist</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>Medical Board of Australia</td>
</tr>
<tr>
<td>254211</td>
<td>Nurse Educator</td>
<td>Proficient English (or Proficient Plus overall); 5 years&#39; work experience in field</td>
<td>ANMAC</td>
</tr>
<tr>
<td>254212</td>
<td>Nurse Researcher</td>
<td>Proficient English (or Proficient Plus overall); 3 years&#39; work experience in field</td>
<td>ANMAC</td>
</tr>
<tr>
<td colspan="4"><strong>26 ICT Professionals</strong></td>
</tr>
<tr>
<td>263311</td>
<td>Telecommunications Engineer</td>
<td>Proficient English (or Proficient Plus overall); Offshore applicants Provisional 489 visa only; 3 years&#39; work experience in field</td>
<td>Engineers Australia</td>
</tr>
<tr>
<td>263312</td>
<td>Telecommunications Network Engineer</td>
<td>Proficient English (or Proficient Plus overall); Offshore applicants Provisional 489 visa only; 3 years&#39; work experience in field</td>
<td>Engineers Australia</td>
</tr>
<tr>
<td colspan="4"><strong>27 Legal, Social &amp; Welfare Professionals</strong></td>
</tr>
<tr>
<td>271111</td>
<td>Barrister</td>
<td>Proficient English (or Proficient Plus overall); Also refer to the Law Society requirements</td>
<td>SLAA</td>
</tr>
<tr>
<td>271214</td>
<td>Intellectual Property Lawyer</td>
<td>Proficient English (or Proficient Plus overall); Provisional 489 visa only; Also refer to the Law Society requirements</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>271299</td>
<td>Judicial and Other Legal Professionals nec</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>271311</td>
<td>Solicitor</td>
<td>Proficient English (or Proficient Plus overall); Also refer to the Law Society requirements</td>
<td>SLAA</td>
</tr>
<tr>
<td>272111</td>
<td>Careers Counsellor</td>
<td>Competent Plus English (or Proficient overall); Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>272112</td>
<td>Drug and Alcohol Counsellor</td>
<td>Competent Plus English (or Proficient overall); Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>272113</td>
<td>Family and Marriage Counsellor</td>
<td>Competent Plus English (or Proficient overall); Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>272313</td>
<td>Organisational Psychologist</td>
<td>Proficient English (or Proficient Plus overall)</td>
<td>APS</td>
</tr>
<tr>
<td>272412</td>
<td>Interpreter</td>
<td>Competent Plus English (or Proficient overall); Offshore applicants Provisional 489 visa only; Research job opportunities for your language specialisation</td>
<td>NAATI</td>
</tr>
<tr>
<td>272413</td>
<td>Translator</td>
<td>Competent Plus English (or Proficient overall); Provisional 489 visa only; Research job opportunities for your language specialisation</td>
<td>NAATI</td>
</tr>
<tr>
<td>272611</td>
<td>Community Arts Worker</td>
<td>Competent Plus English (or Proficient overall); Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td colspan="4"><strong>31 Engineering, ICT &amp; Science Technicians</strong></td>
</tr>
<tr>
<td>311211</td>
<td>Anaesthetic Technician</td>
<td>Competent Plus English (or Proficient overall)</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>311212</td>
<td>Cardiac Technician</td>
<td>Competent Plus English (or Proficient overall)</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>311214</td>
<td>Operating Theatre Technician</td>
<td>Competent Plus English (or Proficient overall); Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>311312</td>
<td>Meat Inspector</td>
<td>Competent English</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>311399</td>
<td>Primary Products Inspectors nec</td>
<td>Competent English; Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>312113</td>
<td>Building Inspector</td>
<td>Competent English</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>312114</td>
<td>Construction Estimator</td>
<td>Competent Plus English (or Proficient overall); Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>312116</td>
<td>Surveying or Spatial Science Technician</td>
<td>Competent Plus English (or Proficient overall); Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>312199</td>
<td>Architectural, Building and Surveying Technicians nec</td>
<td>Competent Plus English (or Proficient overall)</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>312511</td>
<td>Mechanical Engineering Draftsperson</td>
<td>Competent Plus English (or Proficient overall); Provisional 489 visa only</td>
<td>Engineers Australia</td>
</tr>
<tr>
<td>312512</td>
<td>Mechanical Engineering Technician</td>
<td>Competent Plus English (or Proficient overall); Offshore applicants Provisional 489 visa only</td>
<td>TRA</td>
</tr>
<tr>
<td>313211</td>
<td>Radiocommunications Technician</td>
<td>Competent English</td>
<td>TRA</td>
</tr>
<tr>
<td>313212</td>
<td>Telecommunications Field Engineer</td>
<td>Competent English</td>
<td>Engineers Australia</td>
</tr>
<tr>
<td>313213</td>
<td>Telecommunications Network Planner</td>
<td>Competent English</td>
<td>Engineers Australia</td>
</tr>
<tr>
<td>313214</td>
<td>Telecommunications Technical Officer or Technologist</td>
<td>Competent English</td>
<td>Engineers Australia</td>
</tr>
<tr>
<td colspan="4"><strong>32 Automotive &amp; Engineering Trades Workers</strong></td>
</tr>
<tr>
<td>322113</td>
<td>Farrier</td>
<td>Competent English</td>
<td>TRA</td>
</tr>
<tr>
<td>323111</td>
<td>Aircraft Maintenance Engineer (Avionics)</td>
<td>Competent English</td>
<td>TRA</td>
</tr>
<tr>
<td>323112</td>
<td>Aircraft Maintenance Engineer (Mechanical)</td>
<td>Competent English</td>
<td>TRA</td>
</tr>
<tr>
<td>323113</td>
<td>Aircraft Maintenance Engineer (Structures)</td>
<td>Competent English</td>
<td>TRA</td>
</tr>
<tr>
<td>323313</td>
<td>Locksmith</td>
<td>Competent English</td>
<td>TRA</td>
</tr>
<tr>
<td>323314</td>
<td>Precision Instrument Maker and Repairer</td>
<td>Competent English</td>
<td>TRA</td>
</tr>
<tr>
<td colspan="4"><strong>33 Construction Trades Workers</strong></td>
</tr>
<tr>
<td>334113</td>
<td>Drainer</td>
<td>Competent English</td>
<td>TRA</td>
</tr>
<tr>
<td>334114</td>
<td>Gasfitter</td>
<td>Competent English; Please contact Immigration SA before applying</td>
<td>TRA</td>
</tr>
<tr>
<td>334115</td>
<td>Roof Plumber</td>
<td>Competent English</td>
<td>TRA</td>
</tr>
<tr>
<td colspan="4"><strong>34 Electrotechnology &amp; Telecommunications Trades Workers</strong></td>
</tr>
<tr>
<td>341112</td>
<td>Electrician (Special Class)</td>
<td>Competent English</td>
<td>TRA</td>
</tr>
<tr>
 <td>342212</td>
<td>Technical Cable Jointer</td>
<td>Competent English</td>
<td>TRA</td>
</tr>
<tr>
<td>342411</td>
<td>Cabler (Data and Telecommunications)</td>
<td>Competent English</td>
<td>TRA</td>
</tr>
<tr>
<td colspan="4"><strong>36 Skilled Animal &amp; Horticultural Workers</strong></td>
</tr>
<tr>
<td>361111</td>
<td>Dog Handler or Trainer</td>
<td>Competent English; Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>361112</td>
<td>Horse Trainer</td>
<td>Competent English; Offshore applicants Provisional 489 visa only</td>
<td>TRA</td>
</tr>
<tr>
<td>361114</td>
<td>Zookeeper</td>
<td>Competent English; Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>361199</td>
<td>Animal Attendants and Trainers nec</td>
<td>Competent English; Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>361311</td>
<td>Veterinary Nurse</td>
<td>Competent English; Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>362111</td>
<td>Florist</td>
<td>Competent English; Offshore applicants Provisional 489 visa only</td>
<td>TRA</td>
</tr>
<tr>
<td colspan="4"><strong>39 Other Technicians &amp; Trades Workers</strong></td>
</tr>
<tr>
<td>392111</td>
<td>Print Finisher</td>
<td>Competent English</td>
<td>TRA</td>
</tr>
<tr>
<td>392311</td>
<td>Printing Machinist</td>
<td>Competent English</td>
<td>TRA</td>
</tr>
<tr>
<td>393311</td>
<td>Upholsterer</td>
<td>Competent English</td>
<td>TRA</td>
</tr>
<tr>
<td>394211</td>
<td>Furniture Finisher</td>
<td>Competent English</td>
<td>TRA</td>
</tr>
<tr>
<td>394213</td>
<td>Wood Machinist</td>
<td>Competent English</td>
<td>TRA</td>
</tr>
<tr>
<td>394299</td>
<td>Wood Machinists and Other Wood Trades Workers nec</td>
<td>Competent English</td>
<td>TRA</td>
</tr>
<tr>
<td>399212</td>
<td>Gas or Petroleum Operator</td>
<td>Competent English; Provisional 489 visa only</td>
<td>TRA</td>
</tr>
<tr>
<td>399213</td>
<td>Power Generation Plant Operator</td>
<td>Competent English</td>
<td>TRA</td>
</tr>
<tr>
<td>399411</td>
<td>Jeweller</td>
<td>Competent English</td>
<td>TRA</td>
</tr>
<tr>
<td>399512</td>
<td>Camera Operator (Film, Television or Video)</td>
<td>Competent English</td>
<td>TRA</td>
</tr>
<tr>
<td>399514</td>
<td>Make Up Artist</td>
<td>Competent English; Provisional 489 visa only</td>
<td>TRA</td>
</tr>
<tr>
<td>399516</td>
<td>Sound Technician</td>
<td>Competent English</td>
<td>TRA</td>
</tr>
<tr>
<td>399599</td>
<td>Performing Arts Technicians nec</td>
<td>Competent English</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>399611</td>
<td>Signwriter</td>
<td>Competent English</td>
<td>TRA</td>
</tr>
<tr>
<td colspan="4"><strong>41 Health &amp; Welfare Support Workers</strong></td>
</tr>
<tr>
<td>411112</td>
<td>Intensive Care Ambulance Paramedic</td>
<td>Competent Plus English (or Proficient overall)</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>411611</td>
<td>Massage Therapist</td>
<td>Competent English; Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>411715</td>
<td>Residential Care Officer</td>
<td>Competent English; Provisional 489 visa only</td>
<td>ACWA</td>
</tr>
<tr>
<td colspan="4"><strong>44 Protective Services Workers</strong></td>
</tr>
<tr>
<td>441211</td>
<td>Emergency Service Worker</td>
<td>Competent English; Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td colspan="4"><strong>45 Sports &amp; Personal Service Workers</strong></td>
</tr>
 <tr>
<td>451211</td>
<td>Driving Instructor</td>
<td>Competent English; Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>451399</td>
<td>Funeral Workers nec</td>
<td>Competent English; Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>451711</td>
<td>Flight Attendant</td>
<td>Competent English; Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>451815</td>
<td>First Aid Trainer</td>
<td>Proficient English (or Proficient Plus overall); Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>452311</td>
<td>Diving Instructor (Open Water)</td>
<td>Competent English; Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>452312</td>
<td>Gymnastics Coach or Instructor</td>
<td>Competent English; Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>452313</td>
<td>Horse Riding Coach or Instructor</td>
<td>Competent English; Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>452316</td>
<td>Tennis Coach</td>
<td>Competent English; Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>452317</td>
<td>Other Sports Coach or Instructor</td>
<td>Competent English; Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>452321</td>
<td>Sports Development Officer</td>
<td>Competent English; Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>452411</td>
<td>Footballer</td>
<td>Competent English; Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>452413</td>
<td>Jockey</td>
<td>Competent English; Provisional 489 visa only</td>
<td>TRA</td>
</tr>
<tr>
<td>452499</td>
<td>Sportspersons nec</td>
<td>Competent English; Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td colspan="4"><strong>59 Other Clerical and Administrative Workers</strong></td>
</tr>
<tr>
<td>599612</td>
<td>Insurance Loss Adjuster</td>
<td>Competent English; Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td>599915</td>
<td>Clinical Coder</td>
<td>Competent English; Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
<tr>
<td colspan="4"><strong>63 Sales Support Workers</strong></td>
</tr>
<tr>
<td>639211</td>
<td>Retail Buyer</td>
<td>Competent English; Offshore applicants Provisional 489 visa only</td>
<td>VETASSESS</td>
</tr>
</tbody>
</table>
<p>&nbsp;</p>
</div>
</div>
		 <div class="col-md-4 col-sm-4 col-xs-12">
		 <?php include('enquiry-form.php')?>
		 </div>
                
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>