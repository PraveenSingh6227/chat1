<?php include 'inc/header.php'; ?>
<div class="page-area">
    <div class="breadcumb-overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="breadcrumb">
                    <div class="bread-inner">
                        <div class="section-headline white-headline">
                            <h2>Canada PR Visa Application  <span class="color"> Process and Processing Time</span></h2>
                        </div>
                        <ul class="breadcrumb-bg">
                            <li class="home-bread"><a href="index.php">Home</a></li>
                            <li>Canada PR Visa Application Process and Processing Time</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="team-area bg-color pd-35">
    <div class="container">
        <!-- section head -->
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-headline text-center">
                    <h3>Canada PR Visa Application  <span class="color"> Process and Processing Time</span></h3>
                </div>
            </div>
        </div>
        <div class="row">
		 <div class="col-md-8 col-sm-8 col-xs-12" style="box-shadow: 5px 3px 10px rgb(0 0 0 / 10%);">
<div class='text-justify innerpage-text'><h3>Overview: Sponsoring Your Family</h3>
<div>Canada family immigration visa is specially designed for applicants or Canadian citizens or permanent residents who can sponsor their husband/wife, conjugal partner, common-law partner, dependent child (including adopted child) or other eligible relative (such as parent or grandparent) for becoming the permanent resident of Canada, thereby boosting Family immigration to Canada. with over 65,000 family visas issued alone in the year 2008. Canada family immigration visa is one of the most widely used categories.</div>
<h3>Relationships Not Eligible for The Family Visa</h3>
<div>You shall not be eligible to be sponsored as a spouse, a common-law partner or a conjugal partner if:</div>
<div>&nbsp;</div>
<ul>
<li>He or she is below 16 years of age.</li>
<li>He or she or even the sponsor is married to some other person during the time of the marriage.</li>
<li>If he or she has stayed away from the sponsor separately for at least 1 year and are either the husband or the wife is common-law or conjugal partner of another person.</li>
<li>The sponsor has immigrated to Canada, and during the time of the permanent residency was applied wherein he or she was a member of the family during the time of their eligibility assessment of their immigration requirements but were not evaluated.&nbsp;</li>
<li>The sponsor had previously funded any other spouse common-law partner or conjugal partner, and 3 years have not gone by since they became a permanent resident of Canada.&nbsp;</li>
<li>If the applicant does not qualify to sponsor or provide support to their spouse common-law partner or dependent child in the Family Class, their partner or dependent can very well apply to reside in Canada on humanitarian and compassionate grounds.</li>
</ul>
<h3>Other Eligible Relatives</h3>
<div>Canada family visa requirements requires you to sponsor eligible relatives are spouse, common-law partner and/or dependent children.&nbsp; Your spouse, partner or dependent children can be living or even be outside Canada while applying for the Canada family visa application. To be eligible you as well as your eligible relative will be required to meet certain eligibility requirements. It is the responsibility of the sponsor to assist their relatives financially in Canada, due to which there is no requirement for them to ask for any monetary help from the government of Canada.<br />
&nbsp;</div>
<div>Also, the sponsor is required to meet income requirements.&nbsp; Under the Canada family immigration visa you can even sponsor certain relatives such as parents and grandparents under the family class program as well as Brothers or sisters, nephews or nieces, granddaughters or grandsons who are orphaned, under 18 years of age and not married or in a common-law relationship and children who were either adopted outside Canada or intend to be adopted in Canada.</div>
<p><br />
<a href="authorized-representative-canada.html" style="padding:7px 5px ;background: #f00 !important; color: #fff; line-height: 24px; border-radius: 5px; margin-bottom: 6px;  width: 140px;" target="_blank" title="Our Canada RCIC Agent">Our Canada RCIC Agent</a></p>
<h3><br />
Benefits</h3>
<ul>
<li>One of the main benefits of applying for Canada family visa from India is that now relatives who are sponsored under this category will need not undergo any points-based evaluation on the Canada points system.</li>
<li>Sponsored family members who are granted <a href="permanent-resident-canada.html" target="_blank">Canadian permanent residency</a> under the Family class program secure the Right to live, work and study in Canada for a long period of time.&nbsp;</li>
<li>Family members and eligible relatives coming to Canada as permanent residents can now work minus any restrictions, avail training programs for language as well as find the appropriate help when it comes to finding the right kind of employment.&nbsp;</li>
<li>Also, permanent residents have complete accessibility to long term benefits such as government-funded healthcare, free education till the age of 18 after which they have a subsidized rate of education at university level along with reduced tuition fees and other social care perks such as Canada Pension Plan Benefits, Old Age Security and Guaranteed Income Supplement.</li>
<li>With Canada dependent visa for parents even apply for Canadian citizenship three years post living in Canada as a permanent resident.&nbsp;</li>
</ul>
<h3>Sponsorship Agreement</h3>
<div>Basically, a sponsorship agreement is a contract that outlines the conditions for both the sponsor as well as the family member or relative who is being sponsored to <a href="how-to-immigrate-to-canada-from-india.html" target="_blank">immigrate to Canada</a>. In this agreement the sponsor must accept that they are ready to help out his/her relative or dependent for an agreed duration of time without receiving any kind of social assistance. The sponsored individual must ensure that they are able to fund themselves, except in the case where your sponsored relatives are elderly.&nbsp;</div>
<h3>Visa Fee</h3>
<div>The Canada family visa fees for processing must be included along with your visa application</div>
<ul>
<li>The Processing fee amount for amount per person for sponsor is $75 and for the principal applicant is $475.</li>
<li>If the primary applicant is below 22 years and is a dependent child of a sponsor, a child to be adopted or an orphaned family member that is neither married nor in a common-law relationship they will need to pay $75 for the visa application.</li>
<li>If you are more than 22 years or more and are not married, engaged or in a common-law relationship regardless of age you will need to pay a visa processing fee of $550.</li>
<li>A sponsored relative below 22 years who is not married, engaged or in a common-law relationship will be required to pay a fee of $150.</li>
<li>The right to permanent residence fee for the primary applicant is $490 and for Spouse or common-law partner it is the same.</li>
<li>You will also be required to pay fees for yourself and your family members for the purpose of Medical examinations, Police certificates as well as for conducting Language assessments.</li>
</ul>
</div>
</div>
		 <div class="col-md-4 col-sm-4 col-xs-12">
		 <?php include('enquiry-form.php')?>
		 </div>
                
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>