<?php include 'inc/header.php'; ?>
<div class="page-area">
    <div class="breadcumb-overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="breadcrumb">
                    <div class="bread-inner">
                        <div class="section-headline white-headline">
                            <h2>Canada Spouse <span class="color"> Visa</span></h2>
                        </div>
                        <ul class="breadcrumb-bg">
                            <li class="home-bread"><a href="index.php">Home</a></li>
                            <li>Canada Spouse Visa</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="team-area bg-color pd-35">
    <div class="container">
        <!-- section head -->
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-headline text-center">
                    <h3>Canada Spouse <span class="color"> Visa</span></h3>
                </div>
            </div>
        </div>
        <div class="row">
		 <div class="col-md-8 col-sm-8 col-xs-12" style="box-shadow: 5px 3px 10px rgb(0 0 0 / 10%);">
<div class='text-justify innerpage-text'><p>With an economy shaped by settlers from across the globe, &ldquo;Canada&rdquo; is a very familiar name amongst the immigrant community. Through its lenient immigration policies Canada&rsquo;s federal government have made possible for applications from around the globe to live, work, and settle permanently in Canada. For all those who are permanently settled in Canada and desire to bring in their spouse with PR privileges to Canada can opt to avail for spouse sponsorship program. This procedure of spouse visa for&nbsp;<a href="../canada-visa.html" target="_blank">Canada PR</a>&nbsp;has a higher variable as compared to other visa applications as they&rsquo;ll not be restricted to fulfill stringent educational requirements, language proficiencies or work experience.<br />
<br />
<strong>What is Canadian Spouse Visa?</strong></p>
<p>The Spouse Sponsorship program allows Canadian citizens and permanent residents to sponsor their common-law partner or spouse as <a href="permanent-resident-canada.html" target="_blank">Canada Permanent Residents</a>. Upon receiving the sponsorship by their partners, this visa category allows the spouse to come, live, work, and settle permanently in Canada.<br />
<br />
The spousal sponsorship visa can be further categorized into:</p>
<ul>
<li>Outland sponsorship: to be applied if the sponsored partner is residing outside the Canadian border.</li>
<li>Inland sponsorship: to be applied if the sponsored partner is living together in Canada but under a temporary Canadian status.</li>
</ul>
<p><br />
<a href="../check-your-eligibility.html" style="color: rgb(255, 255, 255); padding: 7px 5px; line-height: 24px; border-radius: 5px; margin-bottom: 6px; width: 140px; background: rgb(255, 0, 0) !important;" target="_blank" title="Check Your Eligibility">Check Your Eligibility</a></p>
<p><br />
<strong>Rules for Spouse Visa in Canada</strong></p>
<p>Only Canada PR Visa holder and Canadian citizen are entitled to sponsor their spouse. The sponsor and sponsored partner have to be an adult (at least 18 years old) and should state the authenticity of their relationship to fulfill the criteria set by the Citizenship and&nbsp;Immigration Canada.<br />
<br />
<img alt="Spouse Visa Canada Requirements" src="img/21082019spouse-visa-canada-requirements.webp" style="width: 100%; height: 350px;" title="Spouse Visa for Canada PR" /><br />
<br />
<strong>Eligibility Requirements for Spouse</strong></p>
<p>In order to be eligible for sponsoring their spouse, one must:</p>
<ul>
<li>18 years or more in age</li>
<li>Must be a Canadian citizen or permanent resident</li>
<li>Must have a clean police record or must have not be charged with any serious offence</li>
<li>Must have not been invited to Canada as a sponsored spouse within a span of last 5 years</li>
</ul>
<p><br />
<a href="../expressyourinterest.html" style="color: rgb(255, 255, 255); padding: 7px 5px; line-height: 24px; border-radius: 5px; margin-bottom: 6px; width: 220px; background: rgb(255, 0, 0) !important;" target="_blank" title="Immigration Visa Enquiry Form">Free Profile Assessment and Visa Guidance</a></p>
<p>&nbsp;</p>
<p>Factors that can terminate your chances of sponsoring your spouse:</p>
<ul>
<li>If you fall under 18 years of age or were married to someone else at the time of his/her marriage to the sponsored applicant,</li>
<li>have failed to provide any financial evidence to support a previous sponsorship,</li>
<li>lived separately and any one of the two had been involved in a conjugal or common-law relationship with a third person,</li>
<li>have been admitted to Canada but not examined by CIC, and</li>
<li>have been engaged in an existing sponsorship agreement which is valid at the time of filing another sponsorship application to CIC.</li>
</ul>
<p><br />
<a href="authorized-representative-canada.html" style="padding:7px 5px ;background: #f00 !important; color: #fff; line-height: 24px; border-radius: 5px; margin-bottom: 6px;  width: 140px;" target="_blank" title="Our Canada RCIC Agent">Our Canada RCIC Agent</a><br />
<br />
<strong>Canada Spouse Visa Processing Time</strong></p>
<p>The processing time for&nbsp;Canadian Spousal Visa&nbsp;varies from country to country, according to the recent change in the immigration policies, the processing time for applicants under spouse visa for Canada from India may span from 12-26 months.<br />
<br />
<strong>Is IELTS Required for Canada Spouse Visa?</strong></p>
<p>Factually speaking, IELTS is not required at all for Canada spousal visa, although if you wish to include your spouse under the&nbsp;<a href="application-process-and-waiting-period.html" target="_blank">Canadia&nbsp;PR Application</a>&nbsp;via express entry you can get additional points by with your partners IELTS score.</p>
</div>
</div>
		 <div class="col-md-4 col-sm-4 col-xs-12">
		 <?php include('enquiry-form.php')?>
		 </div>
                
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>