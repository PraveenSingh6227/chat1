<?php include 'inc/header.php'; ?>

<div class="page-area">
  <div class="breadcumb-overlay"></div>
  <div class="container">
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="breadcrumb">
          <div class="bread-inner">
            <div class="section-headline white-headline">
              <h2>South Australia State Nomination  <span class="color"> Skilled Occupation List</span></h2>
            </div>
            <ul class="breadcrumb-bg">
              <li class="home-bread"><a href="index.php">Home</a></li>
              <li>South Australia State Nomination Skilled Occupation List</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="team-area bg-color pd-35">
  <div class="container">
    <!-- section head -->
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="section-headline text-center">
          <h3>South Australia State Nomination  <span class="color"> Skilled Occupation List</span></h3>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-8 col-sm-8 col-xs-12" style="box-shadow: 5px 3px 10px rgb(0 0 0 / 10%);">
        <div class='text-justify innerpage-text'>
          <p>This list is available to all applicants including South Australian international graduates.&nbsp;<br />
            <br />
            Additional occupations are available on the <a href="../australia/south-australia-supplementary-skilled-list.html" target="_blank">South Australia Supplementary Skilled List</a> for South Australian international graduates who have completed a Bachelor degree or higher.<br />
            <br />
            <strong>&quot;</strong>Please note that the list undergoes a change very frequently and whether or not your occupation is still open to accept fresh applications by the state is dependent on available quota. It is in your interest to lodge in your application for the state ASAP. How fast and when the quota gets filled up for a specific occupation is not in our hands. Please contact our office to check whether or not your occupation is still open for accepting new applications<strong>&rdquo;.</strong><br />
            &nbsp;</p>
          <p><strong>Updated List Date: 4th December 2019.</strong><br />
            &nbsp;</p>
          <table border="1" bordercolor="#CCC" cellpadding="8" cellspacing="0" height="100%" width="90%">
            <tbody>
              <tr bgcolor="#F00" style="color:#FFF">
                <td><p><strong>ANZSCO Code</strong></p></td>
                <td width="373"><p><strong>Occupation</strong></p></td>
                <td><p><strong>Availability</strong></p></td>
                <td><p><strong>Additional Requirements</strong></p></td>
                <td><p><strong>Special Conditions</strong></p></td>
              </tr>
              <tr>
                <td><p>12</p></td>
                <td><p>Farmers and Farm Managers</p></td>
                <td><p>&nbsp;</p></td>
                <td><p>&nbsp;</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>121212</p></td>
                <td><p>Flower Grower</p></td>
                <td><p>Available</p></td>
                <td><p>Competent English; Provisional 491 visa only</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>121213</p></td>
                <td><p>Fruit or Nut Grower</p></td>
                <td><p>Available</p></td>
                <td><p>Competent English; Provisional 491 visa only</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>121214</p></td>
                <td><p>Grain, Oilseed or Pasture Grower</p></td>
                <td><p>Available</p></td>
                <td><p>Competent English; Provisional 491 visa only</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>121215</p></td>
                <td><p>Grape Grower</p></td>
                <td><p>Available</p></td>
                <td><p>Competent English; Provisional 491 visa only; Opportunities stronger in wine regions further from Adelaide (i.e. beyond Adelaide Hills, McLaren Vale, Barossa Valley)</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>121216</p></td>
                <td><p>Mixed Crop Farmer</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Competent English; Provisional 491 visa only; Not available for High Points nomination from 08/07/2019; Not available for Chain Migration nomination from 08/07/2019</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>121221</p></td>
                <td><p>Vegetable Grower</p></td>
                <td><p>Available</p></td>
                <td><p>Competent English; Provisional 491 visa only</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>121299</p></td>
                <td><p>Crop Farmers nec</p></td>
                <td><p>Available</p></td>
                <td><p>Competent English; Provisional 491 visa only</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>121312</p></td>
                <td><p>Beef Cattle Farmer</p></td>
                <td><p>Available</p></td>
                <td><p>Competent English; Provisional 491 visa only</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>121313</p></td>
                <td><p>Dairy Cattle Farmer</p></td>
                <td><p>Available</p></td>
                <td><p>Competent English; Provisional 491 visa only</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>121317</p></td>
                <td><p>Mixed Livestock Farmer</p></td>
                <td><p>Available</p></td>
                <td><p>Competent English; Provisional 491 visa only</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>121318</p></td>
                <td><p>Pig Farmer</p></td>
                <td><p>Available</p></td>
                <td><p>Competent English; Provisional 491 visa only</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>121321</p></td>
                <td><p>Poultry Farmer</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Competent English; Provisional 491 visa only</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>121322</p></td>
                <td><p>Sheep Farmer</p></td>
                <td><p>Available</p></td>
                <td><p>Competent English; Provisional 491 visa only</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>121411</p></td>
                <td><p>Mixed Crop and Livestock Farmer</p></td>
                <td><p>Available</p></td>
                <td><p>Competent English; Provisional 491 visa only</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>13</p></td>
                <td><p>Specialist Managers</p></td>
                <td><p>&nbsp;</p></td>
                <td><p>&nbsp;</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>131112</p></td>
                <td><p>Sales and Marketing Manager</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 85 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>131113</p></td>
                <td><p>Advertising Manager</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 85 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>131114</p></td>
                <td><p>Public Relations Manager</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only; 85 points required for offshore applicants; See additional instructions</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>132111</p></td>
                <td><p>Corporate Services Manager</p></td>
                <td><p>Low Availability</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 85 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>132211</p></td>
                <td><p>Finance Manager</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); 3 years&#39; work experience in field; Not available for High Points nomination from 04/07/2019; Not available for Chain Migration nomination from 04/07/2019; South Australian graduates must be currently working in their field in South Australia for the last 12 months; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>132311</p></td>
                <td><p>Human Resource Manager</p></td>
                <td><p>Low Availability</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 85 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>132511</p></td>
                <td><p>Research and Development Manager</p></td>
                <td><p>Low Availability</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 85 points required for chain migration category</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>133111</p></td>
                <td><p>Construction Project Manager</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Not available for High Points nomination from 05/07/2019; Not available for Chain Migration nomination from 05/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>133112</p></td>
                <td><p>Project Builder</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only; 85 points required for offshore applicants; See additional instructions</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>133211</p></td>
                <td><p>Engineering Manager</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); 3 years&#39; work experience in field; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 85 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>133411</p></td>
                <td><p>Manufacturer</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; Research job opportunities for your particular specialisation; 85 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>133511</p></td>
                <td><p>Production Manager (Forestry)</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; Opportunities may be stronger in forestry regions (i.e. Limestone Coast); 85 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>133512</p></td>
                <td><p>Production Manager (Manufacturing)</p></td>
                <td><p>Low Availability</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; Research job opportunities for your particular specialisation; 85 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>133513</p></td>
                <td><p>Production Manager (Mining)</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 85 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>133611</p></td>
                <td><p>Supply and Distribution Manager</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 85 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>133612</p></td>
                <td><p>Procurement Manager</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only; 85 points required for offshore applicants; See additional instructions</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>134211</p></td>
                <td><p>Medical Administrator</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only; 85 points required for offshore applicants; See additional instructions</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>134212</p></td>
                <td><p>Nursing Clinical Director</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 85 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>134213</p></td>
                <td><p>Primary Health Organisation Manager</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 85 points required for chain migration category</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>134214</p></td>
                <td><p>Welfare Centre Manager</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 85 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>134299</p></td>
                <td><p>Health and Welfare Services Managers nec</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 85 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>135112</p></td>
                <td><p>ICT Project Manager</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Not available for High Points nomination from 04/07/2019; Not available for Chain Migration nomination from 04/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>135199</p></td>
                <td><p>ICT Managers nec</p></td>
                <td><p>Low Availability</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 85 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>139911</p></td>
                <td><p>Art Administrator or Manager</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Not available for High Points nomination from 04/07/2019; Not available for Chain Migration nomination from 04/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>139914</p></td>
                <td><p>Quality Assurance Manager</p></td>
                <td><p>Low Availability</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 85 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>139999</p></td>
                <td><p>Specialist Managers nec</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; Research job opportunities for your particular specialisation; Excludes Ambassador, Archbishop and Bishop; 85 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>14</p></td>
                <td><p>Hospitality, Retail &amp; Service Managers</p></td>
                <td><p>&nbsp;</p></td>
                <td><p>&nbsp;</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>141111</p></td>
                <td><p>Cafe or Restaurant Manager</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Competent Plus English (or Proficient overall); Provisional 491 visa only; 85 points required for offshore applicants; See additional instructions</p></td>
                <td><p>04/12/2019</p></td>
              </tr>
              <tr>
                <td><p>141311</p></td>
                <td><p>Hotel or Motel Manager</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Competent Plus English (or Proficient overall); Provisional 491 visa only; 85 points required for chain migration category; See additional instructions</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>141999</p></td>
                <td><p>Accommodation and Hospitality Managers nec</p></td>
                <td><p>Available</p></td>
                <td><p>Competent Plus English (or Proficient overall); Provisional 491 visa only; 85 points required for offshore applicants; See additional instructions</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>149212</p></td>
                <td><p>Customer Service Manager</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient Plus English (or Superior overall); Provisional 491 visa only; 85 points required for offshore applicants; See additional instructions</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>149311</p></td>
                <td><p>Conference and Event Organiser</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Competent Plus English (or Proficient overall); Not available for High Points nomination from 04/07/2019; Not available for Chain Migration nomination from 04/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>149913</p></td>
                <td><p>Facilities Manager</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Competent Plus English (or Proficient overall); Not available for High Points nomination from 04/07/2019; Not available for Chain Migration nomination from 04/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>149914</p></td>
                <td><p>Financial Institution Branch Manager</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only; 3 years&#39; work experience in field; Not available for High Points nomination from 04/07/2019; Not available for Chain Migration nomination from 04/07/2019; South Australian graduates must be currently working in their field in South Australia for the last 12 months</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>21</p></td>
                <td><p>Arts &amp; Media Professionals</p></td>
                <td><p>&nbsp;</p></td>
                <td><p>&nbsp;</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>211311</p></td>
                <td><p>Photographer</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Competent English; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); Preparedness to self-employ</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>212314</p></td>
                <td><p>Film and Video Editor</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Competent English; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>22</p></td>
                <td><p>Business, Human Resource &amp; Marketing Professionals</p></td>
                <td><p>&nbsp;</p></td>
                <td><p>&nbsp;</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>222112</p></td>
                <td><p>Finance Broker</p></td>
                <td><p>Available</p></td>
                <td><p>Competent Plus English (or Proficient overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 85 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>222113</p></td>
                <td><p>Insurance Broker</p></td>
                <td><p>Available</p></td>
                <td><p>Competent Plus English (or Proficient overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 85 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>223112</p></td>
                <td><p>Recruitment Consultant</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Not available for High Points nomination from 04/07/2019; Not available for Chain Migration nomination from 04/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>224112</p></td>
                <td><p>Mathematician</p></td>
                <td><p>Low Availability</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>224113</p></td>
                <td><p>Statistician</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Not available for High Points nomination from 09/07/2019; Not available for Chain Migration nomination from 09/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>224214</p></td>
                <td><p>Records Manager</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Competent Plus English (or Proficient overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>224311</p></td>
                <td><p>Economist</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>224711</p></td>
                <td><p>Management Consultant</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Not available for High Points nomination from 05/07/2019; Not available for Chain Migration nomination from 05/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>224712</p></td>
                <td><p>Organisation and Methods Analyst</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Not available for High Points nomination from 04/07/2019; Not available for Chain Migration nomination from 04/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>224912</p></td>
                <td><p>Liaison Officer</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only; See additional instructions; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>224999</p></td>
                <td><p>Information and Organisation Professionals nec</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Competent Plus English (or Proficient overall); Not available for High Points nomination from 04/07/2019; Not available for Chain Migration nomination from 04/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>225111</p></td>
                <td><p>Advertising Specialist</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Competent Plus English (or Proficient overall); Not available for High Points nomination from 04/07/2019; Not available for Chain Migration nomination from 04/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>225211</p></td>
                <td><p>ICT Account Manager</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Not available for High Points nomination from 05/07/2019; Not available for Chain Migration nomination from 05/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>225212</p></td>
                <td><p>ICT Business Development Manager</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Not available for High Points nomination from 04/07/2019; Not available for Chain Migration nomination from 04/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>225213</p></td>
                <td><p>ICT Sales Representative</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>225311</p></td>
                <td><p>Public Relations Professional</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Competent Plus English (or Proficient overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>225499</p></td>
                <td><p>Technical Sales Representatives nec</p></td>
                <td><p>Low Availability</p></td>
                <td><p>Competent Plus English (or Proficient overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>23</p></td>
                <td><p>Design, Engineering, Science &amp; Transport Professionals</p></td>
                <td><p>&nbsp;</p></td>
                <td><p>&nbsp;</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>232111</p></td>
                <td><p>Architect</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Competent Plus English (or Proficient overall); 3 years&#39; work experience in field; Not available for High Points nomination from 12/07/2019; Not available for Chain Migration nomination from 12/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>232212</p></td>
                <td><p>Surveyor</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Competent Plus English (or Proficient overall); Not available for High Points nomination from 05/07/2019; Not available for Chain Migration nomination from 05/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>232312</p></td>
                <td><p>Industrial Designer</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Competent Plus English (or Proficient overall); Not available for High Points nomination from 05/07/2019; Not available for Chain Migration nomination from 05/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); Preparedness to self-employ</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>232411</p></td>
                <td><p>Graphic Designer</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Competent English; Not available for High Points nomination from 07/07/2019; Not available for Chain Migration nomination from 07/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>232412</p></td>
                <td><p>Illustrator</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Competent English; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>232413</p></td>
                <td><p>Multimedia Designer</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Competent English; Provisional 491 visa only</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>232414</p></td>
                <td><p>Web Designer</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Competent English; Not available for High Points nomination from 12/07/2019; Not available for Chain Migration nomination from 12/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>232611</p></td>
                <td><p>Urban And Regional Planner</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Competent English; Not available for High Points nomination from 04/07/2019; Not available for Chain Migration nomination from 04/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>233111</p></td>
                <td><p>Chemical Engineer</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); 3 years&#39; work experience in field; Not available for High Points nomination from 04/07/2019; Not available for Chain Migration nomination from 04/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>233211</p></td>
                <td><p>Civil Engineer</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); 3 years&#39; work experience in field; Not available for High Points nomination from 04/07/2019; Not available for Chain Migration nomination from 04/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>233212</p></td>
                <td><p>Geotechnical Engineer</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); 3 years&#39; work experience in field; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 75 points required for offshore applicants</p></td>
                <td><p>04/12/2019</p></td>
              </tr>
              <tr>
                <td><p>233213</p></td>
                <td><p>Quantity Surveyor</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Not available for High Points nomination from 04/07/2019; Not available for Chain Migration nomination from 04/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>233214</p></td>
                <td><p>Structural Engineer</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); 3 years&#39; work experience in field; Not available for High Points nomination from 04/07/2019; Not available for Chain Migration nomination from 04/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>233215</p></td>
                <td><p>Transport Engineer</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); 3 years&#39; work experience in field; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>233311</p></td>
                <td><p>Electrical Engineer</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); 3 years&#39; work experience in field; Not available for High Points nomination from 04/07/2019; Not available for Chain Migration nomination from 04/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>233411</p></td>
                <td><p>Electronics Engineer</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); 3 years&#39; work experience in field; Not available for High Points nomination from 04/07/2019; Not available for Chain Migration nomination from 04/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>233511</p></td>
                <td><p>Industrial Engineer</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); 3 years&#39; work experience in field; Not available for High Points nomination from 04/07/2019; Not available for Chain Migration nomination from 04/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>233512</p></td>
                <td><p>Mechanical Engineer</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); 3 years&#39; work experience in field; Not available for High Points nomination from 04/07/2019; Not available for Chain Migration nomination from 04/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>233513</p></td>
                <td><p>Production or Plant Engineer</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); 3 years&#39; work experience in field; Not available for High Points nomination from 04/07/2019; Not available for Chain Migration nomination from 04/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>233611</p></td>
                <td><p>Mining Engineer (excluding Petroleum)</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); 3 years&#39; work experience in field; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>02/12/2019</p></td>
              </tr>
              <tr>
                <td><p>233612</p></td>
                <td><p>Petroleum Engineer</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); 3 years&#39; work experience in field; Not available for High Points nomination from 02/12/2019; Not available for Chain Migration nomination from 02/12/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>233999</p></td>
                <td><p>Engineering Professionals nec</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); 3 years&#39; work experience in field; Not available for High Points nomination from 06/07/2019; Not available for Chain Migration nomination from 06/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>234111</p></td>
                <td><p>Agricultural Consultant</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Competent Plus English (or Proficient overall); Not available for High Points nomination from 04/07/2019; Not available for Chain Migration nomination from 04/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>234112</p></td>
                <td><p>Agricultural Scientist</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Competent Plus English (or Proficient overall); Not available for High Points nomination from 04/07/2019; Not available for Chain Migration nomination from 04/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>234113</p></td>
                <td><p>Forester</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Competent English; Not available for High Points nomination from 08/07/2019; Not available for Chain Migration nomination from 08/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); Opportunities may be stronger in forestry regions (i.e. Limestone Coast)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>234211</p></td>
                <td><p>Chemist</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Not available for High Points nomination from 08/07/2019; Not available for Chain Migration nomination from 08/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>234212</p></td>
                <td><p>Food Technologist</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>234213</p></td>
                <td><p>Wine Maker</p></td>
                <td><p>Available</p></td>
                <td><p>Competent English; Provisional 491 visa only; Opportunities stronger in wine regions further from Adelaide (i.e. beyond Adelaide Hills, McLaren Vale, Barossa Valley)</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>234411</p></td>
                <td><p>Geologist</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); 3 years&#39; work experience in field; South Australian graduates must be currently working in their field in South Australia for the last 12 months; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>234412</p></td>
                <td><p>Geophysicist</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>234413</p></td>
                <td><p>Hydrogeologist</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>234511</p></td>
                <td><p>Life Scientist (General)</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>234513</p></td>
                <td><p>Biochemist</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>234514</p></td>
                <td><p>Biotechnologist</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>234515</p></td>
                <td><p>Botanist</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>234516</p></td>
                <td><p>Marine Biologist</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>234517</p></td>
                <td><p>Microbiologist</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>234518</p></td>
                <td><p>Zoologist</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>234599</p></td>
                <td><p>Life Scientists nec</p></td>
                <td><p>Low Availability</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>234611</p></td>
                <td><p>Medical Laboratory Scientist</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>234914</p></td>
                <td><p>Physicist (Medical Physicist Only)</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>24</p></td>
                <td><p>Education Professionals</p></td>
                <td><p>&nbsp;</p></td>
                <td><p>&nbsp;</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>241111</p></td>
                <td><p>Early Childhood (Pre-primary School) Teacher</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 85 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>241511</p></td>
                <td><p>Special Needs Teacher</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>241512</p></td>
                <td><p>Teacher of the Hearing Impaired</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>241513</p></td>
                <td><p>Teacher of the Sight Impaired</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>241599</p></td>
                <td><p>Special Education Teachers nec</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>242211</p></td>
                <td><p>Vocational Education Teacher (Trades)</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only; Skills assessment by TRA required; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>249212</p></td>
                <td><p>Dance Teacher (Private Tuition)</p></td>
                <td><p>Available</p></td>
                <td><p>Competent Plus English (or Proficient overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; Preparedness to self-employ; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>249214</p></td>
                <td><p>Music Teacher (Private Tuition)</p></td>
                <td><p>Low Availability</p></td>
                <td><p>Competent Plus English (or Proficient overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; Preparedness to self-employ; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>249299</p></td>
                <td><p>Private Tutors and Teachers nec</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Competent Plus English (or Proficient overall); Not available for High Points nomination from 04/07/2019; Not available for Chain Migration nomination from 04/07/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); Preparedness to self-employ</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>25</p></td>
                <td><p>Health Professionals</p></td>
                <td><p>&nbsp;</p></td>
                <td><p>&nbsp;</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>251211</p></td>
                <td><p>Medical Diagnostic Radiographer</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>251214</p></td>
                <td><p>Sonographer</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>251312</p></td>
                <td><p>Occupational Health and Safety Advisor</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>251411</p></td>
                <td><p>Optometrist</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>251911</p></td>
                <td><p>Health Promotion Officer</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>252111</p></td>
                <td><p>Chiropractor</p></td>
                <td><p>Low Availability</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>252411</p></td>
                <td><p>Occupational Therapist</p></td>
                <td><p>Low Availability</p></td>
                <td><p>Proficient English (or Proficient Plus overall); 3 years&#39; work experience in field; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>252511</p></td>
                <td><p>Physiotherapist</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); 3 years&#39; work experience in field; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>252611</p></td>
                <td><p>Podiatrist</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); 3 years&#39; work experience in field; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>252711</p></td>
                <td><p>Audiologist</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); 3 years&#39; work experience in field; Not available for High Points nomination from 02/12/2019; Not available for Chain Migration nomination from 02/12/2019; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5)</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>252712</p></td>
                <td><p>Speech Pathologist</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); 3 years&#39; work experience in field; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>253111</p></td>
                <td><p>General Practitioner</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; Full - General registration in Australia is required; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>253112</p></td>
                <td><p>Resident Medical Officer</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; Full - General registration in Australia is required; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>253211</p></td>
                <td><p>Anaesthetist</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only; 75 points required for offshore applicants; See additional instructions</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>253321</p></td>
                <td><p>Paediatrician</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>253399</p></td>
                <td><p>Specialist Physicians nec</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>253411</p></td>
                <td><p>Psychiatrist</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>253511</p></td>
                <td><p>Surgeon (General)</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>253514</p></td>
                <td><p>Orthopaedic Surgeon</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>253999</p></td>
                <td><p>Medical Practitioners nec</p></td>
                <td><p>Special Conditions Apply</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; Full - General registration in Australia is required; 75 points required for offshore applicants</p></td>
                <td><p>29/11/2019</p></td>
              </tr>
              <tr>
                <td><p>254111</p></td>
                <td><p>Midwife</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>254311</p></td>
                <td><p>Nurse Manager</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); 5 years&#39; work experience in field; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>254411</p></td>
                <td><p>Nurse Practitioner</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); 5 years&#39; work experience in field; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>254412</p></td>
                <td><p>Registered Nurse (Aged Care)</p></td>
                <td><p>Available</p></td>
                <td><p>Proficient English (or Proficient Plus overall); 5 years&#39; work experience in field; Provisional 491 visa only - 190 nomination offered to applicants under specific circumstances only (see 3.5); See additional instructions; 75 points required for offshore applicants</p></td>
                <td><p>&nbsp;</p></td>
              </tr>
              <tr>
                <td><p>254413</p></td>
                <td>&nbsp;</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div class="col-md-4 col-sm-4 col-xs-12">
        <?php include('enquiry-form.php')?>
      </div>
    </div>
  </div>
</div>
</div>
</div>
<?php include 'inc/footer.php'; ?>
