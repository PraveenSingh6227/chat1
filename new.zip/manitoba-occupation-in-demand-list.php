<?php include 'inc/header.php'; ?>
<div class="page-area">
    <div class="breadcumb-overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="breadcrumb">
                    <div class="bread-inner">
                        <div class="section-headline white-headline">
                            <h2>Manitoba Occupation  <span class="color"> in-Demand List</span></h2>
                        </div>
                        <ul class="breadcrumb-bg">
                            <li class="home-bread"><a href="index.php">Home</a></li>
                            <li>Manitoba Occupation in-Demand List</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="team-area bg-color pd-35">
    <div class="container">
        <!-- section head -->
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-headline text-center">
                    <h3>Manitoba Occupation  <span class="color"> in-Demand List</span></h3>
                </div>
            </div>
        </div>
        <div class="row">
		 <div class="col-md-8 col-sm-8 col-xs-12" style="box-shadow: 5px 3px 10px rgb(0 0 0 / 10%);">
<div class='text-justify innerpage-text'><p><strong>About Manitoba Provincial Nominee Program</strong></p>
<p>The MPNP looks out for skilled workers who have chosen an occupation mentioned in the Manitoba in Demand Occupation List an are basically based on the labor needs, shortages and economic requirements of the Canadian province of Manitoba. Recent graduates, skilled workers, businesspeople and their families who possess the true intention to successfully settle and economically establish themselves as permanent residents.</p>
<p><strong style="text-align: center;"><a href="../expressyourinterest.html" style="color: rgb(255, 255, 255); padding: 7px 5px; line-height: 24px; border-radius: 5px; margin-bottom: 6px; width: 220px; background: rgb(255, 0, 0) !important;" target="_blank" title="Immigration Visa Enquiry Form">Get Free Profile Assessment&nbsp;</a></strong></p>
<p>If business is what you are looking for then the <strong><a href="manitoba-provincial-nominee-program-for-business.html" target="_blank">Manitoba Provincial Nominee Program for Business</a></strong> (MPNPB) also known as the Business Investor Stream (BIS) permits the recruitment and nomination of qualified business investors and entrepreneurs around the world who have the intent and ability to purchase businesses in Manitoba.</p>
<p>The MPNP also conducts Expression of Interest <strong><a href="latest-express-entry-immigration-draws.html" target="_blank">Canada Express Entry Draw</a></strong> for candidates applying for nomination via its Express entry pathways.</p>
<p><br />
<a href="authorized-representative-canada.html" style="padding:7px 5px ;background: #f00 !important; color: #fff; line-height: 24px; border-radius: 5px; margin-bottom: 6px;  width: 140px;" target="_blank" title="Our Canada RCIC Agent">Our Canada RCIC Agent</a><br />
&nbsp;</p>
<p><strong>Eligibility Requirement for Manitoba Occupation List</strong></p>
<p><strong>Here are the following criteria for proving occupational eligibility for Manitoba Immigration</strong></p>
<ul>
<li>You must have a past education, training, work experience and any applicable certification, license or registration (regulatory requirements) as well.</li>
<li>As a prospective applicant you must have proficiency in English to qualify for <strong><a href="../canada-visa.html" target="_blank">Canada PR Visa</a></strong> via MPNP.</li>
<li>NOC Requirements &ndash; needs to be fulfilled to assess whether or skills and potential are conducive for long term employment as well as growth in career, that in turn will assist in the development of the local labor market in Manitoba.</li>
<li>Must provide detailed decryption of duties, skills, talents and work settings in the Canadian economy as mentioned in the National Occupation Classification 2011 (NOC).<br />
&nbsp;</li>
</ul>
<p><strong>Manitoba in Demand Occupation List</strong></p>
<p>Since Manitoba choses suitable skilled workers and professionals via MPNP meaning that these candidates must hold the skills and qualifications to be able to work in the labor market of the province. Manitoba in Demand Occupation List is an updated list of relevant high demand occupations as per the labor shortages and economic requirements of the Manitoba local labor market. This list is updated on a regular basis as per the changing labor demands.<br />
&nbsp;</p>
<h2><strong>1. Business, Finance and Administration Occupations </strong></h2>
<table border="2" class="table tbl" style="border-color: #000;" width="100%">
<tbody>
<tr class="crs_heading">
<td>NOC</td>
<td>Occupation Title</td>
<td>Skill<br />
Level</td>
<td>Minimum<br />
CLB</td>
<td>S<br />
W<br />
O</td>
<td>S<br />
W<br />
M</td>
<td>I<br />
E<br />
S</td>
</tr>
<tr>
<td>0111</td>
<td>Financial managers</td>
<td>0</td>
<td>7</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>0112</td>
<td>Human resources managers</td>
<td>0</td>
<td>7</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>0114</td>
<td>Other administrative services managers</td>
<td>0</td>
<td>7</td>
<td>&nbsp;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>0121</td>
<td>Insurance, real estate and financial brokerage managers</td>
<td>0</td>
<td>7</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>0122</td>
<td>Banking, credit and other investment managers</td>
<td>0</td>
<td>7</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>0124</td>
<td>Advertising, marketing and public relations managers</td>
<td>0</td>
<td>7</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>1111</td>
<td>Financial auditors and accountants</td>
<td>A</td>
<td>7</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>1112</td>
<td>Financial and investment analysts</td>
<td>A</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>1114</td>
<td>Other financial officers</td>
<td>A</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>1121</td>
<td>Human resources professionals</td>
<td>A</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>1122</td>
<td>Professional occupations in business management consulting</td>
<td>A</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>1123</td>
<td>Professional occupations in advertising, marketing and public relations</td>
<td>A</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>1212</td>
<td>Supervisors, finance and insurance office workers</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>1215</td>
<td>Supervisors, supply chain, tracking and scheduling co-ordination occupations</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>1221</td>
<td>Administrative officers</td>
<td>B</td>
<td>5</td>
<td>&nbsp;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>1223</td>
<td>Human resources and recruitment officers</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>1224</td>
<td>Property administrators</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>1241</td>
<td>Administrative assistants</td>
<td>B</td>
<td>5</td>
<td>&nbsp;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>1242</td>
<td>Legal administrative assistants</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>1251</td>
<td>Court reporters, medical transcriptionists and related occupations</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>1311</td>
<td>Accounting technicians and bookkeepers</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
</tbody>
</table>
<h2><br />
<strong>2. Natural and Applied Sciences and Related Occupations </strong></h2>
<table border="2" class="table tbl" style="border-color: #000;" width="100%">
<tbody>
<tr class="crs_heading">
<td>NOC</td>
<td>Occupation Title</td>
<td>Skill Level</td>
<td>Minimum CLB</td>
<td>S<br />
W<br />
O</td>
<td>S<br />
W<br />
M</td>
<td>I<br />
E<br />
S</td>
</tr>
<tr>
<td>0211</td>
<td>Engineering managers</td>
<td>0</td>
<td>7</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>0212</td>
<td>Architecture* and science managers</td>
<td>0</td>
<td>7</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>0213</td>
<td>Computer and information systems managers</td>
<td>0</td>
<td>7</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>2121</td>
<td>Biologists and related scientists</td>
<td>A</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>2123</td>
<td>Agricultural representatives, consultants and specialists</td>
<td>A</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>2131</td>
<td>Civil engineers</td>
<td>A</td>
<td>7</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>2132</td>
<td>Mechanical engineers</td>
<td>A</td>
<td>7</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>2133</td>
<td>Electrical and electronics engineers</td>
<td>A</td>
<td>7</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>2141</td>
<td>Industrial and manufacturing engineers</td>
<td>A</td>
<td>7</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>2147</td>
<td>Computer engineers (except software engineers and designers)</td>
<td>A</td>
<td>7</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>2151</td>
<td>Architects</td>
<td>A</td>
<td>7</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>2154</td>
<td>Land surveyors *</td>
<td>A</td>
<td>7</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>2161</td>
<td>Mathematicians, statisticians and actuaries</td>
<td>A</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>2171</td>
<td>Information systems analysts and consultants</td>
<td>A</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>2172</td>
<td>Database analysts and data administrators</td>
<td>A</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>2173</td>
<td>Software engineers and designers</td>
<td>A</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>2174</td>
<td>Computer programmers and interactive media developers</td>
<td>A</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
 <tr>
<td>2175</td>
<td>Web designers and developers</td>
<td>A</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>2211</td>
<td>Chemical technologists and technicians</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>2212</td>
<td>Geological and mineral technologists and technicians</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>2221</td>
<td>Biological technologists and technicians</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>2222</td>
<td>Agricultural and fish products inspectors</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>2231</td>
<td>Civil engineering technologists and technicians</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>2232</td>
<td>Mechanical engineering technologists and technicians</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>2233</td>
<td>Industrial engineering and manufacturing technologists and technicians</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>2234</td>
<td>Construction estimators</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>2241</td>
<td>Electrical and electronics engineering technologists and technicians</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>2242</td>
<td>Electronic service technicians (household and business equipment)</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>2244</td>
<td>Aircraft instrument, electrical and avionics mechanics, technicians and inspectors</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>2253</td>
<td>Drafting technologists and technicians</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>2271</td>
<td>Air pilots, flight engineers and flying instructors</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>2281</td>
<td>Computer network technicians</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>2282</td>
<td>User support technicians</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
</tbody>
</table>
<h2><br />
<strong>3. Health Occupations </strong></h2>
<table border="2" class="table tbl" style="border-color: #000;" width="100%">
<tbody>
<tr class="crs_heading">
<td>NOC</td>
<td>Occupation Title</td>
<td>Skill Level</td>
<td>Minimum CLB</td>
<td>S<br />
W<br />
O</td>
<td>S<br />
W<br />
M</td>
<td>I<br />
E<br />
S</td>
</tr>
<tr>
<td>0311</td>
<td>Managers in Health Care</td>
<td>A</td>
<td>7</td>
<td>&nbsp;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>3131</td>
<td>Pharmacists *</td>
<td>A</td>
<td>7</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>3132</td>
<td>Dietitians* and nutritionists</td>
<td>A</td>
<td>7</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>3141</td>
<td>Audiologists and speech-language pathologists *</td>
<td>A</td>
<td>7</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>3142</td>
<td>Physiotherapists *</td>
<td>A</td>
<td>7</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>3143</td>
<td>Occupational therapists *</td>
<td>A</td>
<td>7</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>3211</td>
<td>Medical laboratory technologists *</td>
<td>B</td>
<td>7</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>3212</td>
<td>Medical laboratory technicians and pathologists&rsquo; assistants</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>3213</td>
<td>Animal health technologists and veterinary technicians</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>3214</td>
<td>Respiratory therapists, clinical perfusionists and cardiopulmonary technologists *</td>
<td>B</td>
<td>7</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>3215</td>
<td>Medical radiation technologists *</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>3219</td>
<td>Other medical technologists and technicians (except dental health)</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>3222</td>
<td>Dental hygienists and dental therapists *</td>
<td>B</td>
<td>7</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>3236</td>
<td>Massage therapists</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
</tbody>
</table>
<h2><br />
<strong>4. Occupations in Social Science, Education, Government Service and Religion </strong></h2>
<table border="2" class="table tbl" style="border-color: #000;" width="100%">
<tbody>
<tr class="crs_heading">
<td>NOC</td>
<td>Occupation Title</td>
<td>Skill Level</td>
<td>Minimum CLB</td>
<td>S<br />
W<br />
O</td>
<td>S<br />
W<br />
M</td>
<td>I<br />
E<br />
S</td>
</tr>
<tr>
<td>0423</td>
<td>Managers in social, community and correctional services</td>
<td>0</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>4112</td>
<td>Lawyers and Quebec notaries *</td>
<td>A</td>
<td>7</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>4151</td>
<td>Psychologists *</td>
<td>A</td>
<td>7</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>4152</td>
<td>Social workers</td>
<td>A</td>
<td>7</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>4153</td>
<td>Family, marriage and other related counsellors</td>
<td>A</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>4161</td>
<td>Natural and applied science policy researchers, consultants and program officers</td>
<td>A</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>4163</td>
<td>Business development officers and marketing researchers and consultants</td>
<td>A</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>4164</td>
<td>Social policy researchers, consultants and program officers</td>
<td>A</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>4165</td>
<td>Health policy researchers, consultants and program officers</td>
<td>A</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>4166</td>
<td>Education policy researchers, consultants and program officers</td>
<td>A</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>4167</td>
<td>Recreation, sports and fitness policy researchers, consultants and program officers</td>
<td>A</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>4168</td>
<td>Program officers unique to government</td>
<td>A</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>4211</td>
<td>Paralegal and related occupations</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>4212</td>
<td>Social and community service workers</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>4214</td>
<td>Early childhood educators and assistants</td>
<td>B</td>
<td>7</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>4215</td>
<td>Instructors of persons with disabilities</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
</tbody>
</table>
<h2><br />
<strong>5. Occupations in Art, Culture, Recreation and Sport </strong></h2>
<table border="2" class="table tbl" style="border-color: #000;" width="100%">
<tbody>
<tr class="crs_heading">
<td>NOC</td>
<td>Occupation Title</td>
<td>Skill Level</td>
<td>Minimum CLB</td>
<td>S<br />
W<br />
O</td>
<td>S<br />
W<br />
M</td>
<td>I<br />
E<br />
S</td>
</tr>
<tr>
<td>0513</td>
<td>Recreation, sports and fitness program and service directors</td>
<td>0</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>5131</td>
<td>Producers, directors, choreographers and related occupations</td>
<td>A</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>5225</td>
<td>Audio and video recording technicians</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>5241</td>
<td>Graphic designers and illustrators</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>5242</td>
<td>Interior designers and interior decorators</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>5243</td>
<td>Theatre, fashion, exhibit and other creative designers</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>5254</td>
<td>Program leaders and instructors in recreation, sport and fitness</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
</tbody>
</table>
<h2><br />
<strong>6. Sales and Service Occupations </strong></h2>
<table border="2" class="table tbl" style="border-color: #000;" width="100%">
<tbody>
<tr class="crs_heading">
<td>NOC</td>
<td>Occupation Title</td>
<td>Skill Level</td>
<td>Minimum CLB</td>
<td>S<br />
W<br />
O</td>
<td>S<br />
W<br />
M</td>
<td>I<br />
E<br />
S</td>
</tr>
<tr>
<td>0601</td>
<td>Corporate sales managers</td>
<td>0</td>
<td>5</td>
<td>&nbsp;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>0621</td>
<td>Retail and wholesale trade managers</td>
<td>0</td>
<td>5</td>
<td>&nbsp;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>0651</td>
<td>Managers in customer and personal services, n.e.c.</td>
<td>0</td>
<td>5</td>
<td>&nbsp;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>6221</td>
<td>Technical sales specialists &ndash; wholesale trade</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>6222</td>
<td>Retail and wholesale buyers</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>6232</td>
<td>Real estate agents and salespersons</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>6235</td>
<td>Financial sales representatives</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>6311</td>
<td>Food service supervisors</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>6322</td>
<td>Cooks</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>6332</td>
<td>Bakers</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
</tbody>
</table>
<h2><br />
<strong>7. Trades, Transport and Equipment Operators and Related Occupations </strong></h2>
<table border="2" class="table tbl" style="border-color: #000;" width="100%">
<tbody>
<tr class="crs_heading">
<td>NOC</td>
<td>Occupation Title</td>
<td>Skill Level</td>
<td>Minimum CLB</td>
<td>S<br />
W<br />
O</td>
<td>S<br />
W<br />
M</td>
<td>I<br />
E<br />
S</td>
</tr>
<tr>
<td>0711</td>
<td>Construction managers</td>
<td>0</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>0712</td>
<td>Home building and renovation managers</td>
<td>0</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>0714</td>
<td>Facility operation and maintenance managers</td>
<td>0</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>0731</td>
<td>Managers in transportation</td>
<td>0</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>7231</td>
<td>Machinists and machining and tooling inspectors</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>7232</td>
<td>Tool and die makers</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>7233</td>
<td>Sheet metal workers</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>7237</td>
<td>Welders and related machine operators</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>7241</td>
<td>Electricians (except industrial and power system) **</td>
<td>B</td>
<td>6</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>7242</td>
<td>Industrial electricians **</td>
<td>B</td>
<td>6</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>7244</td>
<td>Electrical power line and cable workers</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>7245</td>
<td>Telecommunications line and cable workers</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>7246</td>
<td>Telecommunications installation and repair workers</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>7251</td>
<td>Plumbers</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>7271</td>
<td>Carpenters</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>7282</td>
<td>Concrete finishers</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>7284</td>
<td>Plasterers, drywall installers and finishers and lathers</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>7294</td>
<td>Painters and decorators (except interior decorators)</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>7295</td>
<td>Floor covering installers</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>7311</td>
<td>Construction millwrights and industrial mechanics</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>7312</td>
<td>Heavy-duty equipment mechanics</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>7313</td>
<td>Heating, refrigeration and air conditioning mechanics **</td>
<td>B</td>
<td>6</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>7315</td>
<td>Aircraft mechanics and aircraft inspectors</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>7316</td>
<td>Machine fitters</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>7321</td>
<td>Automotive service technicians, truck and bus mechanics and mechanical repairers</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>7322</td>
<td>Motor vehicle body repairers</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>7361</td>
<td>Railway and yard locomotive engineers</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>7362</td>
<td>Railway conductors and brakemen/women</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>7371</td>
<td>Crane operators **</td>
<td>B</td>
<td>6</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
</tbody>
</table>
<h2><br />
<strong>8. Occupations Unique to Primary Industry </strong></h2>
<table border="2" class="table tbl" style="border-color: #000;" width="100%">
<tbody>
<tr class="crs_heading">
<td>NOC</td>
<td>Occupation Title</td>
<td>Skill Level</td>
<td>Minimum CLB</td>
<td>S<br />
W<br />
O</td>
<td>S<br />
W<br />
M</td>
<td>I<br />
E<br />
S</td>
</tr>
<tr>
<td>0821</td>
<td>Managers in agriculture</td>
<td>0</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
</tbody>
</table>
<h2><br />
<strong>9. Occupations Unique to Processing, Manufacturing and Utilities </strong></h2>
<table border="2" class="table tbl" style="border-color: #000;" width="100%">
<tbody>
<tr class="crs_heading">
<td>NOC</td>
<td>Occupation Title</td>
<td>Skill Level</td>
<td>Minimum CLB</td>
<td>S<br />
W<br />
O</td>
<td>S<br />
W<br />
M</td>
<td>I<br />
E<br />
S</td>
</tr>
<tr>
<td>0911</td>
<td>Manufacturing managers</td>
<td>0</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>0912</td>
<td>Utilities managers</td>
<td>0</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
<tr>
<td>9241</td>
<td>Power engineers and power systems operators</td>
<td>B</td>
<td>5</td>
<td>&bull;</td>
<td>&bull;</td>
<td>&bull;</td>
</tr>
</tbody>
</table>
</div>
</div>
		 <div class="col-md-4 col-sm-4 col-xs-12">
		 <?php include('enquiry-form.php')?>
		 </div>
                
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>