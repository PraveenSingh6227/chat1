<?php include 'inc/header.php'; ?>
<div class="page-area">
    <div class="breadcumb-overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="breadcrumb">
                    <div class="bread-inner">
                        <div class="section-headline white-headline">
                            <h2>Quebec Occupation <span class="color"> in-Demand List</span></h2>
                        </div>
                        <ul class="breadcrumb-bg">
                            <li class="home-bread"><a href="index.php">Home</a></li>
                            <li>Quebec Occupation in-Demand List</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="team-area bg-color pd-35">
    <div class="container">
        <!-- section head -->
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-headline text-center">
                    <h3>Quebec Occupation <span class="color"> in-Demand List</span></h3>
                </div>
            </div>
        </div>
        <div class="row">
		 <div class="col-md-8 col-sm-8 col-xs-12" style="box-shadow: 5px 3px 10px rgb(0 0 0 / 10%);">
<div class='text-justify innerpage-text'><p><strong>About <a href="../quebec-visa.html" target="_blank">Quebec Immigration</a></strong></p>
<p>Quebec is one of Canada&rsquo;s most coveted immigration destinations, owing to its vibrant culture, diverse population, metropolitan lifestyle, urban infrastructure, lucrative job market and ample scope for business innovation. Qualified candidates can successfully immigrate to Quebec through any of the following pathways:</p>
<ul>
<li>Quebec Skilled Worker Program</li>
<li>Quebec Investor Program</li>
<li>Quebec Entrepreneur Program</li>
<li>Quebec Self-Employed Worker Program</li>
<li>Program for Refugees Abroad</li>
</ul>
<p><strong>Quebec Occupation in Demand List 2022</strong></p>
<p>Skilled workers applying under the QSWP must ensure that their primary occupation is featured on the Quebec Occupation in Demand List 2022, which indicates all the skills shortages in Quebec&rsquo;s labor market that cannot be filled by the local population. Thus, qualified foreign nationals are invited to fill these vacancies. The list is regularly updated, and is one of the major eligibility requirements for skilled immigration to Quebec.</p>
<p><strong>Three new pathways added for Quebec immigration</strong></p>
<p>Quebec Immigration Ministry released a new mandate which entails the introduction of three new immigration pathways for the aspirants. Each program will allow the selection of maximum 550 applicants and their family members annually. Below are the programs:</p>
<ul>
<li style="text-align: justify;"><strong>The permanent immigration pilot program for workers in food processing</strong> &ndash; The PR pathway will be for temporary foreign workers who have jobs in the food processing sector in Quebec. Program will commence on March 24, 2021.</li>
<li style="text-align: justify;"><strong>The permanent immigration pilot program for orderlies</strong> &ndash; It is for applicants as orderlies to fill critical labour shortage in this field. Program will commence on March 31, 2021.</li>
<li style="text-align: justify;"><strong>The permanent immigration pilot program for workers in the AI, information technologies and visual effects (IT/VE) sectors</strong> &ndash; There are two streams: AI and IT/VE for tech professionals which will come into effect on April 22, 2021.</li>
</ul>
<p>&nbsp;</p>
<table cellpadding="0" cellspacing="0">
<tbody>
<tr>
<td valign="top"><b>NOC Code</b></td>
<td valign="top"><b>Occupation</b></td>
</tr>
<tr>
<td valign="top">0111</td>
<td valign="top">Financial managers</td>
</tr>
<tr>
<td valign="top">0112</td>
<td valign="top">Human Resources Managers</td>
</tr>
<tr>
<td valign="top">0121</td>
<td valign="top">Insurance, Real Estate and Financial Brokerage Managers</td>
</tr>
<tr>
<td valign="top">0122</td>
<td valign="top">Banking, credit and other investment managers</td>
</tr>
<tr>
<td valign="top">0124</td>
<td valign="top">Advertising, marketing and public relations managers</td>
</tr>
<tr>
<td valign="top">0131</td>
<td valign="top">Telecommunication carriers managers</td>
</tr>
<tr>
<td valign="top">0213</td>
<td valign="top">IT system managers *</td>
</tr>
<tr>
<td valign="top">0311</td>
<td valign="top">Managers in health care</td>
</tr>
<tr>
<td valign="top">0421</td>
<td valign="top">Administrators &ndash; post-secondary education and vocational training (only for educational institutions designated and recognized by the Ministry of Education and Higher Education or another ministry or agency authorized by the State).</td>
</tr>
<tr>
<td valign="top">0422</td>
<td valign="top">Supervisors / School Principals and Administrators / Administrators of education at primary and secondary school programs (for educational institutions designated and recognized by the Ministry of Education and Higher Education or another ministry or mandatory agency of the State)</td>
</tr>
<tr>
<td valign="top">0423</td>
<td valign="top">Managers in social, community and correctional services</td>
</tr>
<tr>
<td valign="top">0711</td>
<td valign="top">Construction managers</td>
</tr>
<tr>
<td valign="top">0712</td>
<td valign="top">Home construction managers and renovators</td>
</tr>
<tr>
<td valign="top">0821</td>
<td valign="top">Managers in agriculture</td>
</tr>
<tr>
<td valign="top">0822</td>
<td valign="top">Horticulture managers</td>
</tr>
<tr>
<td valign="top">0911</td>
<td valign="top">Manufacturing Managers</td>
</tr>
<tr>
<td valign="top">1111</td>
<td valign="top">Financial auditors and accountants</td>
</tr>
<tr>
<td valign="top">1112</td>
<td valign="top">Financial analysts and investment analysts</td>
</tr>
<tr>
<td valign="top">1113</td>
<td valign="top">Securities agents, investment agents and traders</td>
</tr>
<tr>
<td valign="top">1114</td>
<td valign="top">Financial planners and financial advisers (only this name)</td>
</tr>
<tr>
<td valign="top">1121</td>
<td valign="top">Human resources professionals</td>
</tr>
<tr>
<td valign="top">1122</td>
<td valign="top">Professional occupations in business management consulting</td>
</tr>
<tr>
<td valign="top">1212</td>
<td valign="top">Supervisors, finance and insurance office workers</td>
</tr>
<tr>
<td valign="top">1213</td>
<td valign="top">Supervisors, library, correspondence and other information workers</td>
</tr>
<tr>
<td valign="top">1214</td>
<td valign="top">Postal and courier service supervisors</td>
</tr>
<tr>
<td valign="top">1215</td>
<td valign="top">Supervisors, supply chain, tracking and scheduling co-ordination occupations</td>
</tr>
<tr>
<td valign="top">1222</td>
<td valign="top">Executive assistants</td>
</tr>
<tr>
<td valign="top">1223</td>
<td valign="top">Human Resources and Recruitment Officers</td>
</tr>
<tr>
<td valign="top">1224</td>
<td valign="top">Property management officers</td>
</tr>
<tr>
<td valign="top">1225</td>
<td valign="top">Purchasing agents</td>
</tr>
<tr>
<td valign="top">1243</td>
<td valign="top">Medical administrative assistants</td>
</tr>
<tr>
<td valign="top">1251</td>
<td valign="top">Court reporters, medical transcriptionists and related occupations</td>
</tr>
<tr>
<td valign="top">1252</td>
<td valign="top">Health information management occupations</td>
</tr>
<tr>
<td valign="top">1311</td>
<td valign="top">Accounting technicians and bookkeepers</td>
</tr>
<tr>
<td valign="top">1312</td>
<td valign="top">Insurance Adjusters and Claims Examiners</td>
</tr>
<tr>
<td valign="top">1313</td>
<td valign="top">Insurers / Underwriters</td>
</tr> 
<tr>
<td valign="top">1315</td>
<td valign="top">Maritime brokers (only this designation)</td>
</tr>
<tr>
<td valign="top">2112</td>
<td valign="top">Chemists</td>
</tr>
<tr>
<td valign="top">2113</td>
<td valign="top">Geoscientists and oceanographers</td>
</tr>
<tr>
<td valign="top">2121</td>
<td valign="top">Biologists and related scientists</td>
</tr>
<tr>
<td valign="top">2122</td>
<td valign="top">Forest science professionals</td>
</tr>
<tr>
<td valign="top">2123</td>
<td valign="top">Agricultural Representatives, Consultants and Specialists</td>
</tr>
<tr>
<td valign="top">2131</td>
<td valign="top">Civil engineers</td>
</tr>
<tr>
<td valign="top">2132</td>
<td valign="top">Mechanical Engineers</td>
</tr>
<tr>
<td valign="top">2133</td>
<td valign="top">Electrical and Electronics Engineers</td>
</tr>
<tr>
<td valign="top">2134</td>
<td valign="top">Chemical engineers</td>
</tr>
<tr>
<td valign="top">2141</td>
<td valign="top">Industrial and manufacturing engineers</td>
</tr>
<tr>
<td valign="top">2142</td>
<td valign="top">Metallurgical and materials engineers</td>
</tr>
<tr>
<td valign="top">2143</td>
<td valign="top">Mining engineers</td>
</tr>
<tr>
<td valign="top">2146</td>
<td valign="top">Aerospace engineers</td>
</tr>
<tr>
<td valign="top">2147</td>
<td valign="top">Computer engineers (except software engineers and designers ) *</td>
</tr>
<tr>
<td valign="top">2151</td>
<td valign="top">architects</td>
</tr>
<tr>
<td valign="top">2153</td>
<td valign="top">Urban and land use planners</td>
</tr>
<tr>
<td valign="top">2154</td>
<td valign="top">Land Surveyors / Surveyors</td>
</tr>
<tr>
<td valign="top">2161</td>
<td valign="top">Mathematicians, statisticians and actuaries *</td>
</tr>
<tr>
<td valign="top">2171</td>
<td valign="top">Computer analysts and consultants *</td>
</tr>
<tr>
<td valign="top">2172</td>
<td valign="top">Database analysts and data administrators *</td>
</tr>
<tr>
<td valign="top">2173</td>
<td valign="top">Software engineers and designers *</td>
</tr>
<tr>
<td valign="top">2174</td>
<td valign="top">Programmers and Interactive Media Developers *</td>
</tr>
<tr>
<td valign="top">2175</td>
<td valign="top">Web Designers and Developers *</td>
</tr>
<tr>
<td valign="top">2223</td>
<td valign="top">Forest science technologists and technicians</td>
</tr>
<tr>
<td valign="top">2224</td>
<td valign="top">Natural and fishery technicians</td>
</tr>
<tr>
<td valign="top">2225</td>
<td valign="top">Landscape and horticulture technicians and specialists</td>
</tr>
<tr>
<td valign="top">2231</td>
<td valign="top">Civil engineering technologists and technicians</td>
</tr>
<tr>
<td valign="top">2232</td>
<td valign="top">Mechanical engineering technologists and technicians</td>
</tr>
<tr>
<td valign="top">2233</td>
<td valign="top">Industrial engineering and manufacturing technologists and technicians</td>
</tr>
<tr>
<td valign="top">2234</td>
<td valign="top">Construction estimators</td>
</tr>
<tr>
<td valign="top">2241</td>
<td valign="top">Electronic and electrical engineering technologists and technicians</td>
</tr>
<tr>
<td valign="top">2243</td>
<td valign="top">Industrial instrument technicians and mechanics</td>
</tr>
<tr>
<td valign="top">2251</td>
<td valign="top">Architectural technologists and technicians</td>
</tr>
<tr>
<td valign="top">2254</td>
<td valign="top">Land survey technologists and technicians</td>
</tr>
<tr>
<td valign="top">2263</td>
<td valign="top">Public health, environment and occupational health and safety inspectors</td>
</tr>
<tr>
<td valign="top">2264</td>
<td valign="top">Construction inspectors</td>
</tr>
<tr>
<td valign="top">2281</td>
<td valign="top">Computer network technicians *</td>
</tr>
<tr>
<td valign="top">2282</td>
<td valign="top">User support workers</td>
</tr>
<tr>
<td valign="top">2283</td>
<td valign="top">Computer systems assessors and the video game tester designation *</td>
</tr>
<tr>
<td valign="top">3011</td>
<td valign="top">Nursing co-ordinators and supervisors</td>
</tr>
<tr>
<td valign="top">3012</td>
<td valign="top">Registered Nurses and Registered Psychiatric Nurses / Registered Psychiatric Nurses</td>
</tr>
<tr>
<td valign="top">3111</td>
<td valign="top">Specialist doctors</td>
</tr>
<tr>
<td valign="top">3112</td>
<td valign="top">General Practitioners and Family Physicians</td>
</tr>
<tr>
<td valign="top">3113</td>
<td valign="top">Dentists</td>
</tr>
<tr>
<td valign="top">3114</td>
<td valign="top">Vets</td>
</tr>
<tr>
<td valign="top">3121</td>
<td valign="top">Optometrists</td>
</tr>
<tr>
<td valign="top">3122</td>
<td valign="top">Chiropractor / Chiropractors</td>
</tr>
<tr>
<td valign="top">3124</td>
<td valign="top">Related primary health care practitioners</td>
</tr>
<tr>
<td valign="top">3131</td>
<td valign="top">Chemists / Pharmacists</td>
</tr>
<tr>
<td valign="top">3132</td>
<td valign="top">Dietitians and nutritionists</td>
</tr>
<tr>
<td valign="top">3141</td>
<td valign="top">Audiologists and speech-language pathologists</td>
</tr>
<tr>
<td valign="top">3142</td>
<td valign="top">Physiotherapists</td>
</tr>
<tr>
<td valign="top">3143</td>
<td valign="top">Occupational Therapists</td>
</tr>
<tr>
<td valign="top">3211</td>
<td valign="top">Medical laboratory technologists</td>
</tr>
<tr>
<td valign="top">3212</td>
<td valign="top">Medical laboratory technicians and pathology assistants</td>
</tr>
<tr>
<td valign="top">3213</td>
<td valign="top">Animal health technologists and veterinary technicians</td>
</tr>
<tr>
<td valign="top">3214</td>
<td valign="top">Respiratory therapists, cardiovascular perfusionists and cardiopulmonary technologists</td>
</tr>
<tr>
<td valign="top">3215</td>
<td valign="top">Medical radiation technologists</td>
</tr>
<tr>
<td valign="top">3219</td>
<td valign="top">Technical assistants in pharmacy (only this name)</td>
</tr>
<tr>
<td valign="top">3221</td>
<td valign="top">Denturists</td>
</tr>
<tr>
<td valign="top">3222</td>
<td valign="top">Hygienists and dental therapists</td>
</tr>
<tr>
<td valign="top">3233</td>
<td valign="top">Licensed practical nurses</td>
</tr>
<tr>
<td valign="top">3234</td>
<td valign="top">Paramedics</td>
</tr>
<tr>
<td valign="top">4011</td>
<td valign="top">University professors and lecturers</td>
</tr>
<tr>
<td valign="top">4012</td>
<td valign="top">Post-secondary teaching and research assistants</td>
</tr>
<tr>
<td valign="top">4021</td>
<td valign="top">College Teachers and Other Vocational Training Instructors (Only for Educational Institutions Designated by the Ministry of Education and Higher Education or another government department or agency)</td>
</tr>
<tr>
<td valign="top">4031</td>
<td valign="top">Secondary school teachers (only for educational institutions designated and recognized by the Ministry of Education and Higher Education or another ministry or agency authorized by the State)</td>
</tr>
<tr>
<td valign="top">4032</td>
<td valign="top">Elementary and preschool teachers (only for educational institutions designated and recognized by the Ministry of Education and Higher Education or another ministry or agency authorized by the State)</td>
</tr>
<tr>
<td valign="top">4033</td>
<td valign="top">School Information Consultants</td>
</tr>
<tr>
<td valign="top">4112</td>
<td valign="top">Lawyers (everywhere in Canada) and notaries (in Quebec)</td>
</tr>
<tr>
<td valign="top">4151</td>
<td valign="top">Psychologists</td>
</tr>
<tr>
<td valign="top">4152</td>
<td valign="top">Social workers</td>
</tr>
<tr>
<td valign="top">4153</td>
<td valign="top">Marriage therapists / marriage therapists, family therapists / family therapists and psychoeducators / psychoeducators (only this name)</td>
</tr>
<tr>
<td valign="top">4156</td>
<td valign="top">Employment counselors</td>
</tr>
<tr>
<td valign="top">4161</td>
<td valign="top">Natural and applied sciences researchers, consultants and program officers</td>
</tr>
<tr>
<td valign="top">4162</td>
<td valign="top">Economists, researchers and economic policy analysts</td>
</tr>
<tr>
<td valign="top">4163</td>
<td valign="top">Economic development officers, marketers and marketing consultants</td>
</tr>
<tr>
<td valign="top">4164</td>
<td valign="top">Social Policy Researchers, Consultants and Program Officers</td>
</tr>
<tr>
<td valign="top">4165</td>
<td valign="top">Health Policy Researchers, Consultants and Program Officers</td>
</tr>
<tr>
<td valign="top">4166</td>
<td valign="top">Education Policy Researchers, Consultants and Program Officers</td>
</tr>
<tr>
<td valign="top">4211</td>
<td valign="top">Legal technicians (only this name)</td>
</tr>
<tr>
<td valign="top">4212</td>
<td valign="top">Social and community service workers</td>
</tr>
<tr>
<td valign="top">4214</td>
<td valign="top">Early childhood educators and assistants (whose employer is authorized to hire is an educational institution designated and recognized by the Minist&egrave;re de l&rsquo;&Eacute;ducation et de l&rsquo;Enseignement sup&eacute;rieur or another ministry or an authorized agency of the State, or a daycare service recognized by the Ministry of Family)</td>
</tr>
<tr>
<td valign="top">4215</td>
<td valign="top">Instructors of persons with disabilities</td>
</tr>
<tr>
<td valign="top">4312</td>
<td valign="top">Fire / female firefighters</td>
</tr>
<tr>
<td valign="top">5125</td>
<td valign="top">Translators, terminologists and interpreters</td>
</tr>
<tr>
<td valign="top">5131</td>
<td valign="top">Producers, directors, choreographers and the name technical, creative and artistic directors, technical, creative and artistic directors and project managers &ndash; visual effects and video games</td>
</tr>
<tr>
<td valign="top">5211</td>
<td valign="top">Library and public archive technicians</td>
</tr>
<tr>
<td valign="top">5223</td>
<td valign="top">Graphic arts technicians</td>
</tr>
<tr>
<td valign="top">5241</td>
<td valign="top">Graphic designers and illustrators *</td>
</tr>
<tr>
<td valign="top">6211</td>
<td valign="top">Sales Supervisors &ndash; Retail</td>
</tr>
<tr>
<td valign="top">6221</td>
<td valign="top">Technical Sales Specialists &ndash; Wholesale Trade</td>
</tr>
<tr>
<td valign="top">6231</td>
<td valign="top">Insurance agents and brokers</td>
</tr>
<tr>
<td valign="top">6235</td>
<td valign="top">Financial sales representatives</td>
</tr>
<tr>
<td valign="top">6314</td>
<td valign="top">Information and customer service supervisors</td>
</tr>
<tr>
<td valign="top">6331</td>
<td valign="top">Butchers, meat cutters and fishmongers &ndash; wholesale and retail</td>
</tr>
<tr>
<td valign="top">7201</td>
<td valign="top">Supervisors, machinists and metal forming, profiling and assembling trades personnel (only this designation)</td>
</tr>
<tr>
<td valign="top">7202</td>
<td valign="top">Electricity and telecommunications foremen / women (only this designation)</td>
</tr>
<tr>
<td valign="top">7205</td>
<td valign="top">Contractors and supervisors, other construction trades, installers, repairers and servicers</td>
</tr>
<tr>
<td valign="top">7231</td>
<td valign="top">Machinists and Machining and Tooling Inspectors</td>
</tr>
<tr>
<td valign="top">7233</td>
<td valign="top">Sheet Metal / Metal Workers</td>
</tr>
<tr>
<td valign="top">7236</td>
<td valign="top">Ironworkers</td>
</tr>
<tr>
<td valign="top">7237</td>
<td valign="top">Welders and Related Machine Operators</td>
</tr>
<tr>
<td valign="top">7242</td>
<td valign="top">Industrial electricians</td>
</tr>
<tr>
<td valign="top">7245</td>
<td valign="top">Telecommunications line and cable workers</td>
</tr>
<tr>
<td valign="top">7246</td>
<td valign="top">Telecommunications equipment installers and repairers</td>
</tr>
<tr>
<td valign="top">7251</td>
<td valign="top">Plumbers</td>
</tr>
<tr>
<td valign="top">7252</td>
<td valign="top">Steamfitters, pipefitters and sprinkler system installers</td>
</tr>
<tr>
<td valign="top">7271</td>
<td valign="top">Carpenters / Carpenters</td>
</tr>
<tr>
<td valign="top">7281</td>
<td valign="top">Bricklayers / Bricklayers</td>
</tr>
<tr>
<td valign="top">7282</td>
<td valign="top">Concrete finishers</td>
</tr>
<tr>
<td valign="top">7283</td>
<td valign="top">Tiles / Finishers</td>
</tr>
<tr>
<td valign="top">7284</td>
<td valign="top">Plasterers / Drywall installers / applicators and pavers / finishers and Interior Systems Drywall / Lathers</td>
</tr>
<tr>
<td valign="top">7291</td>
<td valign="top">Roofers and shinglers</td>
</tr>
<tr>
<td valign="top">7292</td>
<td valign="top">Glaziers / vitri&egrave;res</td>
</tr>
<tr>
<td valign="top">7293</td>
<td valign="top">Insulators / Insulators</td>
</tr>
<tr>
<td valign="top">7294</td>
<td valign="top">Painters and decorators (except interior decorators)</td>
</tr>
<tr>
<td valign="top">7295</td>
<td valign="top">Floor covering installers</td>
</tr>
<tr>
<td valign="top">7301</td>
<td valign="top">Mechanical foreman / woman (only this designation)</td>
</tr>
<tr>
<td valign="top">7302</td>
<td valign="top">Supervisors, heavy equipment operator teams (only this designation)</td>
</tr>
<tr>
<td valign="top">7303</td>
<td valign="top">Supervisors, printing and related occupations</td>
</tr>
<tr>
<td valign="top">7311</td>
<td valign="top">Construction millwrights and industrial mechanics</td>
</tr>
<tr>
<td valign="top">7312</td>
<td valign="top">Heavy-duty equipment mechanics</td>
</tr>
<tr>
<td valign="top">7316</td>
<td valign="top">Machine fitters</td>
</tr>
<tr>
<td valign="top">7318</td>
<td valign="top">Elevator Constructors and Mechanics</td>
</tr>
<tr>
<td valign="top">7321</td>
<td valign="top">Motor vehicle, truck and bus mechanics and repairers</td>
</tr>
<tr>
<td valign="top">7331</td>
<td valign="top">Oil and solid fuel burner installers</td>
</tr>
<tr>
<td valign="top">7332</td>
<td valign="top">Appliance servicers and repairers</td>
</tr>
<tr>
<td valign="top">7333</td>
<td valign="top">Electromechanical / Mechanics</td>
</tr>
<tr>
<td valign="top">7361</td>
<td valign="top">Locomotive and Yard Mechanics</td>
</tr>
<tr>
<td valign="top">7371</td>
<td valign="top">Crane / Operators</td>
</tr>
<tr>
<td valign="top">7381</td>
<td valign="top">Printing press operators</td>
</tr>
<tr>
<td valign="top">8211</td>
<td valign="top">Supervisors, logging</td>
</tr>
<tr>
<td valign="top">8241</td>
<td valign="top">Logging machinery operators</td>
</tr>
<tr>
<td valign="top">8252</td>
<td valign="top">Foremen / women, agricultural services, supervisors of farms and specialized workers in animal husbandry (only this designation)</td>
</tr>
<tr>
<td valign="top">9212</td>
<td valign="top">Supervisors, petroleum refining, gas and chemical processing, and utilities</td>
</tr>
<tr>
<td valign="top">9213</td>
<td valign="top">Supervisors, food, beverage and associated products processing</td>
</tr>
<tr>
<td valign="top">9214</td>
<td valign="top">Supervisors, rubber and plastics product manufacturing</td>
</tr>
<tr>
<td valign="top">9215</td>
<td valign="top">Supervisors, forest product processing</td>
</tr>
<tr>
<td valign="top">9235</td>
<td valign="top">Operators in pulp and paper pulping, papermaking and coating operators</td>
</tr>
<tr>
<td valign="top">9241</td>
<td valign="top">Power station mechanics and power system operators</td>
</tr>
<tr>
<td valign="top">9243</td>
<td valign="top">Water and waste treatment plant operators</td>
</tr>
</tbody>
</table>
<p><br />
<a href="../check-your-eligibility.html" style="padding:7px 5px ;background: #f00 !important; color: #fff; line-height: 24px; border-radius: 5px; margin-bottom: 6px;  width: 140px;" target="_blank" title="Check Your Eligibility">Check Your Eligibility</a><br />
<br />
<strong>Application Process for Permanent Residence in Quebec</strong></p>
<p>Each immigration pathway has a distinct set of eligibility requirements and application procedures. The most popular route to permanent residence is the&nbsp;<strong><a href="../quebec-immigration/skilled-worker-program.html" target="_blank">Quebec Skilled Worker Program</a></strong>&nbsp;(QSWP), which unfolds in two stages.</p>
<p><br />
<a href="authorized-representative-canada.html" style="padding:7px 5px ;background: #f00 !important; color: #fff; line-height: 24px; border-radius: 5px; margin-bottom: 6px;  width: 140px;" target="_blank" title="Our Canada RCIC Agent">Our Canada RCIC Agent</a><br />
&nbsp;</p>
<p><strong>Stage 1 &ndash; Obtain the Quebec Selection Certificate</strong></p>
<p>Aspirants must submit an online Expression of Interest through the&nbsp;<em>Arrima</em>&nbsp;portal. The most highly eligible candidates will receive an invitation to apply for permanent selection from the Minist&egrave;re. Within 60 days of receiving the invitation, the candidate must apply for permanent selection to the Minist&egrave;re &ndash; online via&nbsp;<em>Mon Projet Qu&eacute;bec</em>. If approved, the candidate receives a Quebec Selection Certificate.</p>
<p><br />
<a href="../expressyourinterest.html" style="padding:7px 5px ;background: #f00 !important; color: #fff; line-height: 24px; border-radius: 5px; margin-bottom: 6px;  width: 220px;" target="_blank" title="Immigration Visa Enquiry Form">Free Profile Assessment and Visa Guidance</a></p>
<p><br />
<strong>Stage 2 &ndash; Apply for Permanent Residence</strong></p>
<p>Upon obtaining the selection certificate, a candidate must apply for the&nbsp;<a href="permanent-resident-canada.html" target="_blank"><strong>Canada permanent resident&nbsp;visa</strong></a>&nbsp;to the federal immigration authority &ndash; Immigration, Refugees and Citizenship Canada &ndash; as a Quebec-selected skilled worker. After due verification, IRCC may award a PR visa to the applicant.</p>
<p>&nbsp;</p>
</div>
</div>
		 <div class="col-md-4 col-sm-4 col-xs-12">
		 <?php include('enquiry-form.php')?>
		 </div>
                
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>