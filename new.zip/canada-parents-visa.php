<?php include 'inc/header.php'; ?>
<div class="page-area">
    <div class="breadcumb-overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="breadcrumb">
                    <div class="bread-inner">
                        <div class="section-headline white-headline">
                            <h2>Canada <span class="color"> Immigration</span></h2>
                        </div>
                        <ul class="breadcrumb-bg">
                            <li class="home-bread"><a href="index.php">Home</a></li>
                            <li>Canada Immigration</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="team-area bg-color pd-35">
    <div class="container">
        <!-- section head -->
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-headline text-center">
                    <h3>Canada <span class="color"> Immigration</span></h3>
                </div>
            </div>
        </div>
        <div class="row">
		 <div class="col-md-8 col-sm-8 col-xs-12" style="box-shadow: 5px 3px 10px rgb(0 0 0 / 10%);">
<div class='text-justify innerpage-text'><p>Once a year, Canada accepts applications for the Parents and Grandparents Program for a limited period. Through this pathway, Canadian citizens and permanent residents can sponsor their parents and grandparents for permanent <a href="../canada-immigration.html" target="_blank">Canada immigration</a>. It is one of those programs through which Immigration, Refugees, and Citizenship Canada (IRCC) allow family reunification.</p>
<p>Sometimes, this program is also referred to as the &lsquo;Canada Super Visa,&rsquo; but it is officially called the Parents and Grandparents Program.</p>
<p><strong>How to Sponsor Your Parents and Grandparents in 2021</strong></p>
<p><strong>Step 1:</strong> If you meet the eligibility criteria for sponsoring a parent/grandparent, you can submit an online interest to Sponsor Form during the period for indicating interest, which is announced by IRCC every year.</p>
<p><strong>Step 2:</strong> IRCC reviews the submissions, removes duplicates, and uses a lottery system to select potential sponsors randomly. Those selected in the lottery receive invitations to apply for the parent or grand-parent visa Canada, i.e., sponsorship.</p>
<p><strong><em>S</em><strong>tep </strong>3:</strong> Invited candidates must submit a complete application package before the deadline mentioned on the invitation. The IRCC will evaluate the applications and make a decision.</p>
<p><strong>Note:</strong> For Canadian citizens and permanent residents living in Quebec, sponsoring parents or grandparents are different.</p>
<p><strong>Parent Super Visa Requirements in Canada</strong></p>
<p>You must be considered eligible as a sponsor by meeting the following Super Visa Canada requirements:</p>
<ul>
<li>Be at least 18 years old</li>
<li>Be a Canadian permanent resident or citizen living in Canada</li>
<li>The person you are sponsoring should be under the family class</li>
<li>Sign an undertaking to provide requirements to the person you are sponsoring</li>
<li>You and the person you are sponsoring must sign an agreement confirming that both parties understand mutual responsibilities and obligations</li>
<li>Have sufficient income (alone or in combination with a co-signer, i.e., spouse/partner) for providing basic requirements to family members already in Canada as well as the person(s) being sponsored</li>
</ul>
<p><strong>Documents required by the applicant to obtain this visa</strong></p>
<p>The primary documents to be submitted by the sponsor include:</p>
<ul>
<li>Application to sponsor</li>
<li>Sponsorship undertaking and agreement</li>
<li>Financial evaluation</li>
<li>Generic Canada application form</li>
<li>Background/declaration Form</li>
<li>Additional information about family</li>
<li>Supplementary information on travels</li>
<li>All documents mentioned in the document checklist</li>
</ul>
<p><strong>Benefits of the Parents and Grandparents Program (PGP)</strong></p>
<p>If your application is approved, your parents and grandparents will enjoy the full benefits of permanent residence, including free healthcare and the right to apply for citizenship eventually. If they wish to, they can also work in Canada. They will be able to access a higher quality of life and comfort. Most importantly, it will allow for family reunification, which adds to your happiness and success as an immigrant.</p>
<p><strong>How to Apply for a Super Visa Canada </strong></p>
<div>
<p>The invited candidate must apply to become a sponsor within 60 days of receiving the invitation. The parent(s)/grandparent(s) must submit an application for permanent residence. These applications must be mailed together, along with the supporting documents and application fees (CAD 1,050 for each parent/grandparent). The processing time for this Canada Super Visa application is 20-24 months.</p>
<p>To check if you are eligible to become a sponsor and act quickly on submitting an application when the window to indicate interest opens, contact our seasoned experts. They have successfully navigated several parent/grandparent sponsorship procedures over the last 25 years. You may enrol for free counselling by calling on 8178788054 or writing to us at <a href="../cdn-cgi/l/email-protection.html#7b0c1e193b1a191312151a0d55181416"><span class="__cf_email__" data-cfemail="d6a1b3b496b7b4bebfb8b7a0f8b5b9bb">[email&#160;protected]</span></a>.</p>
</div>
</div>
</div>
		 <div class="col-md-4 col-sm-4 col-xs-12">
		 <?php include('enquiry-form.php')?>
		 </div>
                
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>