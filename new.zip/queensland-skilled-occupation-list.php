<?php include 'inc/header.php'; ?>
<div class="page-area">
    <div class="breadcumb-overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="breadcrumb">
                    <div class="bread-inner">
                        <div class="section-headline white-headline">
                            <h2>Queensland Skilled  <span class="color">  Occupation List</span></h2>
                        </div>
                        <ul class="breadcrumb-bg">
                            <li class="home-bread"><a href="index.php">Home</a></li>
                            <li>Queensland Skilled Occupation List</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="team-area bg-color pd-35">
    <div class="container">
        <!-- section head -->
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-headline text-center">
                    <h3>Queensland Skilled  <span class="color">  Occupation List</span></h3>
                </div>
            </div>
        </div>
        <div class="row">
		 <div class="col-md-8 col-sm-8 col-xs-12" style="box-shadow: 5px 3px 10px rgb(0 0 0 / 10%);">
<div class='text-justify innerpage-text'><p><strong>Queensland Skilled Occupation Lists</strong></p>
<p>Queensland&rsquo;s burgeoning economy offers a broad range of job opportunities to appropriately skilled professionals. Skilled immigration programs target prospective immigrants who can contribute to the local labour market by filling vacancies for in-demand occupations, which the local Australian population is unable to fill. These &lsquo;in-demand occupations&rsquo; are outlined in the Queensland Skilled Occupation Lists (QSOL).</p>
<p>There are various QSOLs, each of which details the occupation demand for specific candidate profiles.</p>
<p>The <strong>QSOL &lsquo;Offshore&rsquo; List</strong> showcases the occupational shortages in Queensland that can only be filled by overseas skilled workers who wish to live and work in the state.</p>
<p>The <strong>QSOL &lsquo;Masters Graduate&rsquo; List</strong> targets employable international postgraduate alumni from Queensland-based academic institutions.</p>
<p>The <strong>QSOL &lsquo;Working in Queensland&rsquo; List</strong> contains occupations whose demand must be satisfied by migrants who are currently living and working in Queensland, practicing their skilled occupation or a closely-related occupation.</p>
<p>Having an occupation that features on the relevant Skilled Occupation List one of the eligibility requirements for skilled workers or international students pursuing visa pathways to immigrate to Queensland. Applicants also have to undergo Skills Assessment from the relevant authority in Australia.</p>
<p>Each occupation on the list has a corresponding ANZSCO code and assessment authority. ANZSCO is the <em>Australian and New Zealand Standard Classification of Occupations</em>, which classifies occupations based on the skill level and qualifications required to practice them. The aspirant must first identify the ANZSCO code of their nominated occupation, and accordingly determine which assessment authority will conduct their Skills Assessment.</p>
<p>The&nbsp;<strong>Queensland Skilled Occupation Lists (QSOL)</strong>&nbsp;reflect the current labour demand for positions throughout Queensland. Check the category applicable to your current situation to see if your profession is in demand in Queensland.<br />
&nbsp;</p>
<table border="1" bordercolor="#CCC" cellpadding="8" cellspacing="0" height="100%" width="80%">
<tbody>
<tr bgcolor="#F00" style="color: rgb(255, 255, 255);">
<td><strong>ANZCO</strong></td>
<td><strong>Occupation</strong></td>
<td><strong>Assessing Authority</strong></td>
<td><strong>Subclass 489</strong></td>
<td><strong>Subclass 190</strong></td>
</tr>
<tr>
<td>121111</td>
<td>Aquaculture Farmer</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>121211</td>
<td>Cotton Grower</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>121212</td>
<td>Flower Grower</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>121213</td>
<td>Fruit or Nut Grower</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>121215</td>
<td>Grape Grower</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>121216</td>
<td>Sugar Cane Farmer</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>121221</td>
<td>Vegetable Grower</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>121299</td>
<td>Crop Farmers nec</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>121311</td>
<td>Apiarist</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>121312</td>
<td>Beef Cattle Farmer</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>121313</td>
<td>Dairy Cattle Farmer</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>121316</td>
<td>Horse Breeder</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>121317</td>
<td>Mixed Livestock Farmer</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>121318</td>
<td>Pig Farmer</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>121321</td>
<td>Poultry Farmer</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>121322</td>
<td>Sheep Farmer</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>121399</td>
<td>Livestock Farmer nec</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>121411</td>
<td>Mixed Crop and Livestock Farmer</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>132211</td>
<td>Finance Manager</td>
<td>CPAA/ICAA /IPA</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>133111</td>
<td>Construction Project Manager</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>133211</td>
<td>Engineering Manager</td>
<td>Engineers Australia/AIM</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>133411</td>
<td>Manufacturer</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>134111</td>
<td>Child Care Centre Manager</td>
<td>TRA</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>134212</td>
<td>Nursing Clinical Director</td>
<td>ANMAC</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>134213</td>
<td>Primary Health Organisation Manager</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>134214</td>
<td>Welfare Centre Manager</td>
<td>ACWA/VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>134299</td>
<td>Health &amp; Welfare Services Managers nec</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>139911</td>
<td>Arts Administrator or Manager</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>139913</td>
<td>Laboratory Manager</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>139914</td>
<td>Quality Assurance Manager</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>139999</td>
<td>Specialist Managers nec</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>141111</td>
<td>Caf&eacute; or Restaurant Manager</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>141311</td>
<td>Hotel or Motel Manager</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>141999</td>
<td>Accommodation &amp; Hospitality Managers nec</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>221111</td>
<td>Accountant (General)</td>
<td>CPAA/CA/IPA</td>
<td>? Additional requirements apply. See Note 1</td>
<td>? Additional requirements apply. See Note 1</td>
</tr>
<tr>
<td>221112</td>
<td>Management Accountant</td>
<td>CPAA/CA/IPA</td>
<td>? Additional requirements apply. See Note 1</td>
<td>? Additional requirements apply. See Note 1</td>
</tr>
<tr>
<td>221213</td>
<td>Taxation Accountant</td>
<td>CPAA/CA/IPA</td>
<td>? Additional requirements apply. See Note 1</td>
<td>? Additional requirements apply. See Note 1</td>
</tr>
<tr>
<td>222211</td>
<td>Financial Market Dealer</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>222213</td>
<td>Stockbroking Dealer</td>
<td>VETASSESS</td>
<td><strong>X</strong></td>
<td>?</td>
</tr>
<tr>
<td>222299</td>
<td>Financial Dealers nec</td>
<td>VETASSESS</td>
<td><strong>X</strong></td>
<td>?</td>
</tr>
<tr>
<td>223112</td>
<td>Recruitment Consultant</td>
<td>VETASSESS</td>
<td><strong>X</strong></td>
<td>?</td>
</tr>
<tr>
<td>223211</td>
<td>ICT Trainer</td>
<td>ACS</td>
<td>? Additional requirements apply. See note 2</td>
<td>? Additional requirements apply. See note 2</td>
</tr>
<tr>
<td>224111</td>
<td>Actuary</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>224112</td>
<td>Mathematician</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>224212</td>
<td>Gallery or Museum Curator</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>224213</td>
<td>Health Information Manager</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>224214</td>
<td>Records Manager</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>224511</td>
<td>Land Economist</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>225311</td>
<td>Public Relations Professional</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>232212</td>
<td>Surveyor</td>
<td>SSSI</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>232511</td>
<td>Interior Designer</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>233211</td>
<td>Civil Engineer</td>
<td>Engineers Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>233212</td>
<td>Geotechnical Engineer</td>
<td>Engineers Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>233213</td>
<td>Quantity Surveyor</td>
<td>AIQS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>233214</td>
<td>Structural Engineer</td>
<td>Engineers Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>233215</td>
<td>Transport Engineer</td>
<td>Engineers Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>233311</td>
<td>Electrical Engineer</td>
<td>Engineers Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>233512</td>
<td>Mechanical Engineer</td>
<td>Engineers Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>233911</td>
<td>Aeronautical Engineer</td>
<td>Engineers Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>233912</td>
<td>Agricultural Engineer</td>
<td>Engineers Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>233913</td>
<td>Biomedical Engineer</td>
<td>Engineers Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>233914</td>
<td>Engineering Technologist</td>
<td>Engineers Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>233915</td>
<td>Environmental Engineer</td>
<td>Engineers Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>234111</td>
<td>Agricultural Consultant</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>234112</td>
<td>Agricultural Scientist</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>234113</td>
<td>Forester</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>234411</td>
<td>Geologist</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>234611</td>
<td>Medical Laboratory Scientist</td>
<td>AIMS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>234711</td>
<td>Veterinarian</td>
<td>AVBC</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>241111</td>
<td>Early Childhood (Pre-primary School) Teachers</td>
<td>AITSL</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>241213</td>
<td>Primary School Teacher</td>
<td>AITSL</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>241511</td>
<td>Special Needs Teacher</td>
<td>AITSL</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>241512</td>
<td>Teaching of the Hearing Impaired</td>
<td>AITSL</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>241513</td>
<td>Teacher of the Sight Impaired</td>
<td>AITSL</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>214599</td>
<td>Special Education Teachers nec</td>
<td>AITSL</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>251211</td>
<td>Medical Diagnostic Radiographer</td>
<td>AIR</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>251212</td>
<td>Medical Radiation Therapist</td>
<td>AIR</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>251213</td>
<td>Nuclear Medicine Technologist</td>
<td>ANZSNM</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>251214</td>
<td>Sonographer</td>
<td>AIR</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>251312</td>
<td>Occupational Health and Safety Adviser</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>251411</td>
<td>Optometrist</td>
<td>OCANZ</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>251412</td>
<td>Orthoptist</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>251511</td>
<td>Hospital Pharmacist</td>
<td>APharmC</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>251512</td>
<td>Industrial Pharmacist</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>251513</td>
<td>Retail Pharmacist</td>
<td>APharmC</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>251911</td>
<td>Health Promotion Officer</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>251912</td>
<td>Orthotist and Prosthetist</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>252311</td>
<td>Dental Specialist</td>
<td>ADC</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>252312</td>
<td>Dentist</td>
<td>ADC</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>252411</td>
<td>Occupational Therapist</td>
<td>OTC</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>252511</td>
<td>Physiotherapist</td>
<td>APC</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>252611</td>
<td>Podiatrist</td>
<td>APodC/ANZPAC</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>252711</td>
<td>Audiologist</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>252712</td>
<td>Speech Pathologist</td>
<td>SPA</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253111</td>
<td>General Practitioner</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253112</td>
<td>Resident Medical Officer</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253211</td>
<td>Anaesthetist</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253311</td>
<td>Specialist Physician (General Medicine)</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253312</td>
<td>Cardiologist</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253313</td>
<td>Clinical Haematologist</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253314</td>
<td>Medical Oncologist</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253315</td>
<td>Endocrinologist</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253316</td>
<td>Gastroenterologist</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253317</td>
<td>Intensive Care Specialist</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253318</td>
<td>Neurologist</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253321</td>
<td>Paediatrician</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253322</td>
<td>Renal Medicine Specialist</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253323</td>
<td>Rheumatologist</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253324</td>
<td>Thoracic Medicine Specialist</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253399</td>
<td>Specialist Physicians nec</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253411</td>
<td>Psychiatrist</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253511</td>
<td>Surgeon (General)</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253512</td>
<td>Cardiothoracic Surgeon</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253513</td>
<td>Neurosurgeon</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253514</td>
<td>Orthopaedic Surgeon</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253515</td>
<td>Otorhinolaryngologist</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253516</td>
<td>Paediatric Surgeon</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253517</td>
<td>Plastic and Reconstructive Surgeon</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253518</td>
<td>Urologist</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253521</td>
<td>Vascular Surgeon</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253911</td>
<td>Dermatologist</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253912</td>
<td>Emergency Medicine Specialist</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253913</td>
<td>Obstetrician and Gynaecologist</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253914</td>
<td>Ophthalmologist</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253915</td>
<td>Pathologist</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253917</td>
<td>Diagnostic and Interventional Radiologist</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253918</td>
<td>Radiation Oncologist</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>253999</td>
<td>Medical Practitioners nec</td>
<td>Medical Board of Australia</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>254111</td>
<td>Midwife</td>
<td>ANMAC</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>254411</td>
<td>Nurse Practitioner</td>
<td>ANMAC</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>254412</td>
<td>Registered Nurse (Aged Care)</td>
<td>ANMAC</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>254413</td>
<td>Registered Nurse (Child and Family Health)</td>
<td>ANMAC</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>254414</td>
<td>Registered Nurse (Community Health)</td>
<td>ANMAC</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>254415</td>
<td>Registered Nurse (Critical Care and Emergency)</td>
<td>ANMAC</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>254416</td>
<td>Registered Nurse (Developmental Disability)</td>
<td>ANMAC</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>254417</td>
<td>Registered Nurse (Disability and Rehabilitation)</td>
<td>ANMAC</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>254418</td>
<td>Registered Nurse (Medical)</td>
<td>ANMAC</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>254421</td>
<td>Registered Nurse (Medical Practice)</td>
<td>ANMAC</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>254422</td>
<td>Registered Nurse (Mental Health)</td>
<td>ANMAC</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>254423</td>
<td>Registered Nurse (Perioperative)</td>
<td>ANMAC</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>254424</td>
<td>Registered Nurse (Surgical)</td>
<td>ANMAC</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>254425</td>
<td>Registered Nurse (Paediatric)</td>
<td>ANMAC</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>254499</td>
<td>Registered Nurse nec</td>
<td>ANMAC</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>261111</td>
<td>ICT Business Analyst</td>
<td>ACS</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
</tr>
<tr>
<td>261112</td>
<td>Systems Analyst</td>
<td>ACS</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
</tr>
<tr>
<td>261311</td>
<td>Analyst Programmer</td>
<td>ACS</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
</tr>
<tr>
<td>261312</td>
<td>Developer Programmer</td>
<td>ACS</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
</tr>
<tr>
<td>261313</td>
<td>Software Engineer</td>
<td>ACS</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
</tr>
<tr>
<td>261314</td>
<td>Software Tester</td>
<td>ACS</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
</tr>
<tr>
<td>262112</td>
<td>ICT Security Specialist</td>
<td>ACS</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
</tr>
<tr>
<td>263111</td>
<td>Computer Network and Systems Engineer</td>
<td>ACS</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
</tr>
<tr>
<td>263112</td>
<td>Network Administrator</td>
<td>ACS</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
</tr>
<tr>
<td>263113</td>
<td>Network Analyst</td>
<td>ACS</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
</tr>
<tr>
<td>263211</td>
<td>ICT Quality Assurance Engineer</td>
<td>ACS</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
</tr>
<tr>
<td>263212</td>
<td>ICT Support Engineer</td>
<td>ACS</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
</tr>
<tr>
<td>263213</td>
<td>ICT Systems Test Engineer</td>
<td>ACS</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
</tr>
<tr>
<td>263311</td>
<td>Telecommunications Engineer</td>
<td>Engineers Australia</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
</tr>
<tr>
<td>263312</td>
<td>Telecommunications Network Engineer</td>
<td>Engineers Australia</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
</tr>
<tr>
<td>271111</td>
<td>Barrister</td>
<td>SLAA</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>271311</td>
<td>Solicitor</td>
<td>SLAA</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>272111</td>
<td>Careers Counsellor</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>272112</td>
<td>Drug &amp; Alcohol Counsellor</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>272113</td>
<td>Family &amp; Marriage Counsellor</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>272114</td>
<td>Rehabilitation Counsellor</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>272115</td>
<td>Student Counsellor</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>272199</td>
<td>Counsellors nec</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>272311</td>
<td>Clinical Psychologist</td>
<td>APS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>272312</td>
<td>Educational Psychologist</td>
<td>APS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>272313</td>
<td>Organisational Psychologist</td>
<td>APS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>272399</td>
<td>Psychologists nec</td>
<td>APS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>272412</td>
<td>Interpreter</td>
<td>NAATI</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>272499</td>
<td>Social Professionals nec</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>272511</td>
<td>Social Worker</td>
<td>AASW</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>272612</td>
<td>Recreation Officer</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>272613</td>
<td>Welfare Worker</td>
<td>ACWA</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>311211</td>
<td>Anaesthetic Technician</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>311212</td>
<td>Cardiac Technician</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>311213</td>
<td>Medical Laboratory Technician</td>
<td>AIMS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>311215</td>
<td>Pharmacy Technician</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>311299</td>
<td>Medical Technicians (nec)</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>311411</td>
<td>Chemistry Technician</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>311412</td>
<td>Earth Science Technician</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>311413</td>
<td>Life Science Technician</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>311499</td>
<td>Science Technicians nec</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>312111</td>
 <td>Architectural Draftsperson</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>312112</td>
<td>Building Associate</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>312113</td>
<td>Building Inspector</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>312199</td>
<td>Architectural, Building &amp; Surveying Technicians nec</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>312211</td>
<td>Civil Engineering Draftsperson</td>
<td>Engineers Australia/ VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>312912</td>
<td>Metallurgical or Materials Technician</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>312913</td>
<td>Mine Deputy</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>313111</td>
<td>Hardware Technician</td>
<td>TRA</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>313112</td>
<td>ICT Customer Support Officer</td>
<td>TRA</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
</tr>
<tr>
<td>313113</td>
<td>Web Administrator</td>
<td>ACS</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 2</p>
</td>
</tr>
<tr>
<td>321111</td>
<td>Automotive Electrician</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>321211</td>
<td>Motor Mechanic (General)</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>321212</td>
<td>Diesel Motor Mechanic</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>321213</td>
<td>Motorcycle Mechanic</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>321214</td>
<td>Small Engine Mechanic</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>322211</td>
<td>Sheetmetal Trades Workers</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>322311</td>
<td>Metal Fabricator</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>322313</td>
<td>Welder &ndash; first class</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>323112</td>
<td>Aircraft Maintenance Engineer (Mechanical)</td>
<td>TRA</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>323113</td>
<td>Aircraft Maintenance Engineer (Structures)</td>
<td>TRA</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>323211</td>
<td>Fitter (General)</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>323212</td>
<td>Fitter &amp; Turner</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>323213</td>
<td>Fitter &ndash; Welder</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>323214</td>
<td>Metal Machinist (First Class)</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>323299</td>
<td>Metal Fitters &amp; Machinists (nec)</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>323215</td>
<td>Textile, Clothing &amp; Footwear Mechanic</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>323412</td>
<td>Toolmaker</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>324111</td>
<td>Panelbeater</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>324211</td>
<td>Vehicle Body Builder</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>324212</td>
<td>Vehicle Trimmer</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>331111</td>
<td>Bricklayer</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>331211</td>
<td>Carpenter &amp; Joiner</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>331212</td>
<td>Carpenter</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>331213</td>
<td>Joiner</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>332211</td>
<td>Painting Trades Workers</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>333211</td>
<td>Fibrous Plasterer</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>333212</td>
<td>Solid Plasterer</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>334111</td>
<td>Plumber (General)</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>334112</td>
<td>Airconditioning &amp; Mechanical Services Plumber</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>334113</td>
<td>Drainer</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>334114</td>
<td>Gasfitter</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>334115</td>
<td>Roof Plumber</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>342111</td>
<td>Airconditioning &amp; Refrigeration Mechanic</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>351111</td>
<td>Baker</td>
<td>TRA</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 3</p>
</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>351112</td>
<td>Pastrycook</td>
<td>TRA</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 3</p>
</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>351311</td>
<td>Chef</td>
<td>TRA</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 3</p>
</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>351411</td>
<td>Cook</td>
<td>TRA</td>
<td>?
<p>&nbsp;</p>
<p>Additional requirements apply. See note 3</p>
</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>361311</td>
<td>Veterinary Nurse</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>392311</td>
<td>Printing Machinist</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>394111</td>
<td>Cabinetmaker</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>399111</td>
<td>Boat Builder &amp; Repairer</td>
<td>TRA</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>399112</td>
<td>Shipwright</td>
<td>TRA</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>411111</td>
<td>Ambulance Officer</td>
<td>VETASSESS</td>
<td><strong>X</strong></td>
<td>?</td>
</tr>
<tr>
<td>411112</td>
<td>Intensive Care Ambulance Paramedic</td>
<td>VETASSESS</td>
<td><strong>X</strong></td>
<td>?</td>
</tr>
<tr>
<td>411213</td>
<td>Dental Technician</td>
<td>TRA</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>411311</td>
<td>Diversional Therapist</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>411411</td>
<td>Enrolled Nurse</td>
<td>ANMAC</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>411611</td>
<td>Massage Therapist</td>
 <td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>411711</td>
<td>Community Worker</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>411712</td>
<td>Disabilities Services Officer</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>411713</td>
<td>Family Support Worker</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>411715</td>
<td>Residential Care Officer</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>411716</td>
<td>Youth Worker</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>452311</td>
<td>Diving Instructor (Open Water)</td>
<td>VETASSESS</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>452312</td>
<td>Gymnastics Coach or Instructor</td>
<td>VETASSESS</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>452313</td>
<td>Horse Riding Coach or Instructor</td>
<td>VETASSESS</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>452315</td>
<td>Swimming Coach or Instructor</td>
<td>VETASSESS</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>452316</td>
<td>Tennis Coach</td>
<td>VETASSESS</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>452321</td>
<td>Sports Development Officer</td>
<td>VETASSESS</td>
<td>?</td>
<td><strong>X</strong></td>
</tr>
<tr>
<td>599612</td>
<td>Insurance Loss Adjuster</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
<tr>
<td>611211</td>
<td>Insurance Agent</td>
<td>VETASSESS</td>
<td>?</td>
<td>?</td>
</tr>
</tbody>
</table>
<p><strong>Note 1:</strong>&nbsp;Applicants must have a minimum of three years experience (including 6 months working in Queensland); and a job offer for a full time position in their nominated occupation. For regional areas this requirement is 2 years experience (including 4 months&rsquo; work in a regional Queensland location) and a job offer in a full time job position in their nominated occupation.</p>
<p><strong>Note 2:</strong>&nbsp;Applicants must have five years experience post qualification in their nominated occupation and a job offer for a full time position in their nominated occupation. Queensland is seeking specific ICT skills in relation to cyber security, data scientist, data and business analytics and ICT development and architecture. (The 2017-18 QSOL will also place a specific Queensland ceiling of 200 on nominations for ICT occupations across onshore, alumni and offshore programs).</p>
<p><strong>Note 3:</strong>&nbsp;Applicants must have 3 years experience working in their chosen field and a job offer for a full time position in their nominated occupation.</p>
</div>
</div>
		 <div class="col-md-4 col-sm-4 col-xs-12">
		 <?php include('enquiry-form.php')?>
		 </div>
                
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>