<?php include 'inc/header.php'; ?>
<div class="page-area">
    <div class="breadcumb-overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="breadcrumb">
                    <div class="bread-inner">
                        <div class="section-headline white-headline">
                            <h2>Ontario <span class="color"> PNP</span></h2>
                        </div>
                        <ul class="breadcrumb-bg">
                            <li class="home-bread"><a href="index.php">Home</a></li>
                            <li>Ontario PNP</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="team-area bg-color pd-35">
    <div class="container">
        <!-- section head -->
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-headline text-center">
                    <h3>Ontario <span class="color"> PNP</span></h3>
                </div>
            </div>
        </div>
        <div class="row">
		 <div class="col-md-8 col-sm-8 col-xs-12" style="box-shadow: 5px 3px 10px rgb(0 0 0 / 10%);">
<div class='text-justify innerpage-text'><p>Ontario is the most progressive and developed province in Canada due to large corporations and multi-national startups. Toronto is the origin of all the progress, technological advancement, and growth. The majority of the people wish to settle in this particular province. And, it has a <a href="canada-pnp.html" target="_blank">Provincial Nominee Program</a> to boost immigration to this region. Foreign skilled workers can choose the program to move to Ontario with their families by meeting the eligibility requirements.</p>
<p><strong><u>What are the pathways under Ontario Immigrant Nominee Program?</u></strong></p>
<p>There are three categories under the OINP:</p>
<ul>
<li><strong>Employer Job Offer category &ndash; </strong>The program is for those skilled workers and international students who possess a permanent job offer from an Ontario employer. There are three sub-streams:</li>
</ul>
<ul>
<li><strong>Foreign Worker stream:</strong> For Foreign skilled workers with the job offer</li>
<li><strong>International Student stream:</strong> For International graduates in Ontario with the job offer</li>
<li><strong>In-Demand Skills stream:</strong> For intermediate skilled workers in specific work sectors - construction, agriculture, trucking, and personal support workers</li>
</ul>
<ul>
<li><strong>Human Capital category &ndash; </strong>The program is most popular among skilled foreign workers and international graduates. Anyone with <a href="canada-express-entry.html" target="_blank">Canada Express Entry</a> Profile and valuable work experience, education, language skills can apply for the program. It has two sub-streams:</li>
</ul>
<ul>
<li><strong>Ontario&#39;s Express Entry:</strong> Express Entry has three streams:</li>
</ul>
<ol>
<li><strong>Human Capital Priorities Stream: </strong>For skilled foreign workers</li>
<li><strong>French-Speaking Skilled Worker Stream: </strong>For skilled foreign workers with proficiency in French</li>
<li><strong>Skilled Trades Stream: </strong>For workers with experience in Ontario in a trade occupation</li>
</ol>
<ul>
<li><strong>International Graduates (Master&#39;s &amp; Ph.D.):</strong> For International Master&#39;s and Ph.D. degree holders from Ontario</li>
</ul>
<ul>
<li><strong>Business category &ndash; </strong>For foreign entrepreneurs who wish to establish a new or buy an existing business in Ontario. It has only one stream:</li>
</ul>
<ul>
<li><strong>Entrepreneur Stream: </strong>For the foreign entrepreneurs who can invest and establish or purchase a business in the province. The applicants need to meet other requirements as well.</li>
</ul>
<p><a href="authorized-representative-canada.html" style="color: rgb(255, 255, 255); padding: 7px 5px; line-height: 24px; border-radius: 5px; margin-bottom: 6px; width: 140px; background: rgb(255, 0, 0) !important;" target="_blank" title="Our Canada RCIC Agent">Our Canada RCIC Agent</a></p>
<p><strong>What are the eligibility requirements for Ontario Immigrant Nominee Program (Skilled)?</strong></p>
<ul>
<li>Must have an active Express Entry profile in the CIC account for <strong>Canada Immigration</strong></li>
<li>Have minimum Bachelor&#39;s degree evaluated by Educational Credential Assessment (ECA) report for eligibility.</li>
<li>Must have minimum language level Canadian Language Benchmark (CLB) 7 in English or French proved by a recognized language test.</li>
<li>Possess a minimum of 12 months of continuous full-time employment in a National Occupation Classification (NOC) level 0, A, or B occupation in the last five years.</li>
<li>Must demonstrate the genuine intention to live in Ontario with the family</li>
<li>Have a sufficient amount of settlement funds (legally acquired) for the initial stay</li>
</ul>
<p><strong>What are the eligibility requirements for Ontario Immigrant Nominee Program (Entrepreneurs)?</strong></p>
<ul>
<li>Must have a minimum of two years of full-time business management experience in the last five years.</li>
<li>A business owner must have had an active role in the business management and owned a minimum of one-third of the business.</li>
<li>A senior manager can also apply, but he/she must have senior decision-making responsibilities in the business</li>
<li>The minimum net-worth should be CAD 800,000 (INR 4.83 Crore) for the business in the Greater Toronto Area (City of Toronto and Durham, Halton, York, and Peel regions). The minimum net worth of firms outside of the Greater Toronto Area is CAD 400,000 (INR 2.42 Crore).</li>
<li>The minimum investment should be CAD 600,000 (INR 3.62 Crore) and possess one-third of the equity in the business for the proposed business in the Greater Toronto Area. The minimum investment is CAD 200,000 (INR 1.21 Crore) with one-third equity for firms outside of the Greater Toronto Area.</li>
<li>Generate employment for a minimum of 2 citizens or permanent residents for the business within the Greater Toronto Area. And create a minimum of 1 job for the company outside Greater Toronto Area or business in the ICT or digital communications sector.</li>
<li>If you intend to purchase an existing business, you need to conduct an exploratory visit to the province. You must use 10% of the personal investment to improve the business and retain all the company&#39;s existing employees.</li>
<li>Must have minimum language level Canadian Language Benchmark (CLB) 4 in English or French proved by a recognized language test.</li>
</ul>
<p><strong>What is the process of the Ontario Immigrant Nominee Program (Skilled)?</strong></p>
<ul>
<li>Get your academic credentials evaluated by assessment authorities</li>
<li>Score high points on the English language proficiency test</li>
<li>Have sufficient funds and demonstrate genuine intention to reside in the province</li>
<li>Meet the eligibility points requirement of 67 under the <a href="points-calculator.html" target="_blank">Canada Immigration points calculator</a></li>
<li>Submit the expression of interest in the Express Entry System</li>
<li>Choose Ontario&#39;s Express Entry Human Capital Priorities Stream and create an account in the one-key account.</li>
<li>Create a profile in the OINP e-Filing Portal</li>
<li>Click on the file number beside the Human Capital Priorities Stream to begin your application</li>
<li>Upload all the documents and apply OINP</li>
</ul>
<p><strong>What is the process of the Ontario Immigrant Nominee Program (Entrepreneurs)?</strong></p>
<ul>
<li>Under the checklist and arrange all the documents to register an online Expression of Interest</li>
<li>Complete an EOI registration form along with the Self-Declared and Business Concept Score</li>
<li>Upload all the documents and submit the Express of Interest application by mail</li>
<li>Pay the online application fee of CAD 3500 (INR 2.12 Lac)</li>
<li>To complete the application assessment, attend the mandatory interview with the authority</li>
<li>If your application is approved, sign a performance agreement to demonstrate your commitments to invest and generate employment</li>
<li>You will receive a Temporary Work Permit support letter that will allow you to establish a business in Ontario</li>
<li>After incorporating and managing your business in Ontario, you will be eligible for a provincial nomination for permanent residence</li>
<li>Successful nominees will receive permanent residence within six months of the nomination</li>
</ul>
<p><strong>What are the documents required for Ontario Immigrant Nominee Program?</strong></p>
<ul>
<li>Photograph</li>
<li>Passport copies</li>
<li>Education degrees (ECA report)</li>
<li>Language Test Results</li>
<li>Employment documents (Reference Letters)</li>
<li>Proof of settlement funds</li>
<li>Resume/CV</li>
</ul>
<p><strong>What are the application fee and processing times of the Ontario Immigrant Nominee Program?</strong></p>
<ul>
<li>Application Fee&ndash; CAD 1500 (INR 91,000) &ndash; Skilled, CAD 3500 (INR 2.12 Lac) - Entrepreneurs</li>
<li>Estimated Processing Times &ndash; 60 to 90 days (Skilled), 12 to 15 months (Entrepreneurs)</li>
</ul>
</div>
</div>
		 <div class="col-md-4 col-sm-4 col-xs-12">
		 <?php include('enquiry-form.php')?>
		 </div>
                
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>