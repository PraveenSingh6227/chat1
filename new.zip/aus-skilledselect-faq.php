<?php include 'inc/header.php'; ?>

<div class="page-area">
  <div class="breadcumb-overlay"></div>
  <div class="container">
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="breadcrumb">
          <div class="bread-inner">
            <div class="section-headline white-headline">
              <h2>Frequently Asked Questions - <span class="color"> FAQ</span></h2>
            </div>
            <ul class="breadcrumb-bg">
              <li class="home-bread"><a href="index.php">Home</a></li>
              <li>Frequently Asked Questions - FAQ</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="team-area bg-color pd-35">
  <div class="container">
    <!-- section head -->
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="section-headline text-center">
          <h3>Frequently Asked Questions - <span class="color"> FAQ</span></h3>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-8 col-sm-8 col-xs-12" style="box-shadow: 5px 3px 10px rgb(0 0 0 / 10%);">
        <div class='text-justify innerpage-text'>
          <p>Please Note: Mr. Ajay Sharma, Principal consultant, ABHINAV has prepared <strong>Australia Skill Select (FAQs) </strong>for only general reference (<a href="../cdn-cgi/l/email-protection.html#90e7f5f2d0f1f2f8f9fef1e6bef3fffd"><span class="__cf_email__" data-cfemail="c7b0a2a587a6a5afaea9a6b1e9a4a8aa">[email&#160;protected]</span></a>). It is strictly not to be taken as legal advice or opinion. You are well advised to employ the information strictly for reference purposes. In case of any doubts, clarifications, check with the relevant groups and/or professionals.</p>
          <p>&nbsp;</p>
          <p><strong>Q: How expressing an interest through Skill Select and presenting my profile are useful for me, from sponsorship perspectives? </strong></p>
          <p><strong>Answer :</strong> These activities could mean the difference between your selection and non selection. Under the new format offered by Skill Select, when you do so, your whole information becomes accessible to the recruiters exploring the available talents, for recruitment purposes. If an employer from Australia finds your profile really interesting, he may contact you and discuss the existing opportunities. This could also improve your chances of obtaining sponsorship.</p>
          <p>&nbsp;</p>
          <p><strong>Q: What is the invitation&rsquo;s validity time and what takes place, post the expiry of the invitation?</strong></p>
          <p><strong>Answer :</strong> The invitation&rsquo;s validity period is 60 days. The petition should be submitted to the <strong>Department of Immigration and Border Protection (DIBP)</strong>&nbsp;inside the said duration. In case the profile is not picked-up inside two years of the EOI&rsquo;s submission, the petition for EOI will lapse even as the same will be removed from the data bank.</p>
          <p>&nbsp;</p>
          <p><strong>Q: Can I present a petition with 60 points even if I gain no points in the IELTS?</strong></p>
          <p><strong>Answer :</strong> Yes! You can submit a petition under such a state-of-affairs.</p>
          <p>&nbsp;</p>
          <p><strong>Q: In the Subcategory 489, in case an individual concludes his mandatory stay of 4 years in Australia, can he get PR inside that 4 years, and incase he fails to obtain PR, what occurs?</strong></p>
          <p><strong>Answer :</strong> In such a case it is crucial that he has been residing and doing a job in the identified state/region for not less than two years in the appropriate profile. He can submit a petition for Australia PR Visa after two years, and may gain the same in case he is fruitfully employed in the state, and in case he is not found guilty of any wrong doings during the period. If he is found guilty of breaching the terms of the 489 Permit, he will be denied PR.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
          <p>&nbsp;</p>
          <p><strong>Q: Do we require doing an EOI &amp; state sponsored at the same time?</strong></p>
          <p><strong>Answer :</strong> An aspirant can submit an EOI submission, and also apply for state sponsorship, and after approval is given for the latter, the EOI will be duly updated. The <strong>Department of Immigration and Border Protection (DIBP)</strong> will proceed to offer an invite following these developments.</p>
          <p>&nbsp;</p>
          <p><strong>Q: Is an offer of employment obligatory for the Subcategory 489?&nbsp; </strong></p>
          <p><strong>Answer :</strong> You are advised to check the particular state requirements since some Australian states could necessitate a validated Job offer from state sponsorship under the Sub-category 489. A duly validated employment offer is compulsory to gain state sponsorship.</p>
          <p>&nbsp;</p>
          <p><strong>Q: Can I change my visa subcategory after the EOI lodgment?</strong></p>
          <p><strong>Answer :</strong>&nbsp;Yes, you can do so! It is possible to update your EOI with any details through the two year time. You will gain an opportunity to keep updating your profile in Skill Select anytime when you wish. You also have the right to generate on your EOI continuously as your papers/certificates ought to be with more employment experience.</p>
          <p>&nbsp;</p>
          <p><strong>Q: Should the ACS &amp; the IELTS be legitimate at the time of invitation?</strong></p>
          <p><strong>Answer :</strong> Yes! However, in the backdrop of the fact that the EOI will be held in the bank for two years, the same may not pose any issues to most of the candidates. Still, in certain cases where individuals have gone through the skills assessment/IELTS much before the EOI lodgment, the same could present some problems, particularly for the IELTS. It also denotes that the EOI should be filed in as soon as the results for the IELTS &amp; skills evaluation are obtainable. In case a decision is not made inside two years, the petition will cease to be part of EOI bank. The ACS skills appraisal will also expire post two years, and in case the candidate is eager to re-file, he will require getting evaluation done. He will also have to present a fresh EOI submission. Though the EOI form talks about the IELTS report has a validity of 36 months, the IELTS report has a validity of two years.</p>
          <p>&nbsp;</p>
          <p><strong>Q: Are there separate lists of professions for State sponsored &amp;Regional sponsored, or is it advisable to follow one list?</strong></p>
          <p><strong>Answer :</strong> There are two types of occupations lists. One is the <a href="south-australia-state-nominated-occupation-list.html" target="_blank"><strong>Occupation lists</strong></a> with Schedule 1 and 2 which is called CSOL. For independent skilled migration, the professions given in SOL 1 For State Sponsored and <a href="regional-sponsored-migration-scheme.html" target="_blank">Regional Schemes</a>, only Schedule 2 professions can be duly followed. Apart from this, in case of state and regional programs, it is essential that the claimed line-of-work is also given in state/regional lists. Against this backdrop, for independent skilled overseas movement, you will refer to the professions given in SOL 1, and for state/regional sponsorship, you will refer to Schedule 1 and &nbsp;2 AND state lists.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
          <p>&nbsp;</p>
          <p><strong>Q: What&rsquo;s the basis of selection from the EOI? Is it entirely based on points?</strong></p>
          <p><strong>Answer :</strong> It is based in ranking inside the pool which will keep on changing. In the backdrop of the fact that an EOI submission can be analyzed by recruiters/state/federal bureaus, the EOI may not be wholly based on points.</p>
          <p>In case a recruiter/firm or state is happy with a profile that occupies a not-too-high position in the pool ranking, the same will still be preferred. Still, it is essential that every selected profile fulfills the bare minimum points-requirement &ndash; 60 or 65 points whatever the case could be.</p>
          <p>&nbsp;</p>
          <p><strong>Q: How the petition shall be selected from the EOI bank and what&rsquo;s the estimated time period?</strong></p>
          <p><strong>Answer :</strong> The submission will be in the bank for a period of two years, and can be seen anytime during the two years time.</p>
          <p>The petition will be chosen from the bank depending on when the same is chosen and duly shortlisted by a recruiter/state/region/federal bureau.</p>
          <p>The submission will be given a position, on the basis of the points that you obtain. The ranking will continue to undergo changes as fresh petitions continue to land in the pool. Hence, the petitions that could be gaining higher points (65 points or above) will occupy a higher rank. At certain times, the ranking may be decided by the line-of-work to which a candidate belongs to, even while those who are from extreme shortage profession could be given higher ranks.</p>
          <p>There is NO estimated time period that can be given to a candidate. His profile can be chosen at any time, or not chosen at all for the duration of the two years for which his profile will occupy a place in the pool. In case he is not chosen, he loses the amount spent on Skills appraisal, and the IELTS Test, and also what he has offered as consulting charges.</p>
          <p>&nbsp;</p>
          <p><strong>Q: The states continue to improve the laws, and in case the EOI is shown today with an one specific set of requirements then what will take place in case it takes a very long time even as the state concludes the quota or amends any conditions?</strong></p>
          <p><strong>Answer :</strong> Generally, the states follow the set of rules fixed by the Federal/Central Government, except for picking up the professions they prefer for sponsorship, and the IELTS test requirement for every line-of-work. Save for these two areas, the states are powerless to do much about &ldquo;regulatory&rdquo; improvements. The eventual visa is proffered by the federal/central administration, irrespective of state/regional administration rules.</p>
          <p>&nbsp;</p>
          <p><strong>Q: Does profession has no meaning at all in case of a family member sponsorship?</strong></p>
          <p><strong>Answer :</strong> It is essential that the aspirant belongs to either Schedule 1. It is also vital that the relative is residing in the chosen area.</p>
          <p>&nbsp;</p>
          <p><strong>Q: Is the sub-category 489 a 4-year or a 3-year permit? Can I submit a petition for the PR Permit on the basis of the present laws or the one that will prevail post 3 or 4 years? Shall I file a petition before my permit loses its validity?</strong></p>
          <p><strong>Answer :</strong> <strong>Sub-class 489</strong> is a 4-year Permit. You will be qualified to submit a petition for PR on the basis of the laws applicable at the time of submitting your submission. You have the right to file a petition pose two years for PR after arriving in the state/region, but prior to the end of 4 years when your permit loses its validity.</p>
          <p>&nbsp;</p>
          <p><strong>Q: In the case of state sponsorship, the major candidate, partner, and kids will stay and do a job in the specific state. However, can kids pursue studies outside that state&rsquo;s territorial limits?</strong></p>
          <p><strong>Answer :</strong> It is very doubtful that the advantages of funded education will be obtainable outside the states that have offered sponsorship to the candidate. It is important that the family resides in the selected state/region for which the particular permit was offered.</p>
          <p>&nbsp;</p>
          <p><strong>Q: What to do in case I come across some technical difficulties while employing Skill Select?</strong></p>
          <p><strong>Answer :</strong> Such circumstances are not uncommon. But no need to worry! , You are advised to visit the Support page of the Skill Select before pressing the button given for the &lsquo;<strong>Skill Select Support</strong>&rsquo;. The same will provide all-inclusive data, comprising Skill Select user guides, technical FAQs, etc. You will not have more than one chance to access your EOI account. Besides, you can only mention 1 e-mail address so that you can remain in touch with Skill Select for any invitation objects.</p>
          <p>&nbsp;</p>
          <p><strong>Q: What is the compulsory pass marks meant for the points based permits?</strong></p>
          <p><strong>Answer :</strong></p>
          <ol>
            <li>Visa subclasses 189, 190 and 489 &ndash; 60 points;</li>
            <li>Visa subclasses 885, 886 and 487 - 65 points;</li>
            <li><a href="australia-business-innovation-investment-provisional-subclass-188-visa.html" target="_blank">Visa subclass 188 (</a><a href="australia-business-innovation-investment-provisional-subclass-188-visa.html" target="_blank">business innovation &amp; investment visa</a><a href="australia-business-innovation-investment-provisional-subclass-188-visa.html" target="_blank">)</a> - 65 points</li>
          </ol>
          <p>&nbsp;</p>
          <p><strong>Q: Who accesses the specifics of the Skill Select&rsquo; aspirants?</strong></p>
          <p><strong>Answer :</strong> This actually depends on the choices(s) made by the candidate in the EOI petition. In case you have settled for an employer sponsored or state or regional permit, employer/state/regional may review your profile in the EOI bank. In case you have opted for the independent or family sponsored permit, Skill Select will exclusively utilize your specifics.</p>
          <p>&nbsp;</p>
          <p><strong>Q: Can I submit an EOI, even if am yet to sail through the language test for English &amp; skills evaluation from the relatedorganization?</strong></p>
          <p><strong>Answer :</strong> Before you submit a completed EOI, and in case you are pre-setting an EOI for a points based permit, successfully clear the test meant for the English language &amp; also skills appraisal. Even if you may not be required to attach the germane papers to the EOI, present the correct data in your EOI. Guarantee that it is similar to the one given on the supporting documents.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
          <p>&nbsp;</p>
          <p><strong>Q: Can a candidate find-out his ranking in the EOI pool?</strong></p>
          <p><strong>Answer :</strong> No! It cannot be done. The ranking position continues to undergo key changes, thanks to the filing or the withdrawal of other EOIs from the Skill Select.</p>
          <p>&nbsp;</p>
          <p><strong>Q: Can I present an EOI in Australia?</strong></p>
          <p><strong>Answer :</strong> Yes of course! But you need to satisfy the pre-decided conditions. It needs to be borne in mind that the EOI is not a permit submission, and you will not be given a bridging permit/visa. In case you gain an invite to present a visa submission, you have to satisfy the requirements to get the visa.</p>
          <p>&nbsp;</p>
          <p><strong>Q: Is it compulsory to offer a written statement in the EOI?</strong></p>
          <p><strong>Answer :</strong> The answer is in the negative. The EOI will ask questions--the basis of which will be the permit you may be interested in. Your answer will have adequate statistics for your EOI to be successfully presented.</p>
          <p>&nbsp;</p>
          <p><strong>Q: In case I fail to get an invite, can I be get my money back spent for the skills appraisal&amp; the language test for English?</strong></p>
          <p><strong>Answer :</strong> The answer again is in the negative. Only because you have filed an EOI does not mean you will get an invite. You, as an applicant, have to bear the expenses while preparing your EOI and in case the petition fails to get selected from the pool then you will not gain any refund whatsoever for the expenses incurred for appearing for the IELTS Test &amp; assessment for skills.</p>
          <p>&nbsp;</p>
          <p><strong>Q: What to do if the situation, circumstances, or information undergoes any improvements, post the submission of my EOI?</strong></p>
          <p><strong>Answer :</strong> Update you EOI to depict any freshly gained qualification or experience that may have come your way even while the SkillSelect will notice it, and in case appropriate, will automatically update your position.</p>
          <p>&nbsp;</p>
          <p><strong>Q: What if an invitation is not mailed to me to submit a submission for permit, will I have the review rights?</strong></p>
          <p><strong>Answer :</strong> You will be denied the right in such a case. The review process is meant for only those qualified people whose submissions for a permit have been dismissed. In this case, the EOI is not a permit submission.&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</p>
          <p>&nbsp;</p>
          <p><strong>Q: Are some other avenues available that I can utilize for posting objects?</strong></p>
          <p><strong>Answer :</strong> Frankly, NO! You can only use the online facility Skill Select for EOI submission. Aspirants, who are sent in invitations to file a petition for a permit/visa, the particulars given in the EOI will be exploited as part of their petitions. It is vital that the aspirants suitably verify their claims and present evidence when they suitably submit a petition.</p>
          <p>&nbsp;</p>
          <p><strong>Q: Can I employ the professional services of an immigration agent of Australia, for the object of presenting the EOI petition and, in case the petition is chosen out of the EOI bank, for the remaining part of the immigration procedure?</strong></p>
          <p><strong>Answer : </strong>Yes you can! You are absolutely free to do the same. You can employ the professional services of an immigration advisor to assist you with the EOI submission process.</p>
        </div>
      </div>
      <div class="col-md-4 col-sm-4 col-xs-12">
        <?php include('enquiry-form.php')?>
      </div>
    </div>
  </div>
</div>
</div>
</div>
<?php include 'inc/footer.php'; ?>
