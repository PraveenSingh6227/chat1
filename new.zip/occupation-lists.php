<?php include 'inc/header.php'; ?>

<div class="page-area">
  <div class="breadcumb-overlay"></div>
  <div class="container">
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="breadcrumb">
          <div class="bread-inner">
            <div class="section-headline white-headline">
              <h2>Australia's New Skilled  <span class="color"> Occupation List</span></h2>
            </div>
            <ul class="breadcrumb-bg">
              <li class="home-bread"><a href="index.php">Home</a></li>
              <li>Australia's New Skilled Occupation List</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="team-area bg-color pd-35">
  <div class="container">
    <!-- section head -->
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="section-headline text-center">
          <h3>Australia's New Skilled  <span class="color"> Occupation List</span></h3>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-8 col-sm-8 col-xs-12" style="box-shadow: 5px 3px 10px rgb(0 0 0 / 10%);">
        <div class='text-justify innerpage-text'>
          <p>The Skilled Occupation List Australia is a list of occupation which highlights the most in-demand occupations across various states and regions of Australia. Used as a part of points-based system for <a href="../australia-immigration.html" target="_blank">Australia immigration</a>, skilled workers who want to live and work in Australia are required to choose or nominate an occupation that must align with the skills and experience of the candidate from the Consolidated Sponsored Occupation List (CSOL).</p>
          <p><strong>Skilled Occupation List- What&rsquo;s in It</strong></p>
          <p>Anyone who is applying for <a href="../australia-visa.html" target="_blank">Australia PR visa</a> under General Skilled Migration, and they are not nominated by any of the Australian state or territory, then they must choose an occupation from the SOL List Australia. Every year, the Australian Department of Home Affairs updates its skilled occupation list as per the latest labor market demands of the country. The purpose to update the list is to ensure that the entry of skilled immigrants is purely based on Australia&rsquo;s current workforce needs and economy.</p>
          <p>The Skilled Occupations List (SOL) is generally applicable for <a href="australia-skilled-independent-sub-class-189-immigration-visa.html" target="_blank">Skilled Independent Subclass 189 Visa</a>, <a href="skilled-work-regional-provisional-visa-491.html" target="_blank">Skilled Work Regional Provisional Visa Subclass 491</a>, <a href="australia-skilled-nominated-subclass-190-immigration-visa.html" target="_blank">Skilled Nominated Subclass 190 Visa</a>, and Subclass 485 (Graduate Temporary Visa) visa applications.</p>
          <p>Please find below the updated list of skilled occupations which are currently in demand in Australia:</p>
          <h2>List of Eligible Skilled Occupations - Medium and Long-term Strategic Skills List (MLTSSL)</h2>
          <table border="1" bordercolor="#0099ff" cellpadding="8" cellspacing="0" height="100%" width="90%">
            <tbody>
              <tr>
                <th valign="top"><strong>ANZSCO Code </strong></th>
                <th valign="top"><strong>Description </strong></th>
                <th valign="top"><strong>Assessing Authority </strong></th>
                <th valign="top"><strong>Skill Level </strong></th>
              </tr>
              <tr>
                <td valign="top">133111</td>
                <td valign="top">Construction Project Manager</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">133112</td>
                <td valign="top">Project Builder</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">133211</td>
                <td valign="top">Engineering Manager</td>
                <td valign="top">EA/AIM</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">134111</td>
                <td valign="top">Child Care Centre Manager</td>
                <td valign="top">TRA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">134211</td>
                <td valign="top">Medical Administrator</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">134212</td>
                <td valign="top">Nursing Clinical Director</td>
                <td valign="top">ANMAC</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">134213</td>
                <td valign="top">Primary Health Organisation Manager</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">134214</td>
                <td valign="top">Welfare Centre Manager</td>
                <td valign="top">ACWA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">221111</td>
                <td valign="top">Accountant (General)</td>
                <td valign="top">CPAA/CA/IPA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">221112</td>
                <td valign="top">Management Accountant</td>
                <td valign="top">CPAA/CA/IPA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">221113</td>
                <td valign="top">Taxation Accountant</td>
                <td valign="top">CPAA/CA/IPA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">221213</td>
                <td valign="top">External Auditor</td>
                <td valign="top">CPAA/CA/IPA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">221214</td>
                <td valign="top">Internal Auditor</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">224111</td>
                <td valign="top">Actuary</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">224511</td>
                <td valign="top">Land Economist</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">224512</td>
                <td valign="top">Valuer</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">232111</td>
                <td valign="top">Architect</td>
                <td valign="top">AACA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">232112</td>
                <td valign="top">Landscape Architect</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">232212</td>
                <td valign="top">Surveyor</td>
                <td valign="top">SSSI</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">232213</td>
                <td valign="top">Cartographer</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">232214</td>
                <td valign="top">Other Spatial Scientist</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">233111</td>
                <td valign="top">Chemical Engineer</td>
                <td valign="top">EA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">233112</td>
                <td valign="top">Materials Engineer</td>
                <td valign="top">EA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">233211</td>
                <td valign="top">Civil Engineer</td>
                <td valign="top">EA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">233212</td>
                <td valign="top">Geotechnical Engineer</td>
                <td valign="top">EA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">233213</td>
                <td valign="top">Quantity Surveyor</td>
                <td valign="top">AIQS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">233214</td>
                <td valign="top">Structural Engineer</td>
                <td valign="top">EA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">233215</td>
                <td valign="top">Transport Engineer</td>
                <td valign="top">EA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">233311</td>
                <td valign="top">Electrical Engineer</td>
                <td valign="top">EA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">233411</td>
                <td valign="top">Electronics Engineer</td>
                <td valign="top">EA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">233511</td>
                <td valign="top">Industrial Engineer</td>
                <td valign="top">EA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">233512</td>
                <td valign="top">Mechanical Engineer</td>
                <td valign="top">EA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">233513</td>
                <td valign="top">Production or Plant Engineer</td>
                <td valign="top">EA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">233911</td>
                <td valign="top">Aeronautical Engineer</td>
                <td valign="top">EA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">233912</td>
                <td valign="top">Agricultural Engineer</td>
                <td valign="top">EA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">233913</td>
                <td valign="top">Biomedical Engineer</td>
                <td valign="top">EA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">233914</td>
                <td valign="top">Engineering Technologist</td>
                <td valign="top">EA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">233915</td>
                <td valign="top">Environmental Engineer</td>
                <td valign="top">EA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">233916</td>
                <td valign="top">Naval Architect</td>
                <td valign="top">EA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">234111</td>
                <td valign="top">Agricultural Consultant</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">234112</td>
                <td valign="top">Agricultural Scientist</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">234113</td>
                <td valign="top">Forester</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">234611</td>
                <td valign="top">Medical Laboratory Scientist</td>
                <td valign="top">AIMS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">234711</td>
                <td valign="top">Veterinarian</td>
                <td valign="top">AVBC</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">234914</td>
                <td valign="top">Physicist</td>
                <td valign="top">ACPSEM</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">241111</td>
                <td valign="top">Early Childhood (Pre-primary School) Teacher</td>
                <td valign="top">AITSL</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">241411</td>
                <td valign="top">Secondary School Teacher</td>
                <td valign="top">AITSL</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">241511</td>
                <td valign="top">Special Needs Teacher</td>
                <td valign="top">AITSL</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">241512</td>
                <td valign="top">Teacher of the Hearing Impaired</td>
                <td valign="top">AITSL</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">241513</td>
                <td valign="top">Teacher of the Sight Impaired</td>
                <td valign="top">AITSL</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">241599</td>
                <td valign="top">Special Education Teachers nec</td>
                <td valign="top">AITSL</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">251211</td>
                <td valign="top">Medical Diagnostic Radiographer</td>
                <td valign="top">ASMIRT</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">251212</td>
                <td valign="top">Medical Radiation Therapist</td>
                <td valign="top">ASMIRT</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">251213</td>
                <td valign="top">Nuclear Medicine Technologist</td>
                <td valign="top">ANZSNM</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">251214</td>
                <td valign="top">Sonographer</td>
                <td valign="top">ASMIRT</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">251411</td>
                <td valign="top">Optometrist</td>
                <td valign="top">OCANZ</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">251912</td>
                <td valign="top">Orthotist or Prosthetist</td>
                <td valign="top">AOPA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">252111</td>
                <td valign="top">Chiropractor</td>
                <td valign="top">CCEA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">252112</td>
                <td valign="top">Osteopath</td>
                <td valign="top">AOAC</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">252411</td>
                <td valign="top">Occupational Therapist</td>
                <td valign="top">OTC</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">252511</td>
                <td valign="top">Physiotherapist</td>
                <td valign="top">APC</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">252611</td>
                <td valign="top">Podiatrist</td>
                <td valign="top">ANZPAC</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">252711</td>
                <td valign="top">Audiologist</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">252712</td>
                <td valign="top">Speech Pathologist</td>
                <td valign="top">SPA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253111</td>
                <td valign="top">General Practitioner</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253311</td>
                <td valign="top">Specialist Physician (General Medicine)</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253312</td>
                <td valign="top">Cardiologist</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253313</td>
                <td valign="top">Clinical Haematologist</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253314</td>
                <td valign="top">Medical Oncologist</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253315</td>
                <td valign="top">Endocrinologist</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253316</td>
                <td valign="top">Gastroenterologist</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253317</td>
                <td valign="top">Intensive Care Specialist</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253318</td>
                <td valign="top">Neurologist</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253321</td>
                <td valign="top">Paediatrician</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253322</td>
                <td valign="top">Renal Medicine Specialist</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253323</td>
                <td valign="top">Rheumatologist</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253324</td>
                <td valign="top">Thoracic Medicine Specialist</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253399</td>
                <td valign="top">Specialist Physicians nec</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253411</td>
                <td valign="top">Psychiatrist</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253511</td>
                <td valign="top">Surgeon (General)</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253512</td>
                <td valign="top">Cardiothoracic Surgeon</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253513</td>
                <td valign="top">Neurosurgeon</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253514</td>
                <td valign="top">Orthopaedic Surgeon</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253515</td>
                <td valign="top">Otorhinolaryngologist</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253516</td>
                <td valign="top">Paediatric Surgeon</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253517</td>
                <td valign="top">Plastic and Reconstructive Surgeon</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253518</td>
                <td valign="top">Urologist</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253521</td>
                <td valign="top">Vascular Surgeon</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253911</td>
                <td valign="top">Dermatologist</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253912</td>
                <td valign="top">Emergency Medicine Specialist</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253913</td>
                <td valign="top">Obstetrician and Gynaecologist</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253914</td>
                <td valign="top">Ophthalmologist</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253915</td>
                <td valign="top">Pathologist</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253917</td>
                <td valign="top">Diagnostic and Interventional Radiologist</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253918</td>
                <td valign="top">Radiation Oncologist</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253999</td>
                <td valign="top">Medical Practitioners nec</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">254111</td>
                <td valign="top">Midwife</td>
                <td valign="top">ANMAC</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">254411</td>
                <td valign="top">Nurse Practitioner</td>
                <td valign="top">ANMAC</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">254412</td>
                <td valign="top">Registered Nurse (Aged Care)</td>
                <td valign="top">ANMAC</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">254413</td>
                <td valign="top">Registered Nurse (Child and Family Health)</td>
                <td valign="top">ANMAC</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">254414</td>
                <td valign="top">Registered Nurse (Community Health)</td>
                <td valign="top">ANMAC</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">254415</td>
                <td valign="top">Registered Nurse (Critical Care and Emergency)</td>
                <td valign="top">ANMAC</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">254416</td>
                <td valign="top">Registered Nurse (Developmental Disability)</td>
                <td valign="top">ANMAC</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">254417</td>
                <td valign="top">Registered Nurse (Disability and Rehabilitation)</td>
                <td valign="top">ANMAC</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">254418</td>
                <td valign="top">Registered Nurse (Medical)</td>
                <td valign="top">ANMAC</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">254421</td>
                <td valign="top">Registered Nurse (Medical Practice)</td>
                <td valign="top">ANMAC</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">254422</td>
                <td valign="top">Registered Nurse (Mental Health)</td>
                <td valign="top">ANMAC</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">254423</td>
                <td valign="top">Registered Nurse (Perioperative)</td>
                <td valign="top">ANMAC</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">254424</td>
                <td valign="top">Registered Nurse (Surgical)</td>
                <td valign="top">ANMAC</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">254425</td>
                <td valign="top">Registered Nurse (Paediatrics)</td>
                <td valign="top">ANMAC</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">254499</td>
                <td valign="top">Registered Nurses nec</td>
                <td valign="top">ANMAC</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">261111</td>
                <td valign="top">ICT Business Analyst</td>
                <td valign="top">ACS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">261112</td>
                <td valign="top">Systems Analyst</td>
                <td valign="top">ACS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">261311</td>
                <td valign="top">Analyst Programmer</td>
                <td valign="top">ACS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">261312</td>
                <td valign="top">Developer Programmer</td>
                <td valign="top">ACS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">261313</td>
                <td valign="top">Software Engineer</td>
                <td valign="top">ACS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">262112</td>
                <td valign="top">ICT Security Specialist</td>
                <td valign="top">ACS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">263111</td>
                <td valign="top">Computer Network and Systems Engineer</td>
                <td valign="top">ACS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">263311</td>
                <td valign="top">Telecommunications Engineer</td>
                <td valign="top">EA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">263312</td>
                <td valign="top">Telecommunications Network Engineer</td>
                <td valign="top">EA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">271111</td>
                <td valign="top">Barrister</td>
                <td valign="top">SLAA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">271311</td>
                <td valign="top">Solicitor</td>
                <td valign="top">SLAA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">272311</td>
                <td valign="top">Clinical Psychologist</td>
                <td valign="top">APS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">272312</td>
                <td valign="top">Educational Psychologist</td>
                <td valign="top">APS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">272313</td>
                <td valign="top">Organisational Psychologist</td>
                <td valign="top">APS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">272399</td>
                <td valign="top">Psychologists nec</td>
                <td valign="top">APS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">272511</td>
                <td valign="top">Social Worker</td>
                <td valign="top">AASW</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">312211</td>
                <td valign="top">Civil Engineering Draftsperson</td>
                <td valign="top">EA/VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">312212</td>
                <td valign="top">Civil Engineering Technician</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">312311</td>
                <td valign="top">Electrical Engineering Draftsperson</td>
                <td valign="top">EA</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">312312</td>
                <td valign="top">Electrical Engineering Technician</td>
                <td valign="top">TRA</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">313211</td>
                <td valign="top">Radiocommunications Technician</td>
                <td valign="top">TRA</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">313212</td>
                <td valign="top">Telecommunications Field Engineer</td>
                <td valign="top">EA</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">313213</td>
                <td valign="top">Telecommunications Network Planner</td>
                <td valign="top">EA</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">313214</td>
                <td valign="top">Telecommunications Technical Officer or Technologist</td>
                <td valign="top">EA</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">321111</td>
                <td valign="top">Automotive Electrician</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">321211</td>
                <td valign="top">Motor Mechanic (General)</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">321212</td>
                <td valign="top">Diesel Motor Mechanic</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">321213</td>
                <td valign="top">Motorcycle Mechanic</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">321214</td>
                <td valign="top">Small Engine Mechanic</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">322211</td>
                <td valign="top">Sheetmetal Trades Worker</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">322311</td>
                <td valign="top">Metal Fabricator</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">322312</td>
                <td valign="top">Pressure Welder</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">322313</td>
                <td valign="top">Welder (First Class)</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">323211</td>
                <td valign="top">Fitter (General)</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">323212</td>
                <td valign="top">Fitter and Turner</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">323213</td>
                <td valign="top">Fitter-Welder</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">323214</td>
                <td valign="top">Metal Machinist (First Class)</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">323313</td>
                <td valign="top">Locksmith</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">324111</td>
                <td valign="top">Panelbeater</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">331111</td>
                <td valign="top">Bricklayer</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">331112</td>
                <td valign="top">Stonemason</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">331211</td>
                <td valign="top">Carpenter and Joiner</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">331212</td>
                <td valign="top">Carpenter</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">331213</td>
                <td valign="top">Joiner</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">332211</td>
                <td valign="top">Painting Trades Worker</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">333111</td>
                <td valign="top">Glazier</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">333211</td>
                <td valign="top">Fibrous Plasterer</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">333212</td>
                <td valign="top">Solid Plasterer</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">333411</td>
                <td valign="top">Wall and Floor Tiler</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">334111</td>
                <td valign="top">Plumber (General)</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">334112</td>
                <td valign="top">Airconditioning and Mechanical Services Plumber</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">334113</td>
                <td valign="top">Drainer</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">334114</td>
                <td valign="top">Gasfitter</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">334115</td>
                <td valign="top">Roof Plumber</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">341111</td>
                <td valign="top">Electrician (General)</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">341112</td>
                <td valign="top">Electrician (Special Class)</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">341113</td>
                <td valign="top">Lift Mechanic</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">342111</td>
                <td valign="top">Airconditioning and Refrigeration Mechanic</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">342211</td>
                <td valign="top">Electrical Linesworker</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">342212</td>
                <td valign="top">Technical Cable Jointer</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">342313</td>
                <td valign="top">Electronic Equipment Trades Worker</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">342314</td>
                <td valign="top">Electronic Instrument Trades Worker (General)</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">342315</td>
                <td valign="top">Electronic Instrument Trades Worker (Special Class)</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">351311</td>
                <td valign="top">Chef</td>
                <td valign="top">TRA</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">394111</td>
                <td valign="top">Cabinetmaker</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">399111</td>
                <td valign="top">Boat Builder and Repairer</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">399112</td>
                <td valign="top">Shipwright</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">423111</td>
                <td valign="top">Aged or Disabled Carer</td>
                <td valign="top">N/A</td>
                <td valign="top">4</td>
              </tr>
              <tr>
                <td valign="top">423312</td>
                <td valign="top">Nursing Support Worker</td>
                <td valign="top">N/A</td>
                <td valign="top">4</td>
              </tr>
              <tr>
                <td valign="top">423313</td>
                <td valign="top">Personal Care Assistant</td>
                <td valign="top">N/A</td>
                <td valign="top">4</td>
              </tr>
            </tbody>
          </table>
          <p><strong>Farmers</strong></p>
          <p>Due to the pandemic, Australia faces a severe shortage in the farming and irrigation. Mostly, consists of labors from overseas as the Australian residents are fewer in this industry.</p>
          <table border="1" cellpadding="0" cellspacing="0">
            <tbody>
              <tr>
                <td style="width:208px;"><p>Mixed Cattle and Sheep Farmer</p></td>
                <td style="width:208px;"><p>Fruit Grower</p></td>
                <td style="width:208px;"><p>Nut Grower</p></td>
              </tr>
              <tr>
                <td style="width:208px;"><p>Production Nursery Grower</p></td>
                <td style="width:208px;"><p>Wine Grape Grower</p></td>
                <td style="width:208px;"><p>Horticultural Crop Growers nec</p></td>
              </tr>
              <tr>
                <td style="width:208px;"><p>Broad acre Crop and Livestock Farmer</p></td>
                <td style="width:208px;"><p>Mixed Production Farmers nec</p></td>
                <td style="width:208px;"><p>Cotton Farm Worker</p></td>
              </tr>
              <tr>
                <td style="width:208px;"><p>Fruit Farm Worker</p></td>
                <td style="width:208px;"><p>Fruit Picker</p></td>
                <td style="width:208px;"><p>Nut Farm Worker</p></td>
              </tr>
              <tr>
                <td style="width:208px;"><p>Sugar Cane Farm Worker</p></td>
                <td style="width:208px;"><p>Cattle and Sheep Farm Worker</p></td>
                <td style="width:208px;"><p>Piggery Farm Worker</p></td>
              </tr>
              <tr>
                <td style="width:208px;"><p>Broadacre Crop and Livestock Farm Worker</p></td>
                <td style="width:208px;"><p>&nbsp;</p></td>
                <td style="width:208px;"><p>&nbsp;</p></td>
              </tr>
            </tbody>
          </table>
          <p><strong>Agriculture Technicians &amp; Workers</strong></p>
          <p>Agriculture industry is one of the booming industries in Australia. Therefore, more technical professionals are needed in this industry. December 1, 2021 will mark the resumption of international workers travel to the country.</p>
          <table border="1" cellpadding="0" cellspacing="0" style="width:624px;" width="624">
            <tbody>
              <tr>
                <td style="width:210px;"><p>Agricultural Research Scientist</p>
                  <p>&nbsp;</p></td>
                <td style="width:210px;"><p>Agronomist</p>
                  <p>&nbsp;</p></td>
                <td style="width:204px;"><p>Aquaculture or Fisheries Scientist</p></td>
              </tr>
              <tr>
                <td style="width:210px;"><p>Entomologist</p></td>
                <td style="width:210px;"><p>Zoologist</p></td>
                <td style="width:204px;"><p>Agricultural and Agritech Technician</p></td>
              </tr>
              <tr>
                <td style="width:210px;"><p>Animal Husbandry Technician</p>
                  <p>&nbsp;</p></td>
                <td style="width:210px;"><p>Aquaculture or Fisheries Technician</p>
                  <p>&nbsp;</p></td>
                <td style="width:204px;"><p>Irrigation Designer</p>
                  <p>&nbsp;</p></td>
              </tr>
              <tr>
                <td style="width:210px;"><p>Respiratory Technician</p></td>
                <td style="width:210px;"><p>Respiratory Scientist</p></td>
                <td style="width:204px;"><p>Primary Products Quality Assurance Officer</p></td>
              </tr>
              <tr>
                <td style="width:210px;"><p>Other Draftsperson</p></td>
                <td style="width:210px;"><p>Irrigation Technician</p></td>
                <td style="width:204px;"><p>Aquaculture Supervisor</p></td>
              </tr>
              <tr>
                <td style="width:210px;"><p>Fishing Leading Hand</p></td>
                <td style="width:210px;"><p>Forestry Operations Supervisor</p></td>
                <td style="width:204px;"><p>Horticultural Supervisor or Specialist</p></td>
              </tr>
              <tr>
                <td style="width:210px;"><p>Senior Broadacre Crop and Livestock Farm Worker</p></td>
                <td style="width:210px;"><p>Senior Broadacre Crop Farm Worker</p></td>
                <td style="width:204px;"><p>Senior Aquaculture, Crop and Forestry Workers nec</p></td>
              </tr>
              <tr>
                <td style="width:210px;"><p>Senior Beef Cattle Station Worker</p></td>
                <td style="width:210px;"><p>Senior Cattle and Sheep Farm Worker</p></td>
                <td style="width:204px;"><p>Senior Dairy Cattle Farm Worker</p></td>
              </tr>
              <tr>
                <td style="width:210px;"><p>Senior Piggery Stockperson</p>
                  <p>&nbsp;</p></td>
                <td style="width:210px;"><p>Senior Sheep Farm Worker</p></td>
                <td style="width:204px;"><p>Senior Livestock Farm Workers nec</p></td>
              </tr>
              <tr>
                <td style="width:210px;"><p>Shearer</p></td>
                <td style="width:210px;"><p>Wool Classer</p></td>
                <td style="width:204px;"><p>Tree Worker</p></td>
              </tr>
            </tbody>
          </table>
          <p><strong>Cyber Security &amp; ICT Professionals</strong></p>
          <p>IT industry is one of the backbone of Australian economy and IT skilled professionals are in-demand in the country. Most of the professionals come for Asia Pacific, mostly Indians. IT skilled professionals from India are preferred by the Tech businesses in Australia.</p>
          <table border="1" cellpadding="0" cellspacing="0">
            <tbody>
              <tr>
                <td style="width:208px;"><p>User Experience Designer (ICT)</p></td>
                <td style="width:208px;"><p>Cyber Security Engineer</p></td>
                <td style="width:208px;"><p>Devops Engineer</p></td>
              </tr>
              <tr>
                <td style="width:208px;"><p>Penetration Tester</p></td>
                <td style="width:208px;"><p>Cyber Security Advice and Assessment Specialist</p></td>
                <td style="width:208px;"><p>Cyber Governance Risk and Compliance Specialist</p></td>
              </tr>
              <tr>
                <td style="width:208px;"><p>Cyber Security Analyst</p></td>
                <td style="width:208px;"><p>Cyber Security Architect</p></td>
                <td style="width:208px;"><p>Cyber Security Operations Coordinator</p></td>
              </tr>
            </tbody>
          </table>
          <p><strong>Marketing Professionals</strong></p>
          <p>Every business needs a dedicated marketing team to generate business. And, marketing professionals are demanded in the country. Digital Marketing is now becoming useful medium for the businesses to promote their products and offerings.</p>
          <table border="1" cellpadding="0" cellspacing="0">
            <tbody>
              <tr>
                <td style="width:208px;"><p>Content Creator (Marketing)</p></td>
                <td style="width:208px;"><p>Digital Marketing Analyst</p></td>
              </tr>
            </tbody>
          </table>
          <p><strong>Sports Professionals</strong></p>
          <p>In the recent occupations addition, Australia has added sports professionals (riders and turf managers). It is a unique occupations which has less competition with maximum opportunities for the professionals who are associated with sports and management.</p>
          <table border="1" cellpadding="0" cellspacing="0">
            <tbody>
              <tr>
                <td style="width:208px;"><p>Track Rider</p></td>
                <td style="width:208px;"><p>Sports Turf Manager</p></td>
                <td style="width:208px;"><p>Sports Turf Trades Worker</p></td>
              </tr>
            </tbody>
          </table>
          <h3>Short-term Skilled Occupation List (STSOL) Contains 253 Occupations</h3>
          <table border="1" bordercolor="#0099ff" cellpadding="8" cellspacing="0" height="100%" width="90%">
            <tbody>
              <tr>
                <th valign="top"><strong>ANZSCO Code </strong></th>
                <th valign="top"><strong>Description </strong></th>
                <th valign="top"><strong>Assessing Authority </strong></th>
                <th valign="top"><strong>Skill Level </strong></th>
              </tr>
              <tr>
                <td valign="top">121111</td>
                <td valign="top">Aquaculture Farmer</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">121211</td>
                <td valign="top">Cotton Grower</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">121212</td>
                <td valign="top">Flower Grower</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">121213</td>
                <td valign="top">Fruit or Nut Grower</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">121214</td>
                <td valign="top">Grain, Oilseed or Pasture Grower</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">121215</td>
                <td valign="top">Grape Grower</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">121216</td>
                <td valign="top">Mixed Crop Farmer</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">121217</td>
                <td valign="top">Sugar Cane Grower</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">121221</td>
                <td valign="top">Vegetable Grower</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">121299</td>
                <td valign="top">Crop Farmers nec</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">121311</td>
                <td valign="top">Apiarist</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">121312</td>
                <td valign="top">Beef Cattle Farmer</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">121313</td>
                <td valign="top">Dairy Cattle Farmer</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">121316</td>
                <td valign="top">Horse Breeder</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">121317</td>
                <td valign="top">Mixed Livestock Farmer</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">121318</td>
                <td valign="top">Pig Farmer</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">121321</td>
                <td valign="top">Poultry Farmer</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">121322</td>
                <td valign="top">Sheep Farmer</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">121399</td>
                <td valign="top">Livestock Farmers nec</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">121411</td>
                <td valign="top">Mixed Crop and Livestock Farmer</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">131112</td>
                <td valign="top">Sales and Marketing Manager</td>
                <td valign="top">AIM</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">131113</td>
                <td valign="top">Advertising Manager</td>
                <td valign="top">AIM</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">132111</td>
                <td valign="top">Corporate Services Manager</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">132211</td>
                <td valign="top">Finance Manager</td>
                <td valign="top">CPAA/CA/IPA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">132311</td>
                <td valign="top">Human Resource Manager</td>
                <td valign="top">AIM</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">132511</td>
                <td valign="top">Research and Development Manager</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">133411</td>
                <td valign="top">Manufacturer</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">133511</td>
                <td valign="top">Production Manager (Forestry)</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">133512</td>
                <td valign="top">Production Manager (Manufacturing)</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">133513</td>
                <td valign="top">Production Manager (Mining)</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">133611</td>
                <td valign="top">Supply and Distribution Manager</td>
                <td valign="top">AIM</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">134299</td>
                <td valign="top">Health and Welfare Services Managers nec</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">134311</td>
                <td valign="top">School Principal</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">134499</td>
                <td valign="top">Education Managers nec</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">135112</td>
                <td valign="top">ICT Project Manager</td>
                <td valign="top">ACS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">135199</td>
                <td valign="top">ICT Managers nec</td>
                <td valign="top">ACS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">139911</td>
                <td valign="top">Arts Administrator or Manager</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">139913</td>
                <td valign="top">Laboratory Manager</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">139914</td>
                <td valign="top">Quality Assurance Manager</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">139999</td>
                <td valign="top">Specialist Managers nec</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">141111</td>
                <td valign="top">Cafe or Restaurant Manager</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">141311</td>
                <td valign="top">Hotel or Motel Manager</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">141999</td>
                <td valign="top">Accommodation and Hospitality Managers nec</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">142114</td>
                <td valign="top">Hair or Beauty Salon Manager</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">142115</td>
                <td valign="top">Post Office Manager</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">149112</td>
                <td valign="top">Fitness Centre Manager</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">149113</td>
                <td valign="top">Sports Centre Manager</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">149212</td>
                <td valign="top">Customer Service Manager</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">149311</td>
                <td valign="top">Conference and Event Organiser</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">149413</td>
                <td valign="top">Transport Company Manager</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">149913</td>
                <td valign="top">Facilities Manager</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">211112</td>
                <td valign="top">Dancer or Choreographer</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">211212</td>
                <td valign="top">Music Director</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">211299</td>
                <td valign="top">Music Professionals nec</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">211311</td>
                <td valign="top">Photographer</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">211499</td>
                <td valign="top">Visual Arts and Crafts Professionals nec</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">212111</td>
                <td valign="top">Artistic Director</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">212212</td>
                <td valign="top">Book or Script Editor</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">212312</td>
                <td valign="top">Director (Film, Television, Radio or Stage)</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">212314</td>
                <td valign="top">Film and Video Editor</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">212315</td>
                <td valign="top">Program Director (Television or Radio)</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">212316</td>
                <td valign="top">Stage Manager</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">212317</td>
                <td valign="top">Technical Director</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">212318</td>
                <td valign="top">Video Producer</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">212411</td>
                <td valign="top">Copywriter</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">212412</td>
                <td valign="top">Newspaper or Periodical Editor</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">212413</td>
                <td valign="top">Print Journalist</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">212415</td>
                <td valign="top">Technical Writer</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">212416</td>
                <td valign="top">Television Journalist</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">212499</td>
                <td valign="top">Journalists and Other Writers nec</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">221211</td>
                <td valign="top">Company Secretary</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">221212</td>
                <td valign="top">Corporate Treasurer</td>
                <td valign="top">N/A</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">222111</td>
                <td valign="top">Commodities Trader</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">222112</td>
                <td valign="top">Finance Broker</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">222113</td>
                <td valign="top">Insurance Broker</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">222199</td>
                <td valign="top">Financial Brokers nec</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">222211</td>
                <td valign="top">Financial Market Dealer</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">222213</td>
                <td valign="top">Stockbroking Dealer</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">222299</td>
                <td valign="top">Financial Dealers nec</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">222311</td>
                <td valign="top">Financial Investment Adviser</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">222312</td>
                <td valign="top">Financial Investment Manager</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">223112</td>
                <td valign="top">Recruitment Consultant</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">223211</td>
                <td valign="top">ICT Trainer</td>
                <td valign="top">ACS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">224112</td>
                <td valign="top">Mathematician</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">224212</td>
                <td valign="top">Gallery or Museum Curator</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">224213</td>
                <td valign="top">Health Information Manager</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">224214</td>
                <td valign="top">Records Manager</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">224611</td>
                <td valign="top">Librarian</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">224711</td>
                <td valign="top">Management Consultant</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">224712</td>
                <td valign="top">Organisation and Methods Analyst</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">224914</td>
                <td valign="top">Patents Examiner</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">224999</td>
                <td valign="top">Information and Organisation Professionals nec</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">225111</td>
                <td valign="top">Advertising Specialist</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">225113</td>
                <td valign="top">Marketing Specialist</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">225211</td>
                <td valign="top">ICT Account Manager</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">225212</td>
                <td valign="top">ICT Business Development Manager</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">225213</td>
                <td valign="top">ICT Sales Representative</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">225311</td>
                <td valign="top">Public Relations Professional</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">225499</td>
                <td valign="top">Technical Sales Representatives nec</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">231111</td>
                <td valign="top">Aeroplane Pilot</td>
                <td valign="top">CASA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">231113</td>
                <td valign="top">Flying Instructor</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">231114</td>
                <td valign="top">Helicopter Pilot</td>
                <td valign="top">CASA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">232311</td>
                <td valign="top">Fashion Designer</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">232312</td>
                <td valign="top">Industrial Designer</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">232313</td>
                <td valign="top">Jewellery Designer</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">232411</td>
                <td valign="top">Graphic Designer</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">232412</td>
                <td valign="top">Illustrator</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">232414</td>
                <td valign="top">Web Designer</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">232511</td>
                <td valign="top">Interior Designer</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">232611</td>
                <td valign="top">Urban and Regional Planner</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">234213</td>
                <td valign="top">Wine Maker</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">234411</td>
                <td valign="top">Geologist</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">241213</td>
                <td valign="top">Primary School Teacher</td>
                <td valign="top">AITSL</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">241311</td>
                <td valign="top">Middle School Teacher</td>
                <td valign="top">AITSL</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">249111</td>
                <td valign="top">Education Adviser</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">249211</td>
                <td valign="top">Art Teacher (Private Tuition)</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">249212</td>
                <td valign="top">Dance Teacher (Private Tuition)</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">249214</td>
                <td valign="top">Music Teacher (Private Tuition)</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">249299</td>
                <td valign="top">Private Tutors and Teachers nec</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">249311</td>
                <td valign="top">Teacher of English to Speakers of Other Languages</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">251111</td>
                <td valign="top">Dietitian</td>
                <td valign="top">DAA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">251112</td>
                <td valign="top">Nutritionist</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">251312</td>
                <td valign="top">Occupational Health and Safety Adviser</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">251412</td>
                <td valign="top">Orthoptist</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">251511</td>
                <td valign="top">Hospital Pharmacist</td>
                <td valign="top">APharmC</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">251512</td>
                <td valign="top">Industrial Pharmacist</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">251513</td>
                <td valign="top">Retail Pharmacist</td>
                <td valign="top">ApharmC</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">251911</td>
                <td valign="top">Health Promotion Officer</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">251999</td>
                <td valign="top">Health Diagnostic and Promotion Professionals nec</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">252211</td>
                <td valign="top">Acupuncturist</td>
                <td valign="top">CMBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">252213</td>
                <td valign="top">Naturopath</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">252214</td>
                <td valign="top">Traditional Chinese Medicine Practitioner</td>
                <td valign="top">CMBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">252299</td>
                <td valign="top">Complementary Health Therapists nec</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">252311</td>
                <td valign="top">Dental Specialist</td>
                <td valign="top">ADC</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">252312</td>
                <td valign="top">Dentist</td>
                <td valign="top">ADC</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253112</td>
                <td valign="top">Resident Medical Officer</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">253211</td>
                <td valign="top">Anaesthetist</td>
                <td valign="top">MBA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">254211</td>
                <td valign="top">Nurse Educator</td>
                <td valign="top">ANMAC</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">254212</td>
                <td valign="top">Nurse Researcher</td>
                <td valign="top">ANMAC</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">254311</td>
                <td valign="top">Nurse Manager</td>
                <td valign="top">ANMAC</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">261212</td>
                <td valign="top">Web Developer</td>
                <td valign="top">ACS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">261314</td>
                <td valign="top">Software Tester</td>
                <td valign="top">ACS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">262111</td>
                <td valign="top">Database Administrator</td>
                <td valign="top">ACS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">262113</td>
                <td valign="top">Systems Administrator</td>
                <td valign="top">ACS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">263112</td>
                <td valign="top">Network Administrator</td>
                <td valign="top">ACS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">263113</td>
                <td valign="top">Network Analyst</td>
                <td valign="top">ACS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">263211</td>
                <td valign="top">ICT Quality Assurance Engineer</td>
                <td valign="top">ACS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">263212</td>
                <td valign="top">ICT Support Engineer</td>
                <td valign="top">ACS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">263213</td>
                <td valign="top">ICT Systems Test Engineer</td>
                <td valign="top">ACS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">263299</td>
                <td valign="top">ICT Support and Test Engineers nec</td>
                <td valign="top">ACS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">271299</td>
                <td valign="top">Judicial and Other Legal Professionals nec</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">272111</td>
                <td valign="top">Careers Counsellor</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1 (Closed)</td>
              </tr>
              <tr>
                <td valign="top">272112</td>
                <td valign="top">Drug and Alcohol Counsellor</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">272113</td>
                <td valign="top">Family and Marriage Counsellor</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">272114</td>
                <td valign="top">Rehabilitation Counsellor</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">272115</td>
                <td valign="top">Student Counsellor</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">272199</td>
                <td valign="top">Counsellors nec</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">272412</td>
                <td valign="top">Interpreter</td>
                <td valign="top">NAATI</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">272499</td>
                <td valign="top">Social Professionals nec</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">272612</td>
                <td valign="top">Recreation Officer</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">272613</td>
                <td valign="top">Welfare Worker</td>
                <td valign="top">ACWA</td>
                <td valign="top">1</td>
              </tr>
              <tr>
                <td valign="top">311111</td>
                <td valign="top">Agricultural Technician</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">311211</td>
                <td valign="top">Anaesthetic Technician</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">311212</td>
                <td valign="top">Cardiac Technician</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">311213</td>
                <td valign="top">Medical Laboratory Technician</td>
                <td valign="top">AIMS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">311215</td>
                <td valign="top">Pharmacy Technician</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">311299</td>
                <td valign="top">Medical Technicians nec</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">311312</td>
                <td valign="top">Meat Inspector</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">311399</td>
                <td valign="top">Primary Products Inspectors nec</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">311411</td>
                <td valign="top">Chemistry Technician</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">311412</td>
                <td valign="top">Earth Science Technician</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">311413</td>
                <td valign="top">Life Science Technician</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">311499</td>
                <td valign="top">Science Technicians nec</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">312111</td>
                <td valign="top">Architectural Draftsperson</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">312112</td>
                <td valign="top">Building Associate</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">312113</td>
                <td valign="top">Building Inspector</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">312199</td>
                <td valign="top">Architectural, Building and Surveying Technicians nec</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">312512</td>
                <td valign="top">Mechanical Engineering Technician</td>
                <td valign="top">TRA</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">312912</td>
                <td valign="top">Metallurgical or Materials Technician</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">312913</td>
                <td valign="top">Mine Deputy</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">313111</td>
                <td valign="top">Hardware Technician</td>
                <td valign="top">TRA</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">313112</td>
                <td valign="top">ICT Customer Support Officer</td>
                <td valign="top">TRA</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">313113</td>
                <td valign="top">Web Administrator</td>
                <td valign="top">ACS</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">313199</td>
                <td valign="top">ICT Support Technicians nec</td>
                <td valign="top">TRA</td>
                <td valign="top">2</td>
              </tr>
              <tr>
                <td valign="top">322113</td>
                <td valign="top">Farrier</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">323111</td>
                <td valign="top">Aircraft Maintenance Engineer (Avionics)</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">323112</td>
                <td valign="top">Aircraft Maintenance Engineer (Mechanical)</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">323113</td>
                <td valign="top">Aircraft Maintenance Engineer (Structures)</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">323215</td>
                <td valign="top">Textile, Clothing and Footwear Mechanic</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">323299</td>
                <td valign="top">Metal Fitters and Machinists nec</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">323314</td>
                <td valign="top">Precision Instrument Maker and Repairer</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">323316</td>
                <td valign="top">Watch and Clock Maker and Repairer</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">323412</td>
                <td valign="top">Toolmaker</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">324211</td>
                <td valign="top">Vehicle Body Builder</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">324212</td>
                <td valign="top">Vehicle Trimmer</td>
                <td valign="top">TRA</td>
                <td valign="top">3 (Closed)</td>
              </tr>
              <tr>
                <td valign="top">333311</td>
                <td valign="top">Roof Tiler</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">342311</td>
                <td valign="top">Business Machine Mechanic</td>
                <td valign="top">TRA</td>
                <td valign="top">3&nbsp;(Closed)</td>
              </tr>
              <tr>
                <td valign="top">342411</td>
                <td valign="top">Cabler (Data and Telecommunications)</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">342413</td>
                <td valign="top">Telecommunications Linesworker</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">351111</td>
                <td valign="top">Baker</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">351112</td>
                <td valign="top">Pastrycook</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">351211</td>
                <td valign="top">Butcher or Smallgoods Maker</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">351411</td>
                <td valign="top">Cook</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">361111</td>
                <td valign="top">Dog Handler or Trainer</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">361199</td>
                <td valign="top">Animal Attendants and Trainers nec</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">3&nbsp;(Closed)</td>
              </tr>
              <tr>
                <td valign="top">361311</td>
                <td valign="top">Veterinary Nurse</td>
                <td valign="top">VETASSESS</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">362111</td>
                <td valign="top">Florist</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">362211</td>
                <td valign="top">Gardener (General)</td>
                <td valign="top">TRA</td>
                <td valign="top">3&nbsp;(Closed)</td>
              </tr>
              <tr>
                <td valign="top">362212</td>
                <td valign="top">Arborist</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">362213</td>
                <td valign="top">Landscape Gardener</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">362311</td>
                <td valign="top">Greenkeeper</td>
                <td valign="top">TRA</td>
                <td valign="top">3</td>
              </tr>
              <tr>
                <td valign="top">391111</td>
              </tr>
            </tbody>
          </table>
        </div>
      </div>
      <div class="col-md-4 col-sm-4 col-xs-12">
        <?php include('enquiry-form.php')?>
      </div>
    </div>
  </div>
</div>
</div>
</div>
<?php include 'inc/footer.php'; ?>
