<?php include 'inc/header.php'; ?>
<div class="page-area">
    <div class="breadcumb-overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="breadcrumb">
                    <div class="bread-inner">
                        <div class="section-headline white-headline">
                            <h2>Tasmanian Skilled <span class="color"> Occupation List</span></h2>
                        </div>
                        <ul class="breadcrumb-bg">
                            <li class="home-bread"><a href="index.php">Home</a></li>
                            <li>Tasmanian Skilled Occupation List</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="team-area bg-color pd-35">
    <div class="container">
        <!-- section head -->
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-headline text-center">
                    <h3>Tasmanian Skilled <span class="color"> Occupation List</span></h3>
                </div>
            </div>
        </div>
        <div class="row">
		 <div class="col-md-8 col-sm-8 col-xs-12" style="box-shadow: 5px 3px 10px rgb(0 0 0 / 10%);">
<div class='text-justify innerpage-text'><p>The <strong>Tasmanian Skilled Occupations List</strong> defines occupations that have been identified by according to the extent of evidence available as areas of skills shortage.</p>
<table border="1" bordercolor="#CCC" cellpadding="8" cellspacing="0" height="100%" width="90%">
<tbody>
<tr bgcolor="#F00" style="color:#FFF">
<td valign="top" width="178">
<p>111111</p>
</td>
<td valign="top" width="178">
<p>Chief Executive or Managing Director</p>
</td>
<td valign="top" width="178">
<p>AIM</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>111211</p>
</td>
<td valign="top" width="178">
<p>Corporate General Manager</p>
</td>
<td valign="top" width="178">
<p>AIM</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>121213</p>
</td>
<td valign="top" width="178">
<p>Fruit or Nut Grower</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>121215</p>
</td>
<td valign="top" width="178">
<p>Grape Grower</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>121216</p>
</td>
<td valign="top" width="178">
<p>Mixed Crop Farmer</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>121221</p>
</td>
<td valign="top" width="178">
<p>Vegetable Grower</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>121299</p>
</td>
<td valign="top" width="178">
<p>Crop Farmers nec</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>121312</p>
</td>
<td valign="top" width="178">
<p>Beef Cattle Farmer</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>121313</p>
</td>
<td valign="top" width="178">
<p>Dairy Cattle Farmer</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>121316</p>
</td>
<td valign="top" width="178">
<p>Horse Breeder</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>121317</p>
</td>
<td valign="top" width="178">
<p>Mixed Livestock Farmer</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>121318</p>
</td>
<td valign="top" width="178">
<p>Pig Farmer</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>121321</p>
</td>
<td valign="top" width="178">
<p>Poultry Farmer</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>121322</p>
</td>
<td valign="top" width="178">
<p>Sheep Farmer</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>121399</p>
</td>
<td valign="top" width="178">
<p>Livestock Farmers nec</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>131112</p>
</td>
<td valign="top" width="178">
<p>Sales and Marketing Manager</p>
</td>
<td valign="top" width="178">
<p>AIM</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>132211</p>
</td>
<td valign="top" width="178">
<p>Finance Manager</p>
</td>
<td valign="top" width="178">
<p>CPA/ICA/AIPA</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>133111</p>
</td>
<td valign="top" width="178">
<p>Construction Project Manager</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>133211</p>
</td>
<td valign="top" width="178">
<p>Engineering Manager</p>
</td>
<td valign="top" width="178">
<p>Engineers Australia/AIM</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>133611</p>
</td>
<td valign="top" width="178">
<p>Supply and Distribution Manager</p>
</td>
<td valign="top" width="178">
<p>AIM</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>134212</p>
</td>
<td valign="top" width="178">
<p>Nursing Clinical Director</p>
</td>
<td valign="top" width="178">
<p>ANMAC</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>134213</p>
</td>
<td valign="top" width="178">
<p>Primary Health Organisation Manager</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>134214</p>
</td>
<td valign="top" width="178">
<p>Welfare Centre Manager</p>
</td>
<td valign="top" width="178">
<p>ACWA/VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>135111</p>
</td>
<td valign="top" width="178">
<p>Chief Information Officer</p>
</td>
<td valign="top" width="178">
<p>ACS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>135112</p>
</td>
<td valign="top" width="178">
<p>ICT Project Manager</p>
</td>
<td valign="top" width="178">
<p>ACS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>135199</p>
</td>
<td valign="top" width="178">
<p>ICT Managers nec</p>
</td>
<td valign="top" width="178">
<p>ACS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>139914</p>
</td>
<td valign="top" width="178">
<p>Quality Assurance Manager</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>141111</p>
</td>
<td valign="top" width="178">
<p>Cafe or Restaurant Manager</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>141311</p>
</td>
<td valign="top" width="178">
<p>Hotel or Motel Manager</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>149413</p>
</td>
<td valign="top" width="178">
<p>Transport Company Manager</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>224711</p>
</td>
<td valign="top" width="178">
<p>Management Consultant</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>224712</p>
</td>
<td valign="top" width="178">
<p>Organisation and Methods Analyst</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>232111</p>
</td>
<td valign="top" width="178">
<p>Architect</p>
</td>
<td valign="top" width="178">
<p>AACA</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>232212</p>
</td>
<td valign="top" width="178">
<p>Surveyor</p>
</td>
<td valign="top" width="178">
<p>SSSI</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>232312</p>
</td>
<td valign="top" width="178">
<p>Industrial Designer</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>232611</p>
</td>
<td valign="top" width="178">
<p>Urban and Regional Planner</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td>233211</td>
<td>Civil Engineer</td>
<td>Engineers Australia</td>
</tr>
<tr>
<td>233212</td>
<td>Geotechnical Engineer</td>
<td>Engineers Australia</td>
</tr>
<tr>
<td valign="top" width="178">
<p>233213</p>
</td>
<td valign="top" width="178">
<p>Quantity Surveyor</p>
</td>
<td valign="top" width="178">
<p>AIQS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>233214</p>
</td>
<td valign="top" width="178">
<p>Structural Engineer</p>
</td>
<td valign="top" width="178">
<p>Engineers Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>233215</p>
</td>
<td valign="top" width="178">
<p>Transport Engineer</p>
</td>
<td valign="top" width="178">
<p>Engineers Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>233311</p>
</td>
<td valign="top" width="178">
<p>Electrical Engineer</p>
</td>
<td valign="top" width="178">
<p>Engineers Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>233512</p>
</td>
<td valign="top" width="178">
<p>Mechanical Engineer</p>
</td>
<td valign="top" width="178">
<p>Engineers Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>233611</p>
</td>
<td valign="top" width="178">
<p>Mining Engineer (Excluding Petroleum)</p>
</td>
<td valign="top" width="178">
<p>Engineers Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>233911</p>
</td>
<td valign="top" width="178">
<p>Aeronautical Engineer</p>
</td>
<td valign="top" width="178">
<p>Engineers Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>233914</p>
</td>
<td valign="top" width="178">
<p>Engineering Technologist</p>
</td>
<td valign="top" width="178">
<p>Engineers Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>233999</p>
</td>
<td valign="top" width="178">
<p>Engineering Professionals nec</p>
</td>
<td valign="top" width="178">
<p>Engineers Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>234111</p>
</td>
<td valign="top" width="178">
<p>Agricultural Consultant</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>234112</p>
</td>
<td valign="top" width="178">
<p>Agricultural Scientist</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>234213</p>
</td>
<td valign="top" width="178">
<p>Wine Maker</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>234711</p>
</td>
<td valign="top" width="178">
<p>Veterinarian</p>
</td>
<td valign="top" width="178">
<p>AVBC</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>234914</p>
</td>
<td valign="top" width="178">
<p>Physicist (Medical Physicist only)</p>
</td>
<td valign="top" width="178">
<p>ACPSEM</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>234914</p>
</td>
<td valign="top" width="178">
<p>Physicist</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>241213</p>
</td>
<td valign="top" width="178">
<p>Primary School Teacher</p>
</td>
<td valign="top" width="178">
<p>AITSL</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>241411</p>
</td>
<td valign="top" width="178">
<p>Secondary School Teacher</p>
</td>
<td valign="top" width="178">
<p>AITSL</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>241511</p>
</td>
<td valign="top" width="178">
<p>Special Needs Teacher</p>
</td>
<td valign="top" width="178">
<p>AITSL</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>251111</p>
</td>
<td valign="top" width="178">
<p>Dietitian</p>
</td>
<td valign="top" width="178">
<p>DAA</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>251211</p>
</td>
<td valign="top" width="178">
<p>Medical Diagnostic Radiographer</p>
</td>
<td valign="top" width="178">
<p>AIR</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>251212</p>
</td>
<td valign="top" width="178">
<p>Medical Radiation Therapist</p>
</td>
<td valign="top" width="178">
<p>AIR</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>251214</p>
</td>
<td valign="top" width="178">
<p>Sonographer</p>
</td>
<td valign="top" width="178">
<p>AIR</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>251912</p>
</td>
<td valign="top" width="178">
<p>Orthotist or Prosthetist</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>252111</p>
</td>
<td valign="top" width="178">
<p>Chiropractor</p>
</td>
<td valign="top" width="178">
<p>CCEA</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>252112</p>
</td>
<td valign="top" width="178">
<p>Osteopath</p>
</td>
<td valign="top" width="178">
<p>ANZOC</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>252311</p>
</td>
<td valign="top" width="178">
<p>Dental Specialist</p>
</td>
<td valign="top" width="178">
<p>ADC</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>252312</p>
</td>
<td valign="top" width="178">
<p>Dentist</p>
</td>
<td valign="top" width="178">
<p>ADC</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>252411</p>
</td>
<td valign="top" width="178">
<p>Occupational Therapist</p>
</td>
<td valign="top" width="178">
<p>OTC</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>252511</p>
</td>
<td valign="top" width="178">
<p>Physiotherapist</p>
</td>
<td valign="top" width="178">
<p>APC</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>252611</p>
</td>
<td valign="top" width="178">
<p>Podiatrist</p>
</td>
<td valign="top" width="178">
<p>APodC/ANZPAC</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>252711</p>
</td>
<td valign="top" width="178">
<p>Audiologist</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>252712</p>
</td>
<td valign="top" width="178">
<p>Speech Pathologist</p>
</td>
<td valign="top" width="178">
<p>SPA</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>253111</p>
</td>
<td valign="top" width="178">
<p>General Practitioner</p>
</td>
<td valign="top" width="178">
<p>Medical Board of Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>253211</p>
</td>
<td valign="top" width="178">
<p>Anaesthetist</p>
</td>
<td valign="top" width="178">
<p>Medical Board of Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>253311</p>
</td>
<td valign="top" width="178">
<p>Specialist Physician (General Medicine)</p>
</td>
<td valign="top" width="178">
<p>Medical Board of Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>253312</p>
</td>
<td valign="top" width="178">
<p>Cardiologist</p>
</td>
<td valign="top" width="178">
<p>Medical Board of Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>253313</p>
</td>
<td valign="top" width="178">
<p>Clinical Haematologist</p>
</td>
<td valign="top" width="178">
<p>Medical Board of Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>253314</p>
</td>
<td valign="top" width="178">
<p>Medical Oncologist</p>
</td>
<td valign="top" width="178">
<p>Medical Board of Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>253315</p>
</td>
<td valign="top" width="178">
<p>Endocrinologist</p>
</td>
<td valign="top" width="178">
<p>Medical Board of Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>253316</p>
</td>
<td valign="top" width="178">
<p>Gastroenterologist</p>
</td>
<td valign="top" width="178">
<p>Medical Board of Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>253317</p>
</td>
<td valign="top" width="178">
<p>Intensive Care Specialist</p>
</td>
<td valign="top" width="178">
<p>Medical Board of Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>253318</p>
</td>
<td valign="top" width="178">
<p>Neurologist</p>
</td>
<td valign="top" width="178">
<p>Medical Board of Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>253321</p>
</td>
<td valign="top" width="178">
<p>Paediatrician</p>
</td>
<td valign="top" width="178">
<p>Medical Board of Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>253411</p>
</td>
<td valign="top" width="178">
<p>Psychiatrist</p>
</td>
<td valign="top" width="178">
<p>Medical Board of Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>253511</p>
</td>
<td valign="top" width="178">
<p>Surgeon (General)</p>
</td>
<td valign="top" width="178">
<p>Medical Board of Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>253512</p>
</td>
<td valign="top" width="178">
<p>Cardiothoracic Surgeon</p>
</td>
<td valign="top" width="178">
<p>Medical Board of Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>253513</p>
</td>
<td valign="top" width="178">
<p>Neurosurgeon</p>
</td>
<td valign="top" width="178">
<p>Medical Board of Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>253514</p>
</td>
<td valign="top" width="178">
<p>Orthopaedic Surgeon</p>
</td>
<td valign="top" width="178">
<p>Medical Board of Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>253515</p>
</td>
<td valign="top" width="178">
<p>Otorhinolaryngologist</p>
</td>
<td valign="top" width="178">
<p>Medical Board of Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>253516</p>
</td>
<td valign="top" width="178">
<p>Paediatric Surgeon</p>
</td>
<td valign="top" width="178">
<p>Medical Board of Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>253517</p>
</td>
<td valign="top" width="178">
<p>Plastic and Reconstructive Surgeon</p>
</td>
<td valign="top" width="178">
<p>Medical Board of Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>253518</p>
</td>
<td valign="top" width="178">
<p>Urologist</p>
</td>
<td valign="top" width="178">
<p>Medical Board of Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>253521</p>
</td>
<td valign="top" width="178">
<p>Vascular Surgeon</p>
</td>
<td valign="top" width="178">
<p>Medical Board of Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>253911</p>
</td>
<td valign="top" width="178">
<p>Dermatologist</p>
</td>
<td valign="top" width="178">
<p>Medical Board of Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>253912</p>
</td>
<td valign="top" width="178">
<p>Emergency Medicine Specialist</p>
</td>
<td valign="top" width="178">
<p>Medical Board of Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>253913</p>
</td>
<td valign="top" width="178">
<p>Obstetrician and Gynaecologist</p>
</td>
<td valign="top" width="178">
<p>Medical Board of Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>253914</p>
</td>
<td valign="top" width="178">
<p>Ophthalmologist</p>
</td>
<td valign="top" width="178">
<p>Medical Board of Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>253915</p>
</td>
<td valign="top" width="178">
<p>Pathologist</p>
</td>
<td valign="top" width="178">
<p>Medical Board of Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>253917</p>
</td>
<td valign="top" width="178">
<p>Diagnostic and Interventional Radiologist</p>
</td>
<td valign="top" width="178">
<p>Medical Board of Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>253918</p>
</td>
<td valign="top" width="178">
<p>Radiation Oncologist</p>
</td>
<td valign="top" width="178">
<p>Medical Board of Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>253999</p>
</td>
<td valign="top" width="178">
<p>Medical Practitioners nec</p>
</td>
<td valign="top" width="178">
<p>Medical Board of Australia</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>254111</p>
</td>
<td valign="top" width="178">
<p>Midwife</p>
</td>
<td valign="top" width="178">
<p>ANMAC</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>254411</p>
</td>
<td valign="top" width="178">
<p>Nurse Practitioner</p>
</td>
<td valign="top" width="178">
<p>ANMAC</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>254412</p>
</td>
<td valign="top" width="178">
<p>Registered Nurse (Aged Care)</p>
</td>
<td valign="top" width="178">
<p>ANMAC</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>254413</p>
</td>
<td valign="top" width="178">
<p>Registered Nurse (Child and Family Health)</p>
</td>
<td valign="top" width="178">
<p>ANMAC</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>254414</p>
</td>
<td valign="top" width="178">
<p>Registered Nurse (Community Health)</p>
</td>
<td valign="top" width="178">
<p>ANMAC</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>254415</p>
</td>
<td valign="top" width="178">
<p>Registered Nurse (Critical Care and Emergency)</p>
</td>
<td valign="top" width="178">
<p>ANMAC</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>254416</p>
</td>
<td valign="top" width="178">
<p>Registered Nurse (Developmental Disability)</p>
</td>
<td valign="top" width="178">
<p>ANMAC</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>254417</p>
</td>
<td valign="top" width="178">
<p>Registered Nurse (Disability and Rehabilitation)</p>
</td>
<td valign="top" width="178">
<p>ANMAC</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>254418</p>
</td>
<td valign="top" width="178">
<p>Registered Nurse (Medical)</p>
</td>
<td valign="top" width="178">
<p>ANMAC</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>254421</p>
</td>
<td valign="top" width="178">
<p>Registered Nurse (Medical Practice)</p>
</td>
<td valign="top" width="178">
<p>ANMAC</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>254422</p>
</td>
<td valign="top" width="178">
<p>Registered Nurse (Mental Health)</p>
</td>
<td valign="top" width="178">
<p>ANMAC</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>254423</p>
</td>
<td valign="top" width="178">
<p>Registered Nurse (Perioperative)</p>
</td>
<td valign="top" width="178">
<p>ANMAC</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>254499</p>
</td>
<td valign="top" width="178">
<p>Registered Nurses nec</p>
</td>
<td valign="top" width="178">
<p>ACS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>261111</p>
</td>
<td valign="top" width="178">
<p>ICT business Analyst</p>
</td>
<td valign="top" width="178">
<p>ACS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>261112</p>
</td>
<td valign="top" width="178">
<p>Systems Analyst</p>
</td>
<td valign="top" width="178">
<p>ACS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>261311</p>
</td>
<td valign="top" width="178">
<p>Analyst Programmer</p>
</td>
<td valign="top" width="178">
<p>ACS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>261312</p>
</td>
<td valign="top" width="178">
<p>Developer Programmer</p>
</td>
<td valign="top" width="178">
<p>ACS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>261313</p>
</td>
<td valign="top" width="178">
<p>Software Engineer</p>
</td>
<td valign="top" width="178">
<p>ACS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>261399</p>
</td>
<td valign="top" width="178">
<p>Software and Applications Programmers nec</p>
</td>
<td valign="top" width="178">
<p>ACS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>262111</p>
</td>
<td valign="top" width="178">
<p>Database Administrator</p>
</td>
<td valign="top" width="178">
<p>ACS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>262112</p>
</td>
<td valign="top" width="178">
<p>ICT Security Specialist</p>
</td>
<td valign="top" width="178">
<p>ACS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>262113</p>
</td>
<td valign="top" width="178">
<p>Systems Administrator</p>
</td>
<td valign="top" width="178">
<p>ACS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>272311</p>
</td>
<td valign="top" width="178">
<p>Clinical Psychologist</p>
</td>
<td valign="top" width="178">
<p>APS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>272399</p>
</td>
<td valign="top" width="178">
<p>Psychologists nec</p>
</td>
<td valign="top" width="178">
<p>APS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>272412</p>
</td>
<td valign="top" width="178">
<p>Interpreter</p>
</td>
<td valign="top" width="178">
<p>NAATI</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>272511</p>
</td>
<td valign="top" width="178">
<p>Social Worker</p>
</td>
<td valign="top" width="178">
<p>AASW</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>311111</p>
</td>
<td valign="top" width="178">
<p>Agricultural Technician</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>312111</p>
</td>
<td valign="top" width="178">
<p>Architectural Draftsperson</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>313111</p>
</td>
<td valign="top" width="178">
<p>Hardware Technician</p>
</td>
<td valign="top" width="178">
<p>TRA</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>313112</p>
</td>
<td valign="top" width="178">
<p>ICT Customer Support Officer</p>
</td>
<td valign="top" width="178">
<p>TRA</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>313113</p>
</td>
<td valign="top" width="178">
<p>Web Administrator</p>
</td>
<td valign="top" width="178">
<p>ACS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>321111</p>
</td>
<td valign="top" width="178">
<p>Automotive Electrician</p>
</td>
<td valign="top" width="178">
<p>TRA</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>321211</p>
</td>
<td valign="top" width="178">
<p>Motor Mechanic (General)</p>
</td>
<td valign="top" width="178">
<p>TRA</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>321212</p>
</td>
<td valign="top" width="178">
<p>Diesel Motor Mechanic</p>
</td>
<td valign="top" width="178">
<p>TRA</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>321213</p>
</td>
<td valign="top" width="178">
<p>Motorcycle Mechanic</p>
</td>
<td valign="top" width="178">
<p>TRA</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>321214</p>
</td>
<td valign="top" width="178">
<p>Small Engine Mechanic</p>
</td>
<td valign="top" width="178">
<p>TRA</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>323211</p>
</td>
<td valign="top" width="178">
<p>Fitter (General)</p>
</td>
<td valign="top" width="178">
<p>TRA</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>323212</p>
</td>
<td valign="top" width="178">
<p>Fitter and Turner</p>
</td>
<td valign="top" width="178">
<p>TRA</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>323213</p>
</td>
<td valign="top" width="178">
<p>Fitter-Welder</p>
</td>
<td valign="top" width="178">
<p>TRA</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>323214</p>
</td>
<td valign="top" width="178">
<p>Metal Machinist (First Class)</p>
</td>
<td valign="top" width="178">
<p>TRA</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>324111</p>
</td>
<td valign="top" width="178">
<p>Panelbeater</p>
</td>
<td valign="top" width="178">
<p>TRA</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>331111</p>
</td>
<td valign="top" width="178">
<p>Bricklayer</p>
</td>
<td valign="top" width="178">
<p>TRA</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>331211</p>
</td>
<td valign="top" width="178">
<p>Carpenter and Joiner</p>
</td>
<td valign="top" width="178">
<p>TRA</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>331212</p>
</td>
<td valign="top" width="178">
<p>Carpenter</p>
</td>
<td valign="top" width="178">
<p>TRA</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>332211</p>
</td>
<td valign="top" width="178">
<p>Painting trades workers</p>
</td>
<td valign="top" width="178">
<p>TRA</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>333111</p>
</td>
<td valign="top" width="178">
<p>Glazier</p>
</td>
<td valign="top" width="178">
<p>TRA</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>333211</p>
</td>
<td valign="top" width="178">
<p>Fibrous Plasterer</p>
</td>
<td valign="top" width="178">
<p>TRA</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>333311</p>
</td>
<td valign="top" width="178">
<p>Roof Tiler</p>
</td>
<td valign="top" width="178">
<p>TRA</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>333411</p>
</td>
<td valign="top" width="178">
<p>Wall and Floor Tiler</p>
</td>
<td valign="top" width="178">
<p>TRA</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>334111</p>
</td>
<td valign="top" width="178">
<p>Plumber (General)</p>
</td>
<td valign="top" width="178">
<p>TRA</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>351112</p>
</td>
<td valign="top" width="178">
<p>Pastrycook</p>
</td>
<td valign="top" width="178">
<p>TRA</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>351311</p>
</td>
<td valign="top" width="178">
<p>Chef&nbsp;</p>
</td>
<td valign="top" width="178">
<p>TRA</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>351411</p>
</td>
<td valign="top" width="178">
<p>Cook&nbsp;</p>
</td>
<td valign="top" width="178">
<p>TRA</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>362211</p>
</td>
<td valign="top" width="178">
<p>Gardener (General)</p>
</td>
<td valign="top" width="178">
<p>TRA</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>391111</p>
</td>
<td valign="top" width="178">
<p>Hairdresser</p>
</td>
<td valign="top" width="178">
<p>TRA</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>399312</p>
</td>
<td valign="top" width="178">
<p>Library Technician</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>411111</p>
</td>
<td valign="top" width="178">
<p>Ambulance Officer</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>411112</p>
</td>
<td valign="top" width="178">
<p>Intensive Care Ambulance Paramedic</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>411213</p>
</td>
<td valign="top" width="178">
<p>Dental Technician</p>
</td>
<td valign="top" width="178">
<p>TRA</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>411411</p>
</td>
<td valign="top" width="178">
<p>Enrolled Nurse</p>
</td>
<td valign="top" width="178">
<p>ANMAC</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>411711</p>
</td>
<td valign="top" width="178">
<p>Community Worker</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>411712</p>
</td>
<td valign="top" width="178">
<p>Disabilities Services Officer</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
 </td>
</tr>
<tr>
<td valign="top" width="178">
<p>411715</p>
</td>
<td valign="top" width="178">
<p>Residential Care Officer</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
<tr>
<td valign="top" width="178">
<p>411716</p>
</td>
<td valign="top" width="178">
<p>Youth Worker</p>
</td>
<td valign="top" width="178">
<p>VETASSESS</p>
</td>
</tr>
</tbody>
</table>
<p>&nbsp;</p>
</div>
</div>
		 <div class="col-md-4 col-sm-4 col-xs-12">
		 <?php include('enquiry-form.php')?>
		 </div>
                
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>