<?php include 'inc/header.php'; ?>

<div class="page-area">
  <div class="breadcumb-overlay"></div>
  <div class="container">
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="breadcrumb">
          <div class="bread-inner">
            <div class="section-headline white-headline">
              <h2>Western Australian Skilled Migration  <span class="color"> Occupation List</span></h2>
            </div>
            <ul class="breadcrumb-bg">
              <li class="home-bread"><a href="index.php">Home</a></li>
              <li>Western Australian Skilled Migration Occupation List</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="team-area bg-color pd-35">
  <div class="container">
    <!-- section head -->
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="section-headline text-center">
          <h3>Western Australian Skilled Migration  <span class="color"> Occupation List</span></h3>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-8 col-sm-8 col-xs-12" style="box-shadow: 5px 3px 10px rgb(0 0 0 / 10%);">
        <div class='text-justify innerpage-text'>
          <p>Applicants who have an occupation identified on the Western Australian skilled migration occupation list (shown below) may be eligible&nbsp;for Western Australian State&nbsp;nomination using the following visas:</p>
          <p><a href="australia-skilled-nominated-subclass-190-immigration-visa.html" target="_blank">Skilled &ndash; State&nbsp;Nominated (Subclass 190) Visa</a> or <a href="skilled-work-regional-provisional-visa-491.html" target="_blank">Skilled &ndash; Nominated (Provisional) (Subclass 489) Visa</a></p>
          <h2>Schedule 1</h2>
          <table border="0" bordercolor="#CCC" cellpadding="0" cellspacing="0">
            <tbody>
              <tr bgcolor="#F00" style="color:#FFF">
                <td>ANZSCO code*</td>
                <td>Skilled occupation</td>
                <td>Assessing authority</td>
                <td>Status</td>
              </tr>
              <tr>
                <td colspan="4"><p><strong>Managers</strong></p></td>
              </tr>
              <tr>
                <td>121214</td>
                <td>Grain, oilseed or pasture grower</td>
                <td>VETASSESS</td>
                <td>Available</td>
              </tr>
              <tr>
                <td>121312</td>
                <td>Beef cattle farmer</td>
                <td>VETASSESS</td>
                <td>Available</td>
              </tr>
              <tr>
                <td>121313</td>
                <td>Dairy cattle farmer</td>
                <td>VETASSESS</td>
                <td>Available</td>
              </tr>
              <tr>
                <td>121322</td>
                <td>Sheep farmer</td>
                <td>VETASSESS</td>
                <td>Available</td>
              </tr>
              <tr>
                <td rowspan="1">121411</td>
                <td rowspan="1">Mixed crop and livestock farmer</td>
                <td rowspan="1">VETASSESS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">149411</td>
                <td rowspan="1">Fleet manager</td>
                <td rowspan="1">VETASSESS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td colspan="4"><p><strong>Professionals</strong></p></td>
              </tr>
              <tr>
                <td>231111</td>
                <td>Aeroplane pilot</td>
                <td>CASA</td>
                <td>Available</td>
              </tr>
              <tr>
                <td rowspan="1">231113</td>
                <td rowspan="1">Flying instructor</td>
                <td rowspan="1">VETASSESS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td>233912</td>
                <td>Agricultural engineer</td>
                <td>Engineers Australia</td>
                <td>Available</td>
              </tr>
              <tr>
                <td>251214</td>
                <td>Sonographer</td>
                <td>ASMIRT</td>
                <td>Available</td>
              </tr>
              <tr>
                <td>253312&nbsp;&nbsp;</td>
                <td>Cardiologist</td>
                <td>Medical Board of Australia</td>
                <td>Available&nbsp;</td>
              </tr>
              <tr>
                <td>253315</td>
                <td>Endocrinologist</td>
                <td>Medical Board of Australia</td>
                <td>Available&nbsp;</td>
              </tr>
              <tr>
                <td>253316&nbsp;&nbsp;</td>
                <td>Gastroenterologist</td>
                <td>Medical Board of Australia</td>
                <td>Available&nbsp;</td>
              </tr>
              <tr>
                <td>253318</td>
                <td>Neurologist</td>
                <td>Medical Board of Australia</td>
                <td>Available</td>
              </tr>
              <tr>
                <td>253322&nbsp;&nbsp;</td>
                <td>Renal medicine specialist</td>
                <td>Medical Board of Australia</td>
                <td>Available</td>
              </tr>
              <tr>
                <td>253323&nbsp;&nbsp;</td>
                <td>Rheumatologist</td>
                <td>Medical Board of Australia</td>
                <td>Available</td>
              </tr>
              <tr>
                <td>253411</td>
                <td>Psychiatrist</td>
                <td>Medical Board of Australia</td>
                <td>Available</td>
              </tr>
              <tr>
                <td rowspan="1">253511</td>
                <td rowspan="1">Surgeon (general)</td>
                <td rowspan="1">Medical Board of Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td>253512</td>
                <td>Cardiothoracic surgeon</td>
                <td>Medical Board of Australia</td>
                <td>Available</td>
              </tr>
              <tr>
                <td rowspan="1">253513</td>
                <td rowspan="1">Neurosurgeon</td>
                <td rowspan="1">Medical Board of Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">253514</td>
                <td rowspan="1">Orthopaedic surgeon</td>
                <td rowspan="1">Medical Board of Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">253515</td>
                <td rowspan="1">Otorhinolaryngologist</td>
                <td rowspan="1">Medical Board of Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">253518</td>
                <td rowspan="1">Urologist</td>
                <td rowspan="1">Medical Board of Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">253521</td>
                <td rowspan="1">Vascular surgeon</td>
                <td rowspan="1">Medical Board of Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">253911</td>
                <td rowspan="1">Dermatologist</td>
                <td rowspan="1">Medical Board of Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">253913</td>
                <td rowspan="1">Obstetrician and gynaecologist</td>
                <td rowspan="1">Medical Board of Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">253914</td>
                <td rowspan="1">Ophthalmologist</td>
                <td rowspan="1">Medical Board of Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">253915</td>
                <td rowspan="1">Pathologist</td>
                <td rowspan="1">Medical Board of Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">253917</td>
                <td rowspan="1">Diagnostic and interventional radiologist</td>
                <td rowspan="1">Medical Board of Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">253918</td>
                <td rowspan="1">Radiation oncologist</td>
                <td rowspan="1">Medical Board of Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr dir="ltr">
                <td colspan="4" rowspan="1"><strong>Technicians and trades workers</strong></td>
              </tr>
              <tr>
                <td rowspan="1">361112</td>
                <td rowspan="1">Horse trainer</td>
                <td rowspan="1">TRA</td>
                <td rowspan="1">Available</td>
              </tr>
            </tbody>
          </table>
          <p>&nbsp;</p>
          <table>
            <tbody>
              <tr>
                <td colspan="4" rowspan="1"><h2>Schedule 2</h2></td>
              </tr>
              <tr bgcolor="#F00" style="color:#FFF">
                <td>ANZSCO code*</td>
                <td>Skilled occupation</td>
                <td>Assessing authority</td>
                <td>Status</td>
              </tr>
              <tr>
                <td colspan="4" rowspan="1"><strong>Managers</strong></td>
              </tr>
              <tr>
                <td rowspan="1">111111</td>
                <td rowspan="1">Chief executive or managing director</td>
                <td rowspan="1">AIM</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">132311</td>
                <td rowspan="1">Human resource manager</td>
                <td rowspan="1">AIM</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">133211</td>
                <td rowspan="1">Engineering manager</td>
                <td rowspan="1">Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">134111</td>
                <td rowspan="1">Child care centre manager</td>
                <td rowspan="1">TRA</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">134211</td>
                <td rowspan="1">Medical administrator</td>
                <td rowspan="1">VETASSESS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">134212</td>
                <td rowspan="1">Nursing clinical director</td>
                <td rowspan="1">ANMAC</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">134311</td>
                <td rowspan="1">School principal</td>
                <td rowspan="1">VETASSESS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">135112</td>
                <td rowspan="1">ICT project manager</td>
                <td rowspan="1">ACS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">139912</td>
                <td rowspan="1">Environmental manager</td>
                <td rowspan="1">VETASSESS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">141311</td>
                <td rowspan="1">Hotel or motel manager</td>
                <td rowspan="1">VETASSESS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td colspan="4" rowspan="1"><strong>Professionals</strong></td>
              </tr>
              <tr>
                <td rowspan="1">222311</td>
                <td rowspan="1">Financial investment adviser</td>
                <td rowspan="1">VETASSESS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">222312</td>
                <td rowspan="1">Financial investment manager</td>
                <td rowspan="1">VETASSESS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">231114</td>
                <td rowspan="1">Helicopter pilot</td>
                <td rowspan="1">CASA</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">231211</td>
                <td rowspan="1">Master fisher</td>
                <td rowspan="1">VETASSESS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">231212</td>
                <td rowspan="1">Ship&#39;s engineer</td>
                <td rowspan="1">AMSA</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">231213</td>
                <td rowspan="1">Ship&#39;s master</td>
                <td rowspan="1">AMSA</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">231214</td>
                <td rowspan="1">Ship&#39;s officer</td>
                <td rowspan="1">AMSA</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">232611</td>
                <td rowspan="1">Urban and regional planner</td>
                <td rowspan="1">VETASSESS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">233111</td>
                <td rowspan="1">Chemical engineer</td>
                <td rowspan="1">Engineers Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">233112</td>
                <td rowspan="1">Materials engineer</td>
                <td rowspan="1">Engineers Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">233212</td>
                <td rowspan="1">Geotechnical engineer</td>
                <td rowspan="1">Engineers Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">233213</td>
                <td rowspan="1">Quantity surveyor</td>
                <td rowspan="1">AIQS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">233214</td>
                <td rowspan="1">Structural engineer</td>
                <td rowspan="1">Engineers Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">233311</td>
                <td rowspan="1">Electrical engineer</td>
                <td rowspan="1">Engineers Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">233411</td>
                <td rowspan="1">Electronics engineer</td>
                <td rowspan="1">Engineers Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">233511</td>
                <td rowspan="1">Industrial engineer</td>
                <td rowspan="1">Engineers Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">233512</td>
                <td rowspan="1">Mechanical engineer</td>
                <td rowspan="1">Engineers Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">233513</td>
                <td rowspan="1">Production or plant engineer</td>
                <td rowspan="1">Engineers Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">233611</td>
                <td rowspan="1">Mining engineer (excluding petroleum)</td>
                <td rowspan="1">Engineers Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">233612</td>
                <td rowspan="1">Petroleum engineer</td>
                <td rowspan="1">Engineers Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">233911</td>
                <td rowspan="1">Aeronautical engineer</td>
                <td rowspan="1">Engineers Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">233913</td>
                <td rowspan="1">Biomedical engineer</td>
                <td rowspan="1">Engineers Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">233915</td>
                <td rowspan="1">Environmental engineer</td>
                <td rowspan="1">Engineers Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">234111</td>
                <td rowspan="1">Agricultural consultant</td>
                <td rowspan="1">VETASSESS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">234112</td>
                <td rowspan="1">Agricultural scientist</td>
                <td rowspan="1">VETASSESS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">234211</td>
                <td rowspan="1">Chemist</td>
                <td rowspan="1">VETASSESS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">234411</td>
                <td rowspan="1">Geologist</td>
                <td rowspan="1">VETASSESS</td>
                <td rowspan="1">Closed</td>
              </tr>
              <tr>
                <td rowspan="1">234412</td>
                <td rowspan="1">Geophysicist</td>
                <td rowspan="1">VETASSESS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">234514</td>
                <td rowspan="1">Biotechnologist</td>
                <td rowspan="1">VETASSESS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">234611</td>
                <td rowspan="1">Medical laboratory scientist</td>
                <td rowspan="1">AIMS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">234711</td>
                <td rowspan="1">Veterinarian</td>
                <td rowspan="1">AVBC</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">234912</td>
                <td rowspan="1">Metallurgist</td>
                <td rowspan="1">VETASSESS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">241411</td>
                <td rowspan="1">Secondary school teacher</td>
                <td rowspan="1">AITSL</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">241511</td>
                <td rowspan="1">Special needs teacher</td>
                <td rowspan="1">AITSL</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">241512</td>
                <td rowspan="1">Teacher of the hearing impaired</td>
                <td rowspan="1">AITSL</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">241513</td>
                <td rowspan="1">Teacher of the sight impaired</td>
                <td rowspan="1">AITSL</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">251211</td>
                <td rowspan="1">Medical diagnostic radiographer</td>
                <td rowspan="1">ASMIRT</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <th colspan="1" rowspan="1">251212</th>
                <td rowspan="1">Medical radiation therapist</td>
                <td rowspan="1">ASMIRT</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <th colspan="1" rowspan="1">251213</th>
                <td rowspan="1">Nuclear medicine technologist</td>
                <td rowspan="1">ANZSNM</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">251311</td>
                <td rowspan="1">Environmental health officer</td>
                <td rowspan="1">VETASSESS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">251411</td>
                <td rowspan="1">Optometrist</td>
                <td rowspan="1">OCANZ</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">251412</td>
                <td rowspan="1">Orthoptist</td>
                <td rowspan="1">VETASSESS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">251511</td>
                <td rowspan="1">Hospital pharmacist</td>
                <td rowspan="1">APharmC</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">251512</td>
                <td rowspan="1">Industrial pharmacist</td>
                <td rowspan="1">VETASSESS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">251912</td>
                <td rowspan="1">Orthotist or prosthetist</td>
                <td rowspan="1">VETASSESS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">252112</td>
                <td rowspan="1">Osteopath</td>
                <td rowspan="1">AOAC</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">252311</td>
                <td rowspan="1">Dental specialist</td>
                <td rowspan="1">ADC</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">252312</td>
                <td rowspan="1">Dentist</td>
                <td rowspan="1">ADC</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">252411</td>
                <td rowspan="1">Occupational therapist</td>
                <td rowspan="1">OTC</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">252511</td>
                <td rowspan="1">Physiotherapist</td>
                <td rowspan="1">APC</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">252611</td>
                <td rowspan="1">Podiatrist</td>
                <td rowspan="1">ANZPAC</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">252711</td>
                <td rowspan="1">Audiologist</td>
                <td rowspan="1">VETASSESS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">252712</td>
                <td rowspan="1">Speech pathologist</td>
                <td rowspan="1">SPA</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">253111</td>
                <td rowspan="1">General practitioner</td>
                <td rowspan="1">Medical Board of Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">253112</td>
                <td rowspan="1">Resident medical officer</td>
                <td rowspan="1">Medical Board of Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">253211</td>
                <td rowspan="1">Anaesthetist</td>
                <td rowspan="1">Medical Board of Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">253311</td>
                <td rowspan="1">Specialist physician (general medicine)</td>
                <td rowspan="1">Medical Board of Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">253313</td>
                <td rowspan="1">Clinical haematologist</td>
                <td rowspan="1">Medical Board of Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">253314</td>
                <td rowspan="1">Medical oncologist</td>
                <td rowspan="1">Medical Board of Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">253317</td>
                <td rowspan="1">Intensive care specialist</td>
                <td rowspan="1">Medical Board of Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">253321</td>
                <td rowspan="1">Paediatrician</td>
                <td rowspan="1">Medical Board of Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">253324</td>
                <td rowspan="1">Thoracic medicine specialist</td>
                <td rowspan="1">Medical Board of Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">253399</td>
                <td rowspan="1">Specialist physicians <em>nec</em></td>
                <td rowspan="1">Medical Board of Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">253516</td>
                <td rowspan="1">Paediatric surgeon</td>
                <td rowspan="1">Medical Board of Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">253517</td>
                <td rowspan="1">Plastic and reconstructive surgeon</td>
                <td rowspan="1">Medical Board of Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">253912</td>
                <td rowspan="1">Emergency medicine specialist</td>
                <td rowspan="1">Medical Board of Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">253999</td>
                <td rowspan="1">Medical practitioners <em>n</em><em>ec</em></td>
                <td rowspan="1">Medical Board of Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">254111</td>
                <td rowspan="1">Midwife</td>
                <td rowspan="1">ANMAC</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">254211</td>
                <td rowspan="1">Nurse educator</td>
                <td rowspan="1">ANMAC</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">254311</td>
                <td rowspan="1">Nurse manager</td>
                <td rowspan="1">ANMAC</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">254411</td>
                <td rowspan="1">Nurse practitioner</td>
                <td rowspan="1">ANMAC</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">254412</td>
                <td rowspan="1">Registered nurse (aged care)</td>
                <td rowspan="1">ANMAC</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">254413</td>
                <td rowspan="1">Registered nurse (child and family health)</td>
                <td rowspan="1">ANMAC</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">254414</td>
                <td rowspan="1">Registered nurse (community health)</td>
                <td rowspan="1">ANMAC</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">254415</td>
                <td rowspan="1">Registered nurse (critical care and emergency)</td>
                <td rowspan="1">ANMAC</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">254421</td>
                <td rowspan="1">Registered nurse (medical practice)</td>
                <td rowspan="1">ANMAC</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">254422</td>
                <td rowspan="1">Registered nurse (mental health)</td>
                <td rowspan="1">ANMAC</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">254423</td>
                <td rowspan="1">Registered nurse (perioperative)</td>
                <td rowspan="1">ANMAC</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">254424</td>
                <td rowspan="1">Registered nurse (surgical)</td>
                <td rowspan="1">ANMAC</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">262112</td>
                <td rowspan="1">ICT security specialist</td>
                <td rowspan="1">ACS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">263111</td>
                <td rowspan="1">Computer network and systems engineer</td>
                <td rowspan="1">ACS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">263112</td>
                <td rowspan="1">Network administrator</td>
                <td rowspan="1">ACS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">263113</td>
                <td rowspan="1">Network analyst</td>
                <td rowspan="1">ACS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">263311</td>
                <td rowspan="1">Telecommunications engineer</td>
                <td rowspan="1">Engineers Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">263312</td>
                <td rowspan="1">Telecommunications network engineer</td>
                <td rowspan="1">Engineers Australia</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">272112</td>
                <td rowspan="1">Drug and alcohol counsellor</td>
                <td rowspan="1">VETASSESS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">272114</td>
                <td rowspan="1">Rehabilitation counsellor</td>
                <td rowspan="1">VETASSESS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">272311</td>
                <td rowspan="1">Clinical psychologist</td>
                <td rowspan="1">APS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">272399</td>
                <td rowspan="1">Psychologists <em>nec</em></td>
                <td rowspan="1">APS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">272511</td>
                <td rowspan="1">Social worker</td>
                <td rowspan="1">AASW</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td colspan="4" rowspan="1"><strong>Technicians and trades workers </strong></td>
              </tr>
              <tr>
                <td rowspan="1">311211</td>
                <td rowspan="1">Anaesthetic technician</td>
                <td rowspan="1">VETASSESS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">311214</td>
                <td rowspan="1">Operating theatre technician</td>
                <td rowspan="1">VETASSESS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">311215</td>
                <td rowspan="1">Pharmacy technician</td>
                <td rowspan="1">VETASSESS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">311312</td>
                <td rowspan="1">Meat inspector</td>
                <td rowspan="1">VETASSESS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">312113</td>
                <td rowspan="1">Building inspector</td>
                <td rowspan="1">VETASSESS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">312913</td>
                <td rowspan="1">Mine deputy</td>
                <td rowspan="1">VETASSESS</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">323111</td>
                <td rowspan="1">Aircraft maintenance engineer (avionics)</td>
                <td rowspan="1">TRA</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">323112</td>
                <td rowspan="1">Aircraft maintenance engineer (mechanical)</td>
                <td rowspan="1">TRA</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">323113</td>
                <td rowspan="1">Aircraft maintenance engineer (structures)</td>
                <td rowspan="1">TRA</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">323211</td>
                <td rowspan="1">Fitter (general)&nbsp;&ndash;&nbsp;including mechanical fitters and plant mechanics</td>
                <td rowspan="1">TRA</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">342111</td>
                <td rowspan="1">Airconditioning and refrigeration mechanic</td>
                <td rowspan="1">TRA</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">342211</td>
                <td rowspan="1">Electrical linesworker</td>
                <td rowspan="1">TRA</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">342313</td>
                <td rowspan="1">Electronic equipment trades worker</td>
                <td rowspan="1">TRA</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">342412</td>
                <td rowspan="1">Telecommunications cable jointer</td>
                <td rowspan="1">TRA</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">342413</td>
                <td rowspan="1">Telecommunications linesworker</td>
                <td rowspan="1">TRA</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">342414</td>
                <td rowspan="1">Telecommunications technician</td>
                <td rowspan="1">TRA</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">351211</td>
                <td rowspan="1">Butcher or smallgoods maker</td>
                <td rowspan="1">TRA</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <td rowspan="1">351311</td>
                <td rowspan="1">Chef**</td>
                <td rowspan="1">TRA</td>
                <td rowspan="1">Available</td>
              </tr>
              <tr>
                <th colspan="4" rowspan="1"><strong>Community and personal service workers</strong></th>
              </tr>
              <tr>
                <th colspan="1" rowspan="1">451399</th>
                <td rowspan="1">Funeral workers <em>nec</em></td>
                <td rowspan="1">VETASSESS</td>
                <td rowspan="1">Available</td>
              </tr>
            </tbody>
          </table>
          <p>&nbsp;</p>
        </div>
      </div>
      <div class="col-md-4 col-sm-4 col-xs-12">
        <?php include('enquiry-form.php')?>
      </div>
    </div>
  </div>
</div>
</div>
</div>
<?php include 'inc/footer.php'; ?>
