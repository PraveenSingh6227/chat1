<?php include 'inc/header.php'; ?>
<div class="page-area">
    <div class="breadcumb-overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="breadcrumb">
                    <div class="bread-inner">
                        <div class="section-headline white-headline">
                            <h2>Ontario Business  <span class="color"> Immigration Stream</span></h2>
                        </div>
                        <ul class="breadcrumb-bg">
                            <li class="home-bread"><a href="index.php">Home</a></li>
                            <li>Ontario Business Immigration Stream</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="team-area bg-color pd-35">
    <div class="container">
        <!-- section head -->
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-headline text-center">
                    <h3>Ontario Business  <span class="color"> Immigration Stream</span></h3>
                </div>
            </div>
        </div>
        <div class="row">
		 <div class="col-md-8 col-sm-8 col-xs-12" style="box-shadow: 5px 3px 10px rgb(0 0 0 / 10%);">
<div class='text-justify innerpage-text'><p>Craving for gaining entry into the Canadian shores on the basis of business or skills is never going to end for this country offers an unprecedented abundance of opportunities for both the segments. Canada has been in the news, since January 2015, after the announcement of brand new migration initiative called &lsquo;Express Entry&rsquo;; and it has been immensely successful in attracting people through both the federal and provincial migration schemes.</p>
<p>The grand success of the Express Entry can be attributed to equal participation of both the federal and provincial governments in the program. Almost all the states of Canada have joined hands with the federal government and CIC; and have launched full-fledged programs to facilitate inwards migration. Every month one of more states are launching their individual schemes to allow entry of immigrants. One such program New Business Immigration Streams of Ontario has been launched by the state of Ontario.</p>
<p>The Two New <strong>Ontario Business Immigration Streams</strong> that the government of this province has announced include corporate class and the Entrepreneur class. Both of these classifications would work as an integral part of the OOPNP - Opportunities Ontario Provincial Nominee Program; and would enable the government to invite immigrants selected as a part of provincial nomination program.&nbsp;</p>
<p>Both of the Streams of <strong>Ontario Business Immigration</strong> would be targeting immigrants with varying backgrounds and would be carrying distinct sets of rules and requirements. But, one thing is for sure, the programs intend to perpetuate the intentions of the government of the state to create an environment that offers opportunities to the new entrants fit enough to fit into the scheme of things pretty well; and also boosts the economic scenario that has scope for both jobs and business and trade.</p>
<p><br />
<a href="authorized-representative-canada.html" style="padding:7px 5px ;background: #f00 !important; color: #fff; line-height: 24px; border-radius: 5px; margin-bottom: 6px;  width: 140px;" target="_blank" title="Canada Immigration Attorney">Canada Immigration Attorney</a><br />
&nbsp;</p>
<p>Ontario Business Immigration Entrepreneur Stream would render all possible assistance to the immigrants in establishing a new business venture or procuring an existing set-up in the state. The people intending to move in on the basis of this scheme would probably need to evidence practicality of the business proposals that the commercial activities being setup by them would prove to be of an immense benefit for the economy of the state.</p>
<p>An endorsement from the state government would allow the applicants to obtain a provisional residence permit of the country. The provisional entry permit would enable the alien business owners to establish their businesses in the state&nbsp;upon achievement of which the applicants would be granted endorsement for the permanent residency of Canada by the state authorities.</p>
<p>The authorities of the state have although not yet declared the eligibility criteria of OINP, initial impressions about the qualification parameters suggest that the immigrants would be required to adhere to the following parameters:</p>
<ul style="box-sizing: border-box; margin-top: 0px; margin-bottom: 10px; font-family: Roboto, Arial, Helvetica, sans-serif; font-size: 15px; text-align: justify;">
<li style="box-sizing: border-box;"><em style="box-sizing: border-box;">The investing individuals would be allowed to choose one partner for PNP endorsement for setting up commercial venture in the state;</em></li>
<li style="box-sizing: border-box;"><em style="box-sizing: border-box;">The personal net&nbsp; asset value of the applicants would have to be in tune of CAD $800,000; and</em></li>
<li style="box-sizing: border-box;"><em style="box-sizing: border-box;">The applicant would be given 2 years to establish a commercial concern, in which they would have to provide full-time employment to at least 2 Canadian nationals or permanent residents.</em></li>
</ul>
<p><br />Ontario Business Immigration Corporate Stream has been designed to assist foreign MNCs seeking opportunities of setting their foot on the Canadian soil by way of either expanding their direct operations or by acquiring already operational concerns. The businesses established afresh or acquired would have to generate full time employment for minimum of five Canadian nationals or permanent residents.</p>
<p>The investment parameters of&nbsp;Two New Ontario Business Immigration Streams&nbsp;mandate an infusion of a minimum of CAD $500,000 into a venture.</p>
<p><strong>Check Your Eligibility for Canada Immigration for FREE and get free assessment report on your email. <a href="../check-your-eligibility.html" target="_blank">Click Here</a></strong></p>
<p>&nbsp;</p>
<table border="1" height="175" style="box-sizing: border-box; border-spacing: 0px; border-collapse: collapse; width: 750px; font-family: Roboto, Arial, Helvetica, sans-serif; font-size: 15px; text-align: justify; margin-bottom: 20px !important;" summary="How are the new business streams different from the investor component?" width="100%">
<thead style="box-sizing: border-box;">
<tr style="box-sizing: border-box;">
<th align="center" scope="col" style="box-sizing: border-box; padding: 10px; text-align: left; background: rgb(255, 0, 0); color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); font-weight: normal;" valign="top" width="auto"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">Criteria &amp; Process</span></em></th>
<th align="center" scope="col" style="box-sizing: border-box; padding: 10px; text-align: left; background: rgb(255, 0, 0); color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); font-weight: normal;" valign="top" width="auto"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">Old Investor Component</span>(CLOSED &ndash; Applications will no longer be accepted on or after October 29, 2015 )</em></th>
<th align="center" scope="col" style="box-sizing: border-box; padding: 10px; text-align: left; background: rgb(255, 0, 0); color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); font-weight: normal;" valign="top" width="auto"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">NEW Corporate Stream</span>(Accepting applications fall 2015)</em></th>
<th align="center" scope="col" style="box-sizing: border-box; padding: 10px; text-align: left; background: rgb(255, 0, 0); color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); font-weight: normal;" valign="top" width="auto"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">NEW Entrepreneur Stream</span>(Accepting applications fall 2015)</em></th>
</tr>
</thead>
<tbody style="box-sizing: border-box;">
<tr style="box-sizing: border-box;">
<th align="center" colspan="4" scope="colgroup" style="box-sizing: border-box; padding: 10px; text-align: left; background: rgb(255, 0, 0); color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); font-weight: normal;" valign="top"><em style="box-sizing: border-box;">Section 1: Eligibility Criteria</em></th>
</tr>
</tbody>
<tbody id="element1" style="box-sizing: border-box;">
<tr style="box-sizing: border-box;">
<th align="center" height="auto" scope="row" style="box-sizing: border-box; padding: 10px; text-align: left; background: rgb(255, 0, 0); color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); font-weight: normal;" valign="top"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">Profile of Potential Applicant</span></em></th>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top">
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;">Foreign corporations/individual investors</em></p>
</td>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top">
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;">Established foreign corporations</em></p>
</td>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top"><em style="box-sizing: border-box;">Experienced entrepreneurs</em></td>
</tr>
<tr style="box-sizing: border-box;">
<th align="center" scope="row" style="box-sizing: border-box; padding: 10px; text-align: left; background: rgb(255, 0, 0); color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); font-weight: normal;" valign="top"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">Net Worth</span></em></th>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top">
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;">Not applicable to corporations</em></p>
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;">Not required for individual investors</em></p>
</td>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top">
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;">Not applicable to corporations</em></p>
</td>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top">
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">$800,000 to $1.5 million</span>depending on location and sector of the business</em></p>
</td>
</tr>
<tr style="box-sizing: border-box;">
<th align="center" scope="row" style="box-sizing: border-box; padding: 10px; text-align: left; background: rgb(255, 0, 0); color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); font-weight: normal;" valign="top"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">Previous business experience</span></em></th>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top">
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;">Not required for corporations or individual investors</em></p>
</td>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top"><em style="box-sizing: border-box;">Established corporation must have a track record of at least&nbsp;<span style="box-sizing: border-box; font-weight: 700;">3 years</span></em></td>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">3 years</span>&nbsp;of business owner or senior management experience in the last 5 years</em></td>
</tr>
<tr style="box-sizing: border-box;">
<th align="center" scope="row" style="box-sizing: border-box; padding: 10px; text-align: left; background: rgb(255, 0, 0); color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); font-weight: normal;" valign="top"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">Prospective Nominees</span></em></th>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top">
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;">Up to&nbsp;<span style="box-sizing: border-box; font-weight: 700;">25</span>&nbsp;key staff</em></p>
</td>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top"><em style="box-sizing: border-box;">Up to&nbsp;<span style="box-sizing: border-box; font-weight: 700;">5</span>&nbsp;key staff</em></td>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top">
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;">Up to&nbsp;<span style="box-sizing: border-box; font-weight: 700;">2</span>&nbsp;nominees &ndash; (Entrepreneur&nbsp;<span style="box-sizing: border-box; font-weight: 700;">plus 1</span>&nbsp;business partner<a href="ontario-business-immigratio-stream.html" style="box-sizing: border-box; background-color: transparent; color: rgb(255, 0, 0); text-decoration-line: none;">*</a>)</em></p>
</td>
</tr>
<tr style="box-sizing: border-box;">
<th align="center" scope="row" style="box-sizing: border-box; padding: 10px; text-align: left; background: rgb(255, 0, 0); color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); font-weight: normal;" valign="top"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">Language Requirement</span></em></th>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top">
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;">Not required for key staff</em></p>
</td>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">Canadian Language Benchmark 5</span>&nbsp;at time of nomination<a href="ontario-business-immigratio-stream.html" style="box-sizing: border-box; background-color: transparent; color: rgb(255, 0, 0); text-decoration-line: none;">**</a></em></td>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top">
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">Canadian Language Benchmark 5</span>&nbsp;at time of nomination<a href="ontario-business-immigratio-stream.html" style="box-sizing: border-box; background-color: transparent; color: rgb(255, 0, 0); text-decoration-line: none;">**</a></em></p>
</td>
</tr>
<tr style="box-sizing: border-box;">
<th align="center" scope="row" style="box-sizing: border-box; padding: 10px; text-align: left; background: rgb(255, 0, 0); color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); font-weight: normal;" valign="top"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">Previous work experience</span></em></th>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top">
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;">Key staff must have two years of relevant work experience in the last five years</em></p>
</td>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top"><em style="box-sizing: border-box;">Key staff must have&nbsp;<span style="box-sizing: border-box; font-weight: 700;">3 years</span>&nbsp;of work experience in the intended occupation with the corporation within the last 5 years</em></td>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top">
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">3 years</span>&nbsp;of business owner or senior management experience in the last 5 years</em></p>
</td>
</tr>
<tr style="box-sizing: border-box;">
<th align="center" scope="row" style="box-sizing: border-box; padding: 10px; text-align: left; background: rgb(255, 0, 0); color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); font-weight: normal;" valign="top"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">Nominee Occupational Categories</span></em></th>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top"><em style="box-sizing: border-box;">NOC A, B or 0</em></td>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top">
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;">NOC A or 0 (Labour Market Impact Assessment required for NOC A occupations)</em></p>
</td>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top"><em style="box-sizing: border-box;">See previous work experience requirements</em></td>
</tr>
<tr style="box-sizing: border-box;">
<th align="center" scope="row" style="box-sizing: border-box; padding: 10px; text-align: left; background: rgb(255, 0, 0); color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); font-weight: normal;" valign="top"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">Familial or financial relationship</span></em></th>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top"><em style="box-sizing: border-box;">Not applicable</em></td>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top"><em style="box-sizing: border-box;">No familial or financial relationship between key staff and corporation</em></td>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top"><em style="box-sizing: border-box;">Not applicable</em></td>
</tr>
<tr style="box-sizing: border-box;">
<th align="center" scope="row" style="box-sizing: border-box; padding: 10px; text-align: left; background: rgb(255, 0, 0); color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); font-weight: normal;" valign="top"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">Other nominee criteria</span></em></th>
<td align="left" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top">
<p style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;">For corporate applicants, key staff:</em></p>
<ul style="box-sizing: border-box; margin-top: 0px; margin-bottom: 10px;">
<li style="box-sizing: border-box;"><em style="box-sizing: border-box;">must be necessary for the long-term success of the investment; and</em></li>
<li style="box-sizing: border-box;"><em style="box-sizing: border-box;">must be in Canada on a permanent full-time basis and paid prevailing wage rate</em></li>
</ul>
<p style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;">Individual investors must be involved in the active and ongoing management of the business.</em></p>
</td>
<td align="left" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top">
<p style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;">Key staff:</em></p>
<ul style="box-sizing: border-box; margin-top: 0px; margin-bottom: 10px;">
<li style="box-sizing: border-box;"><em style="box-sizing: border-box;">must be in Canada on a permanent full-time basis and paid prevailing wage rate; and</em></li>
</ul>
<em style="box-sizing: border-box;">must occupy a position in a senior executive, managerial or specialized knowledge capacity</em></td>
<td align="left" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top"><em style="box-sizing: border-box;">Must be involved in the active and ongoing management of the business</em></td>
</tr>
</tbody>
<tbody style="box-sizing: border-box;">
<tr style="box-sizing: border-box;">
<th align="center" colspan="4" scope="colgroup" style="box-sizing: border-box; padding: 10px; text-align: left; background: rgb(255, 0, 0); color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); font-weight: normal;" valign="top"><em style="box-sizing: border-box;">Section 2: Investment Commitments</em></th>
</tr>
</tbody>
<tbody id="element2" style="box-sizing: border-box;">
<tr style="box-sizing: border-box;">
<th align="center" scope="row" style="box-sizing: border-box; padding: 10px; text-align: left; background: rgb(255, 0, 0); color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); font-weight: normal;" valign="top"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">Minimum Investment</span></em></th>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">$3 million</span></em></td>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top">
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">$5 million</span></em></p>
</td>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top">
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">$500k to $1 million</span>&nbsp;depending on location and sector of the business andcontrol at least&nbsp;<span style="box-sizing: border-box; font-weight: 700;">33.3%</span>&nbsp;of the equity in the business</em></p>
</td>
</tr>
<tr style="box-sizing: border-box;">
<th align="center" scope="row" style="box-sizing: border-box; padding: 10px; text-align: left; background: rgb(255, 0, 0); color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); font-weight: normal;" valign="top"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">Job Creation</span></em></th>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top">
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;">5 net new jobs for Canadian citizens/permanent residents for first nominee position; 1 net new job for a Canadian citizen/permanent resident per additional nominee position</em></p>
</td>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top">
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">5</span>&nbsp;net new jobs for Canadian citizens/permanent residents per key staff</em></p>
</td>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top">
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">2</span>&nbsp;net new jobs for Canadian citizens/permanent residents</em></p>
</td>
</tr>
</tbody>
<tbody style="box-sizing: border-box;">
<tr style="box-sizing: border-box;">
<th align="center" colspan="4" scope="colgroup" style="box-sizing: border-box; padding: 10px; text-align: left; background: rgb(255, 0, 0); color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); font-weight: normal;" valign="top"><em style="box-sizing: border-box;">Section 3: Application Assessment</em></th>
</tr>
</tbody>
<tbody id="element3" style="box-sizing: border-box;">
<tr style="box-sizing: border-box;">
<th align="center" scope="row" style="box-sizing: border-box; padding: 10px; text-align: left; background: rgb(255, 0, 0); color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); font-weight: normal;" valign="top"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">Business Plan</span></em></th>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top">
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;">Evaluated for endorsement by assessing ministry</em></p>
</td>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top"><em style="box-sizing: border-box;">Viability of business plan assessed by OINP</em></td>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top"><em style="box-sizing: border-box;">Viability of business plan assessed by OINP</em></td>
</tr>
<tr style="box-sizing: border-box;">
<th align="center" style="box-sizing: border-box; padding: 10px; text-align: left; background: rgb(255, 0, 0); color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); font-weight: normal;" valign="top">
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">Third-Party Verification of business plan viability, source of funds and net worth</span></em></p>
</th>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top">
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;">Not applicable</em></p>
</td>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top"><em style="box-sizing: border-box;">May be conducted if required by OINP</em></td>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top">
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;">May be conducted if required by OINP</em></p>
</td>
</tr>
<tr style="box-sizing: border-box;">
<th align="center" scope="row" style="box-sizing: border-box; padding: 10px; text-align: left; background: rgb(255, 0, 0); color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); font-weight: normal;" valign="top"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">In-Person Interviews</span></em></th>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top">
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;">Not mandatory</em></p>
</td>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top">
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">Mandatory&nbsp;</span>with corporation Chief Executive Officer and key staff seeking nomination</em></p>
</td>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">Mandatory&nbsp;</span>with Entrepreneur and business partner (if applicable)</em></td>
</tr>
<tr style="box-sizing: border-box;">
<th align="center" scope="row" style="box-sizing: border-box; padding: 10px; text-align: left; background: rgb(255, 0, 0); color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); font-weight: normal;" valign="top">
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">Performance Agreements</span></em></p>
</th>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top">
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;">Not required</em></p>
</td>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top">
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">Required</span>&nbsp;- Outlines investment and job creation commitments to be met within two years</em></p>
</td>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top">
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">Required</span>&nbsp;- Outlines investment and job creation commitments to be met within two years</em></p>
</td>
</tr>
</tbody>
<tbody style="box-sizing: border-box;">
<tr style="box-sizing: border-box;">
<th align="center" colspan="4" scope="colgroup" style="box-sizing: border-box; padding: 10px; text-align: left; background: rgb(255, 0, 0); color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); font-weight: normal;" valign="top"><em style="box-sizing: border-box;">Section 4: Nomination Process</em></th>
</tr>
</tbody>
<tbody id="element4" style="box-sizing: border-box;">
<tr style="box-sizing: border-box;">
<th align="center" scope="row" style="box-sizing: border-box; padding: 10px; text-align: left; background: rgb(255, 0, 0); color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); font-weight: normal;" valign="top">
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">Nomination Process</span></em></p>
</th>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top">
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;">Approved key staff are nominated for permanent residence</em></p>
</td>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top">
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">Two-step nomination process (temporary to permanent residence):</span></em></p>
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">Step 1</span>: Key staff of corporations are provided temporary work permit support letters to apply for work permits to establish the business in Ontario</em></p>
<em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">Step 2</span>: Key staff of corporations are nominated for permanent residence once investment and job creation commitments outlined in the performance agreement are met within two years</em></td>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top">
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">Two-step nomination process (temporary to permanent residence):</span></em></p>
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">Step 1</span>: Entrepreneur and additional business partner (if applicable) are provided temporary work permit support letters to apply for work permits to establish the business in Ontario</em></p>
<em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">Step 2</span>: Entrepreneur and additional business partner (if applicable) are nominated for permanent residence once investment and job creation commitments outlined in the performance agreement are met within two years</em></td>
</tr>
</tbody>
<tbody style="box-sizing: border-box;">
<tr style="box-sizing: border-box;">
<th align="center" colspan="4" scope="colgroup" style="box-sizing: border-box; padding: 10px; text-align: left; background: rgb(255, 0, 0); color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); font-weight: normal;" valign="top"><em style="box-sizing: border-box;">Section 5: Other</em></th>
</tr>
</tbody>
<tbody id="element5" style="box-sizing: border-box;">
<tr style="box-sizing: border-box;">
<th align="center" scope="row" style="box-sizing: border-box; padding: 10px; text-align: left; background: rgb(255, 0, 0); color: rgb(255, 255, 255); border: 1px solid rgb(204, 204, 204); font-weight: normal;" valign="top"><em style="box-sizing: border-box;"><span style="box-sizing: border-box; font-weight: 700;">Exploratory Visits</span></em></th>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top">
<p align="center" style="box-sizing: border-box; margin: 0px 0px 10px;"><em style="box-sizing: border-box;">Not required</em></p>
</td>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top"><em style="box-sizing: border-box;">Recommended</em></td>
<td align="center" style="box-sizing: border-box; padding: 10px; border: 1px solid rgb(204, 204, 204); width: auto !important;" valign="top"><em style="box-sizing: border-box;">Recommended</em></td>
</tr>
</tbody>
</table>
</div>
</div>
		 <div class="col-md-4 col-sm-4 col-xs-12">
		 <?php include('enquiry-form.php')?>
		 </div>
                
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>