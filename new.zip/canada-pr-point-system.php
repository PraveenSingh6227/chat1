<?php include 'inc/header.php'; ?>
<div class="page-area">
    <div class="breadcumb-overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="breadcrumb">
                    <div class="bread-inner">
                        <div class="section-headline white-headline">
                            <h2>Canada PR Immigration   <span class="color"> Point System </span></h2>
                        </div>
                        <ul class="breadcrumb-bg">
                             <li class="home-bread"><a href="index.php">Home</a></li>
                            <li>Canada PR Immigration Point System </li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="team-area bg-color pd-35">
    <div class="container">
        <!-- section head -->
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-headline text-center">
                    <h3> Canada PR Immigration   <span class="color"> Point System </span></h3>
                </div>
            </div>
        </div>
        <div class="row">
		 <div class="col-md-8 col-sm-8 col-xs-12" style="box-shadow: 5px 3px 10px rgb(0 0 0 / 10%);">
            <div class='text-justify innerpage-text'>
			<p>Canada is one of the first countries to introduce a points-based immigration system, way back in 1967. In order to be eligible for permanent residency in Canada, the applicant must hold a good score based on the<strong> </strong>Canada PR Points Calculator<strong>. </strong>Also, known as the&nbsp;<a href="canada-immigration/express-entry-comprehensive-ranking-system-criteria.php" target="_blank"><strong>Comprehensive Ranking System</strong></a> (CRS). The Express Entry Points are used to assess and score your profile and rank it in the Express Entry pool. Skills, educational qualifications, proficiency in Language, work experience and other factors are some of the parameters, of your CRS scoring.<br />
<br />
A defining factor of your CRS score is the&nbsp;Canada Immigration Points for IELTS, that you can score with practice, online IELTS coaching or Practice tests. Your score on the IELTS platform elevates your initial score to an entirely new level. To qualify for Canada Immigration, you must be able to secure a score of 67 points. Under the <a href="canada-immigration/canada-express-entry.php" target="_blank"><strong>Express Entry Program</strong></a>, you will be able to access your profile for <a href="canada-immigration.php" target="_blank"><strong>Canada Immigration</strong></a>. Your&nbsp;Express Entry Points&nbsp;will determine your ranking within the pool. The higher the score, more are the chanced of receiving an Invitation to Apply from the Immigration, Refugees and Citizenship Canada (IRCC).<br />
&nbsp;</p>
<h4 class="text-center">Calculate Your Points Now</h4>
<table class="datatable points-table-form">
<tbody>
<tr>
<td class="td"><span>Your Name</span><br />
<input class="txtb form-control" id="txt_your_name" onblur="if (!window.__cfRLUnblockHandlers) return false; validateFormthis()" type="text" data-cf-modified-f20ce70653a5b7027a3f6a59-="" />
<div id="txt_name_error_msg" style="display:none">&nbsp;</div>
</td>
</tr>
<tr>
<td class="td"><span>Your Email ID</span><br />
<input class="txtb form-control" id="txt_email" name="email" onblur="if (!window.__cfRLUnblockHandlers) return false; validateEmail12(this.value);" type="text" data-cf-modified-f20ce70653a5b7027a3f6a59-="" />
<div id="txt_email_error_msg" style="display:none">&nbsp;</div>
</td>
</tr>
<tr>
<td class="td"><span>Your City</span><br />
<input class="txtb form-control" id="txt_city" onblur="if (!window.__cfRLUnblockHandlers) return false; validateFormCity(this.value)" type="text" data-cf-modified-f20ce70653a5b7027a3f6a59-="" />
<div id="txt_city_error_msg" style="display:none">&nbsp;</div>
</td>
</tr>
<tr>
<td class="td"><span>Your Phone No.</span><br />
<input class="txtb form-control" id="txt_phone_no" onblur="if (!window.__cfRLUnblockHandlers) return false; validateFormPhone()" type="text" data-cf-modified-f20ce70653a5b7027a3f6a59-="" />
<div id="txt_phone_error_msg" style="display:none">&nbsp;</div>
</td>
</tr>
<tr>
<td class="td"><span>Please Select Your Age</span><br />
<select class="txtdd form-control" id="ddl_age" onchange="if (!window.__cfRLUnblockHandlers) return false; show_ddl_age()" data-cf-modified-f20ce70653a5b7027a3f6a59-=""><option value="0">SELECT</option><option value="1">18 to 35</option><option value="2">36</option><option value="3">37</option><option value="4">38</option><option value="5">39</option><option value="6">40</option><option value="7">41</option><option value="8">42</option><option value="9">43</option><option value="10">44</option><option value="11">45</option><option value="12">46</option><option value="13">47 and more</option> </select> &nbsp;</td>
</tr>
<tr id="tr_English" style="display:none">
<td class="td">Please Select IELTS / English Proficiency<br />
<select class="txtdd form-control" id="ddl_English" onchange="if (!window.__cfRLUnblockHandlers) return false; show_ddl_English()" data-cf-modified-f20ce70653a5b7027a3f6a59-=""><option value="0">Select</option><option value="1">IELTS</option><option value="2">No Knowledge of English</option> </select></td>
</tr>
<tr id="tr_speaking" style="display:none">
<td class="td">Speaking:<br />
<select class="txtdd form-control" id="dll_speaking" onchange="if (!window.__cfRLUnblockHandlers) return false; show_ddl_speaking()" data-cf-modified-f20ce70653a5b7027a3f6a59-=""><option value="0">Select</option><option value="1">6.0 (Good)</option><option value="2">6.5 (Very Good)</option><option value="3">7.0 &ndash; 9.0 (Expert)</option> </select></td>
</tr>
<tr id="tr_Listening" style="display:none">
<td class="td">Listening:<br />
<select class="txtdd form-control" id="dll_Listening" onchange="if (!window.__cfRLUnblockHandlers) return false; show_ddl_speaking()" data-cf-modified-f20ce70653a5b7027a3f6a59-=""><option value="0">Select</option><option value="1">6.0 &ndash; 7.0 (Good)</option><option value="2">7.5 (Very Good)</option><option value="3">8.0 &ndash; 9.0 (Expert)</option> </select></td>
</tr>
<tr id="tr_Reading" style="display:none">
<td class="td">Reading:<br />
<select class="txtdd form-control" id="dll_Reading" onchange="if (!window.__cfRLUnblockHandlers) return false; show_ddl_speaking()" data-cf-modified-f20ce70653a5b7027a3f6a59-=""><option value="0">Select</option><option value="1">6.0 (Good)</option><option value="2">6.5 (Very Good)</option><option value="3">7.0 &ndash; 9.0 (Expert)</option> </select></td>
</tr>
<tr id="tr_Writing" style="display:none">
<td class="td">Writing:<br />
<select class="txtdd form-control" id="dll_Writing" onchange="if (!window.__cfRLUnblockHandlers) return false; show_ddl_speaking()" data-cf-modified-f20ce70653a5b7027a3f6a59-=""><option value="0">Select</option><option value="1">6.0 &ndash; 7.0 (Good)</option><option value="2">6.5 (Very Good)</option><option value="3">7.0 &ndash; 9.0 (Expert)</option> </select></td>
</tr>
<tr id="tr_qualification" style="display: none;">
<td class="td">Please Select Your Highest Qualification<br />
<select class="txtdd form-control" id="ddl_Qualification" onchange="if (!window.__cfRLUnblockHandlers) return false; show_ddl_Qualification()" style="width:100%; height:auto;" data-cf-modified-f20ce70653a5b7027a3f6a59-=""><option value="0">SELECT</option><option value="1">Doctoral level</option><option value="2">Master&rsquo;s level or professional degree</option><option style="width:100%; height:auto;" value="3">Two or more post-secondary credentials, one of which is a three-year or longer post-secondary credential</option><option value="4">Three-year or longer post-secondary credential</option><option value="5">Two-year post-secondary credential</option><option value="6">One-year post-secondary credential</option><option value="7">Secondary school</option><option value="8">Secondary school not completed</option> </select> &nbsp;</td>
</tr>
<tr id="tr_experience" style="display: none">
<td class="td">Your total work experience<br />
<select class="txtdd form-control" id="ddl_experience" onchange="if (!window.__cfRLUnblockHandlers) return false; show_ddl_experience()" data-cf-modified-f20ce70653a5b7027a3f6a59-=""><option value="0">SELECT</option><option value="1">Six years or more</option><option value="2">Four years</option><option value="3">Two years</option><option value="4">One years</option><option value="5">No Work Experience</option> </select> &nbsp;</td>
</tr>
<tr id="tr_ArrangedEmployment" style="display: none">
<td class="td">Arranged Employment<br />
<select class="txtdd form-control" id="dll_ArrangedEmployment" onchange="if (!window.__cfRLUnblockHandlers) return false; show_dll_ArrangedEmployment()" style="width:100%;" data-cf-modified-f20ce70653a5b7027a3f6a59-=""><option value="0">SELECT</option><option value="1">You have a permanent job offer from a Canadian employer, approved by the HRSDC</option><option style="width:100%;" value="2">You have a permanent job offer from a Canadian employer, without the necessity of HRSDC approval, if you are employed in Canada by the same employer</option><option value="3">Not Applicable</option> </select> &nbsp;</td>
</tr>
<tr id="tr_Adaptability" style="display: none">
<td class="td">Please Select Adaptability<br />
<select class="txtdd form-control" id="ddl_Adaptability" onchange="if (!window.__cfRLUnblockHandlers) return false; show_ddl_Adaptability()" style="width:100%;" data-cf-modified-f20ce70653a5b7027a3f6a59-=""><option value="0">SELECT</option><option value="1">Principal Applicant Previous Work in Canada (min. 1 yr at NOC 0, A, B)</option><option value="2">Accompanying Spouse/Partner Previous Work in Canada</option><option value="3">Principal Applicant Previous Study in Canada</option><option value="4">Accompanying Spouse/Partner Previous Study in Canada</option><option value="5">Arranged Employment</option><option style="width:100%;" value="6">Relative in Canada 18 years or over (parent, grandparent, child, grandchild, child of a parent, sibling, child of a grandparent, aunt or uncle, or grandchild of a parent, niece or nephew) who is residing in Canada and is a Canadian citizen or permanent resident.</option><option value="7">Accompanying spouse/partner&rsquo;s official language (CLB/NCLC 4)</option><option value="8">Not Applicable</option> </select> &nbsp;</td>
</tr>
<tr>
<td class="td"><input class="button" disabled="disabled" id="btn_show" onclick="if (!window.__cfRLUnblockHandlers) return false; show_btn_clickme(); return false;" type="button" value="SHOW POINTS" data-cf-modified-f20ce70653a5b7027a3f6a59-="" /></td>
</tr>
<tr id="tr_msg_show" style="display: none">
<td class="td">
<div>
<h1 id="sn_msg_show">&nbsp;</h1>
<div id="div_msg_age">&nbsp;</div>
&nbsp;
<div id="div_msg_qualification">&nbsp;</div>
&nbsp;
<div id="div_msg_experience">&nbsp;</div>
 &nbsp;
<div id="div_msg_ArrangedEmployment">&nbsp;</div>
&nbsp;
<div id="div_msg_Adaptability">&nbsp;</div>
&nbsp;
<div id="div_msg_speaking" style="display:none">&nbsp;</div>
&nbsp;
<div id="div_msg_listening" style="display:none">&nbsp;</div>
&nbsp;
<div id="div_msg_reading" style="display:none">&nbsp;</div>
&nbsp;
<div id="div_msg_writing" style="display:none">&nbsp;</div>
&nbsp;
<div>For in depth analysis of your profile kindly <a href="contact.php" target="_blank">upload your CV</a> and our experts will guide you.</div>
<br />
&nbsp;</div>
</td>
</tr>
</tbody>
</table>

<p>&nbsp;</p>
<p><br />
To check your eligibility for Canada Immigration you can use this table which is a very handy tool to give you a glance at <strong><a href="canada-visa.php" target="_blank">Canada PR</a></strong> Point System, and you can self evaluate your profile for Canada Immigration under Express Entry Program. To qualify for the same you need to score at least <strong>67 points</strong> based on the following point&nbsp;system.<br />
&nbsp;</p>
<table border="1" cellpadding="10" cellspacing="0" width="90%">
<tbody>
<tr bgcolor="#F00" style="color:#FFF">
<td valign="top" width="33%"><span style="color:#FFFFFF;"><strong>Factor</strong></span></td>
<td valign="top" width="56%"><span style="color:#FFFFFF;"><strong>Description</strong></span></td>
<td valign="top" width="11%"><span style="color:#FFFFFF;"><strong>Points</strong></span></td>
</tr>
<tr>
<td rowspan="13" valign="top" width="19%"><strong>Age</strong></td>
<td valign="top" width="66%">18 - 35</td>
<td valign="top">12 points</td>
</tr>
<tr>
<td valign="top" width="66%">36</td>
<td valign="top">11 points</td>
</tr>
<tr>
<td valign="top" width="66%">37</td>
<td valign="top">10 points</td>
</tr>
<tr>
<td valign="top" width="66%">38</td>
<td valign="top">09 points</td>
</tr>
<tr>
<td valign="top" width="66%">39</td>
<td valign="top">08 points</td>
</tr>
<tr>
<td valign="top" width="66%">40</td>
<td valign="top">07 points</td>
</tr>
<tr>
<td valign="top" width="66%">41</td>
<td valign="top">06 points</td>
</tr>
<tr>
<td valign="top" width="66%">42</td>
<td valign="top">05 points</td>
</tr>
<tr>
<td valign="top" width="66%">43</td>
<td valign="top">04 points</td>
</tr>
<tr>
<td valign="top" width="66%">44</td>
<td valign="top">03 points</td>
</tr>
<tr>
<td valign="top" width="66%">45</td>
<td valign="top">02 points</td>
</tr>
<tr>
<td valign="top" width="66%">46</td>
<td valign="top">01 points</td>
</tr>
<tr>
<td valign="top" width="66%">47 &amp; Above</td>
<td valign="top">00 points</td>
</tr>
<tr>
<td valign="top" width="19%"><strong>English language</strong></td>
<td colspan="2" valign="top" width="66%">IELTS:- &nbsp;
<table border="1" cellpadding="5" cellspacing="0" width="100%">
<tbody>
<tr>
<td width="24%">&nbsp;</td>
<td width="12%">
<div align="center">R</div>
</td>
<td width="13%">
<div align="center">S</div>
</td>
<td width="12%">
<div align="center">W</div>
</td>
<td width="13%">
<div align="center">L</div>
</td>
<td width="5%">&nbsp;</td>
<td width="21%">&nbsp;</td>
</tr>
<tr>
<td>Bands-</td>
<td>
<div align="center">6</div>
</td>
<td>
<div align="center">6</div>
</td>
<td>
<div align="center">6</div>
</td>
<td>
<div align="center">6 to 7</div>
</td>
<td>=</td>
<td>CLB7</td>
</tr>
<tr>
<td>Points-</td>
<td>
<div align="center">4</div>
</td>
<td>
<div align="center">4</div>
</td>
<td>
<div align="center">4</div>
</td>
<td>
<div align="center">4</div>
</td>
<td>=</td>
<td>16 Points</td>
</tr>
<tr>
<td>Bands-</td>
<td>
<div align="center">6.5</div>
</td>
<td>
<div align="center">6.5</div>
</td>
<td>
<div align="center">6.5</div>
</td>
<td>
<div align="center">7.5</div>
</td>
<td>=</td>
<td>CLB8</td>
</tr>
<tr>
<td>Points-</td>
<td>
<div align="center">5</div>
</td>
<td>
<div align="center">5</div>
</td>
<td>
<div align="center">5</div>
</td>
<td>
<div align="center">5</div>
</td>
<td>=</td>
<td>20 Points</td>
</tr>
<tr>
<td>Bands-</td>
<td>
<div align="center">7 - 7.5</div>
</td>
<td>
<div align="center">7</div>
</td>
<td>
<div align="center">7</div>
</td>
<td>
<div align="center">8</div>
</td>
<td>=</td>
<td>CLB9</td>
</tr>
<tr>
<td>Points-</td>
<td>
<div align="center">6</div>
</td>
<td>
<div align="center">6</div>
</td>
<td>
<div align="center">6</div>
</td>
<td>
<div align="center">6</div>
</td>
<td>=</td>
<td>24 Points</td>
</tr>
<tr>
<td>Bands-</td>
<td>
<div align="center">8 - 9</div>
</td>
<td>
<div align="center">7.5-9</div>
</td>
<td>
<div align="center">7.5 - 9</div>
</td>
<td>
<div align="center">8.5 - 9</div>
</td>
<td>=</td>
<td>CLB10</td>
</tr>
<tr>
<td>Points-</td>
<td>
<div align="center">6</div>
</td>
<td>
<div align="center">6</div>
</td>
<td>
<div align="center">6</div>
</td>
<td>
<div align="center">6</div>
</td>
<td>=</td>
<td>24 Points</td>
</tr>
</tbody>
</table>
</td>
</tr>
<tr>
<td rowspan="3" valign="top" width="19%">&nbsp;<strong> Qualfication</strong></td>
<td valign="top" width="66%">&nbsp; PHD</td>
<td valign="top">&nbsp; 25 Points</td>
</tr>
<tr>
<td valign="top" width="66%">Master degree</td>
<td valign="top">23 Points</td>
</tr>
<tr>
<td valign="top" width="66%">Double Bachelor</td>
<td valign="top">22 Points</td>
</tr>
<tr>
<td rowspan="3" valign="top" width="19%">&nbsp;</td>
<td valign="top" width="66%">Bachelor degree</td>
<td valign="top">21 Points</td>
</tr>
<tr>
<td valign="top" width="66%">Diploma 3 Years after Higher Secondary</td>
<td valign="top">19 points</td>
</tr>
<tr>
<td valign="top" width="66%">Diploma 3 Years after 10th (High School)</td>
<td valign="top">15 Points</td>
</tr>
<tr>
<td valign="top" width="19%">&nbsp;</td>
<td valign="top" width="66%">High School</td>
<td valign="top">05 Points</td>
</tr>
<tr>
<td valign="top" width="19%"><strong>Work Experience</strong></td>
<td valign="top" width="66%">1 Year</td>
<td valign="top">09 Points</td>
</tr>
<tr>
<td valign="top" width="19%">&nbsp;</td>
<td valign="top" width="66%">2 - 3 Years</td>
<td valign="top">11 Points</td>
</tr>
<tr>
<td valign="top" width="19%">&nbsp;</td>
<td valign="top" width="66%">4 - 5 Years</td>
<td valign="top">13 Points</td>
</tr>
<tr>
<td valign="top" width="19%">&nbsp;</td>
<td valign="top" width="66%">6 &amp; Above</td>
<td valign="top">15 Points</td>
</tr>
<tr>
<td valign="top" width="19%"><strong>Spouse/ Adaptability</strong></td>
<td valign="top" width="66%">Spouse IELTS</td>
<td valign="top">05 Points</td>
</tr>
<tr>
<td valign="top" width="19%">&nbsp;</td>
<td valign="top" width="66%">Blood Relation</td>
<td valign="top">05 Points</td>
</tr>
</tbody>
</table>
<p>&nbsp;</p>
        </div>
         </div>
		 <div class="col-md-4 col-sm-4 col-xs-12">
		 <?php include('enquiry-form.php')?>
		 </div>
                
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>