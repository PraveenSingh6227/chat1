<?php include 'inc/header.php'; ?>
<div class="page-area">
    <div class="breadcumb-overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="breadcrumb">
                    <div class="bread-inner">
                        <div class="section-headline white-headline">
                            <h2>Comprehensive Ranking System <span class="color"> CRS Calculator</span></h2>
                        </div>
                        <ul class="breadcrumb-bg">
                             <li class="home-bread"><a href="index.php">Home</a></li>
                            <li>Comprehensive Ranking System | CRS Calculator</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="team-area bg-color pd-35">
    <div class="container">
        <!-- section head -->
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-headline text-center">
                    <h3> Comprehensive Ranking System  <span class="color"> CRS Calculator</span></h3>
                </div>
            </div>
        </div>
        <div class="row">
		 <div class="col-md-8 col-sm-8 col-xs-12" style="box-shadow: 5px 3px 10px rgb(0 0 0 / 10%);">
		  <h2>Canada Express Entry &ndash; Comprehensive Ranking System</h2>
            <div class='text-justify innerpage-text'>
<p>&nbsp;</p>
<p>Comprehensive Ranking System is a points-based system administered by the <a href="canada-immigration/canada-express-entry.php"><strong>Canada Express Entry</strong></a> System to choose eligible candidates from the pool of immigration aspirants. The system uses several parameters/factors to evaluate the profile and grant the Invitation to Apply (ITA). These parameters/factors correspond to certain points wherein applicants receive particular points for each factor. The accumulated points are known as the CRS Score of an applicant, which will decide the fate of their immigration.</p>
<p>&nbsp;</p>
<p>The Express Entry system conducts draws twice a month to grant invitations to apply (ITA) to the eligible candidates. Each draw declares the minimum CRS Points requirement wherein applicants with threshold CRS points will get the ITA approval. Applicants get the CRS score upon filing the expression of interest in the official CIC account by uploading all the relevant documents.</p>
<div class="crs-form-box">
<h2 class="text-center ">Check Your Eligibility</h2>
<div class="wb-frmvld">
<form action="crs-result.php" id="crs-form" method="post" role="form">
<div class="form-group" id="Name-Input"><label class="pl-0" for="Name-Input">Enter Your Full Name</label> <input class="form-control margin-bottom" id="Name" name="Name" placeholder="Name*" required="" type="text" /></div>
<div class="form-group" id="Email-Input"><label class="pl-0" for="Email-Input">Enter Your E-Mail Id</label> <input class="form-control margin-bottom" id="Email" name="Email" placeholder="Email*" required="" type="email" /></div>
<div class="form-group" id="Country-select"><label class="pl-0" for="Country">Country</label> <select class="form-control margin-bottom" id="crscountry" name="Country"><option value="101">India</option><option value="231">United States</option><option value="38">Canada</option><option value="13">Australia</option><option value="230">United Kingdom</option><option value="160">Nigeria</option><option value="1">Afghanistan</option><option value="2">Albania</option><option value="3">Algeria</option><option value="4">American Samoa</option><option value="5">Andorra</option><option value="6">Angola</option><option value="7">Anguilla</option><option value="8">Antarctica</option><option value="9">Antigua And Barbuda</option><option value="10">Argentina</option><option value="11">Armenia</option><option value="12">Aruba</option><option value="14">Austria</option><option value="15">Azerbaijan</option><option value="16">Bahamas The</option><option value="17">Bahrain</option><option value="18">Bangladesh</option><option value="19">Barbados</option><option value="20">Belarus</option><option value="21">Belgium</option><option value="22">Belize</option><option value="23">Benin</option><option value="24">Bermuda</option><option value="25">Bhutan</option><option value="26">Bolivia</option><option value="27">Bosnia and Herzegovina</option><option value="28">Botswana</option><option value="29">Bouvet Island</option><option value="30">Brazil</option><option value="31">British Indian Ocean Territory</option><option value="32">Brunei</option><option value="33">Bulgaria</option><option value="34">Burkina Faso</option><option value="35">Burundi</option><option value="36">Cambodia</option><option value="37">Cameroon</option><option value="39">Cape Verde</option><option value="40">Cayman Islands</option><option value="41">Central African Republic</option><option value="42">Chad</option><option value="43">Chile</option><option value="44">China</option><option value="45">Christmas Island</option><option value="46">Cocos (Keeling) Islands</option><option value="47">Colombia</option><option value="48">Comoros</option><option value="49">Republic Of The Congo</option><option value="50">Democratic Republic Of The Congo</option><option value="51">Cook Islands</option><option value="52">Costa Rica</option><option value="53">Cote D&#39;Ivoire (Ivory Coast)</option><option value="54">Croatia (Hrvatska)</option><option value="55">Cuba</option><option value="56">Cyprus</option><option value="57">Czech Republic</option><option value="58">Denmark</option><option value="59">Djibouti</option><option value="60">Dominica</option><option value="61">Dominican Republic</option><option value="62">East Timor</option><option value="63">Ecuador</option><option value="64">Egypt</option><option value="65">El Salvador</option><option value="66">Equatorial Guinea</option><option value="67">Eritrea</option><option value="68">Estonia</option><option value="69">Ethiopia</option><option value="70">External Territories of Australia</option><option value="71">Falkland Islands</option><option value="72">Faroe Islands</option><option value="73">Fiji Islands</option><option value="74">Finland</option><option value="75">France</option><option value="76">French Guiana</option><option value="77">French Polynesia</option><option value="78">French Southern Territories</option><option value="79">Gabon</option><option value="80">Gambia The</option><option value="81">Georgia</option><option value="82">Germany</option><option value="83">Ghana</option><option value="84">Gibraltar</option><option value="85">Greece</option><option value="86">Greenland</option><option value="87">Grenada</option><option value="88">Guadeloupe</option><option value="89">Guam</option><option value="90">Guatemala</option><option value="91">Guernsey and Alderney</option><option value="92">Guinea</option><option value="93">Guinea-Bissau</option><option value="94">Guyana</option><option value="95">Haiti</option><option value="96">Heard and McDonald Islands</option><option value="97">Honduras</option><option value="98">Hong Kong S.A.R.</option><option value="99">Hungary</option><option value="100">Iceland</option><option value="102">Indonesia</option><option value="103">Iran</option><option value="104">Iraq</option><option value="105">Ireland</option><option value="106">Israel</option><option value="107">Italy</option><option value="108">Jamaica</option><option value="109">Japan</option><option value="110">Jersey</option><option value="111">Jordan</option><option value="112">Kazakhstan</option><option value="113">Kenya</option><option value="114">Kiribati</option><option value="115">Korea North</option><option value="116">Korea South</option><option value="117">Kuwait</option><option value="118">Kyrgyzstan</option><option value="119">Laos</option><option value="120">Latvia</option><option value="121">Lebanon</option><option value="122">Lesotho</option><option value="123">Liberia</option><option value="124">Libya</option><option value="125">Liechtenstein</option><option value="126">Lithuania</option><option value="127">Luxembourg</option><option value="128">Macau S.A.R.</option><option value="129">Macedonia</option><option value="130">Madagascar</option><option value="131">Malawi</option><option value="132">Malaysia</option><option value="133">Maldives</option><option value="134">Mali</option><option value="135">Malta</option><option value="136">Man (Isle of)</option><option value="137">Marshall Islands</option><option value="138">Martinique</option><option value="139">Mauritania</option><option value="140">Mauritius</option><option value="141">Mayotte</option><option value="142">Mexico</option><option value="143">Micronesia</option><option value="144">Moldova</option><option value="145">Monaco</option><option value="146">Mongolia</option><option value="147">Montserrat</option><option value="148">Morocco</option><option value="149">Mozambique</option><option value="150">Myanmar</option><option value="151">Namibia</option><option value="152">Nauru</option><option value="153">Nepal</option><option value="154">Netherlands Antilles</option><option value="155">Netherlands The</option><option value="156">New Caledonia</option><option value="157">New Zealand</option><option value="158">Nicaragua</option><option value="159">Niger</option><option value="161">Niue</option><option value="162">Norfolk Island</option><option value="163">Northern Mariana Islands</option><option value="164">Norway</option><option value="165">Oman</option><option value="166">Pakistan</option><option value="167">Palau</option><option value="168">Palestinian Territory Occupied</option><option value="169">Panama</option><option value="170">Papua new Guinea</option><option value="171">Paraguay</option><option value="172">Peru</option><option value="173">Philippines</option><option value="174">Pitcairn Island</option><option value="175">Poland</option><option value="176">Portugal</option><option value="177">Puerto Rico</option><option value="178">Qatar</option><option value="179">Reunion</option><option value="180">Romania</option><option value="181">Russia</option><option value="182">Rwanda</option><option value="183">Saint Helena</option><option value="184">Saint Kitts And Nevis</option><option value="185">Saint Lucia</option><option value="186">Saint Pierre and Miquelon</option><option value="187">Saint Vincent And The Grenadines</option><option value="188">Samoa</option><option value="189">San Marino</option><option value="190">Sao Tome and Principe</option><option value="191">Saudi Arabia</option><option value="192">Senegal</option><option value="193">Serbia</option><option value="194">Seychelles</option><option value="195">Sierra Leone</option><option value="196">Singapore</option><option value="197">Slovakia</option><option value="198">Slovenia</option><option value="199">Smaller Territories of the UK</option><option value="200">Solomon Islands</option><option value="201">Somalia</option><option value="202">South Africa</option><option value="203">South Georgia</option><option value="204">South Sudan</option><option value="205">Spain</option><option value="206">Sri Lanka</option><option value="207">Sudan</option><option value="208">Suriname</option><option value="209">Svalbard And Jan Mayen Islands</option><option value="210">Swaziland</option><option value="211">Sweden</option><option value="212">Switzerland</option><option value="213">Syria</option><option value="214">Taiwan</option><option value="215">Tajikistan</option><option value="216">Tanzania</option><option value="217">Thailand</option><option value="218">Togo</option><option value="219">Tokelau</option><option value="220">Tonga</option><option value="221">Trinidad And Tobago</option><option value="222">Tunisia</option><option value="223">Turkey</option><option value="224">Turkmenistan</option><option value="225">Turks And Caicos Islands</option><option value="226">Tuvalu</option><option value="227">Uganda</option><option value="228">Ukraine</option><option value="229">United Arab Emirates</option><option value="232">United States Minor Outlying Islands</option><option value="233">Uruguay</option><option value="234">Uzbekistan</option><option value="235">Vanuatu</option><option value="236">Vatican City State (Holy See)</option><option value="237">Venezuela</option><option value="238">Vietnam</option><option value="239">Virgin Islands (British)</option><option value="240">Virgin Islands (US)</option><option value="241">Wallis And Futuna Islands</option><option value="242">Western Sahara</option><option value="243">Yemen</option><option value="244">Yugoslavia</option><option value="245">Zambia</option><option value="246">Zimbabwe</option> </select></div>
<div class="form-group" id="crsstate"><label class="pl-0" for="State">State</label> <select class="form-control" id="State" name="State"><option value="1">Andaman and Nicobar Islands</option><option value="2">Andhra Pradesh</option><option value="3">Arunachal Pradesh</option><option value="4">Assam</option><option value="5">Bihar</option><option value="6">Chandigarh</option><option value="7">Chhattisgarh</option><option value="8">Dadra and Nagar Haveli</option><option value="9">Daman and Diu</option><option selected="selected" value="10">Delhi</option><option value="11">Goa</option><option value="12">Gujarat</option><option value="13">Haryana</option><option value="14">Himachal Pradesh</option><option value="15">Jammu and Kashmir</option><option value="16">Jharkhand</option><option value="17">Karnataka</option><option value="18">Kenmore</option><option value="19">Kerala</option><option value="20">Lakshadweep</option><option value="21">Madhya Pradesh</option><option value="22">Maharashtra</option><option value="23">Manipur</option><option value="24">Meghalaya</option><option value="25">Mizoram</option><option value="26">Nagaland</option><option value="27">Narora</option><option value="28">Natwar</option><option value="29">Odisha</option><option value="30">Paschim Medinipur</option><option value="31">Pondicherry</option><option value="32">Punjab</option><option value="33">Rajasthan</option><option value="34">Sikkim</option><option value="35">Tamil Nadu</option><option value="36">Telangana</option><option value="37">Tripura</option><option value="38">Uttar Pradesh</option><option value="39">Uttarakhand</option><option value="40">Vaishali</option><option value="41">West Bengal</option> </select></div>
<div><label class="pl-0" for="Phone-Input">Phone Number</label></div>
<div class="form-group" id="Phone-Input"><select class="form-control" id="crscountrycode" name="CountryCode" style="width: 35%; float: left; margin-right: 1%"><option value="91">IND (+91)</option> </select> <input class="form-control" id="Phone" name="Phone" onkeypress="if (!window.__cfRLUnblockHandlers) return false; return (event.charCode == 8 || event.charCode == 0) ? null : event.charCode &gt;= 48 &amp;&amp; event.charCode &lt;= 57" placeholder="Mobile No.*" required="" style="width: 64%;" type="text" data-cf-modified-bc21cefe8c259650a43dade3-="" /></div>
<div class="form-group" id="q1-marital-status"><label for="q1">What is your marital status?</label> <select class="form-control margin-bottom" id="q1" name="q1"><option label="Select..." value="badvalue">Select...</option><option value="A">Annulled Marriage</option><option value="B">Common-Law</option><option value="C">Divorced / Separated</option><option value="D">Legally Separated</option><option value="E">Married</option><option value="F">Never Married / Single</option><option value="G">Widowed</option> </select></div>
<div class="form-group" id="q2i-spouse-cit"><label for="q2i">Is your spouse or common-law partner a citizen or permanent resident of Canada?</label> <select class="form-control margin-bottom" id="q2i" name="q2i"><option label="Select..." value="badvalue">Select...</option><option value="A">No</option><option value="B">Yes</option> </select></div>
<div class="form-group" id="q2ii-spouse-joining"><label for="q2ii">Will your spouse or common-law partner come with you to Canada?</label> <select class="form-control margin-bottom" id="q2ii" name="q2ii"><option label="Select..." value="badvalue">Select...</option><option value="A">No</option><option value="B">Yes</option> </select></div>
<div class="form-group" id="q3-age"><label for="q3">How old are you? </label>
<p>Choose the best answer:</p>
<ul>
<li>If you&rsquo;ve been invited to apply, enter your age on the date you were invited.<br />
OR</li>
<li>If you plan to complete an Express Entry profile, enter your current age.</li>
</ul>
<select class="form-control margin-bottom" id="q3" name="q3"><option label="Select..." value="badvalue">Select...</option> </select></div>
<div class="form-group" id="q4-education"><label for="q4">What is your level of education?</label>
<p>Enter the highest level of education for which you:</p>
<ul>
<li>earned a <strong>Canadian degree, diploma or certificate</strong> or</li>
<li>had an Educational Credential Assessment (ECA) if you did your study outside Canada. (ECAs must be from an approved agency, in the last five years)</li>
</ul>
<p>Note: a Canadian degree, diploma or certificate must either have been earned at an accredited Canadian university, college, trade or technical school, or other institute in Canada. Distance learning counts for education points, but not for bonus points in your profile or application.</p>
<select class="form-control margin-bottom" id="q4" name="q4"><option label="Select..." value="badvalue">Select...</option> </select></div>
<div class="form-group" id="q4b-education"><label for="q4b">Have you earned a Canadian degree, diploma or certificate?</label>
<p>Note: to answer yes:</p>
<ul>
<li>English or French as a Second Language must not have made up more than half your study</li>
<li>you must not have studied under an award that required you to return to your home country after graduation to apply your skills and knowledge</li>
<li>you must have studied at a school within Canada (foreign campuses don&rsquo;t count)</li>
<li>you had to be enrolled full time for at least eight months, and have been physically present in Canada for at least eight months</li>
</ul>
<select class="form-control margin-bottom" id="q4b" name="q4b"><option label="Select..." value="badvalue">Select...</option><option label="No" value="A">No</option><option label="Yes" value="B">Yes</option> </select></div>
<div class="form-group" id="q4c-education"><label for="q4c">Choose the best answer to describe this level of education.</label> <select class="form-control margin-bottom" id="q4c" name="q4c"><option label="Select..." value="badvalue">Select...</option><option value="A">Secondary (high school) or less</option><option value="B">One- or two-year diploma or certificate</option><option value="C">Degree, diploma or certificate of three years or longer OR a Master&rsquo;s, professional or doctoral degree of at least one academic year</option> </select></div>
<div class="form-group" id="q5-ol">
<p><strong>Official languages: Canada&#39;s official languages are English and French.</strong></p>
<p><strong>You need to submit language test results that are less than two years old for all programs under Express Entry, even if English or French is your first language.</strong></p>
<div class="form-group" id="q5i-fol"><label for="q5i">Are your test results less than two years old?</label> <select class="form-control margin-bottom" id="q5i" name="q5i"><option label="Select..." value="badvalue">Select...</option><option value="B">No</option><option value="A">Yes</option> </select></div>
<div class="form-group" id="q5i-a-fol"><label for="q5i-a">Which language test did you take for your first official language? </label> <select class="form-control margin-bottom" id="q5i-a" name="q5i-a"><option label="Select..." value="badvalue">Select...</option><option value="A">CELPIP-G</option><option value="B">IELTS</option><option value="C">TEF Canada</option><option value="D">TCF Canada</option> </select></div>
<div class="form-group" id="q5i-b-fol">
<p>Enter your test scores:</p>
<label for="q5i-b-speaking">Speaking:</label> <select class="form-control margin-bottom mb-3" id="q5i-b-speaking" name="q5i-b-speaking"><option label="Select..." value="badvalue">Select...</option> </select> <label for="q5i-b-listening">Listening:</label> <select class="form-control margin-bottom mb-3" id="q5i-b-listening" name="q5i-b-listening"><option label="Select..." value="badvalue">Select...</option> </select> <label for="q5i-b-reading">Reading:</label> <select class="form-control margin-bottom mb-3" id="q5i-b-reading" name="q5i-b-reading"><option label="Select..." value="badvalue">Select...</option> </select> <label for="q5i-b-writing">Writing:</label> <select class="form-control margin-bottom" id="q5i-b-writing" name="q5i-b-writing"><option label="Select..." value="badvalue">Select...</option> </select></div>
<div class="form-group" id="q5ii-sol"><label for="q5ii">Do you have other language results?</label>
<p>If so, which language test did you take for your second official language?</p>
<p>Test results must be less than two years old.</p>
<select class="form-control margin-bottom" id="q5ii" name="q5ii"><option label="Select..." value="badvalue">Select...</option> </select></div>
<div class="form-group" id="q5ii-b-sol">
<p><strong>Enter your test scores for:</strong></p>
<label for="q5ii-sol-speaking">Speaking:</label> <select class="form-control margin-bottom mb-3" id="q5ii-sol-speaking" name="q5ii-sol-speaking"><option label="Select..." value="badvalue">Select...</option> </select> <label for="q5ii-sol-listening">Listening:</label> <select class="form-control margin-bottom mb-3" id="q5ii-sol-listening" name="q5ii-sol-listening"><option label="Select..." value="badvalue">Select...</option> </select> <label for="q5ii-sol-reading">Reading:</label> <select class="form-control margin-bottom mb-3" id="q5ii-sol-reading" name="q5ii-sol-reading"><option label="Select..." value="badvalue">Select...</option> </select> <label for="q5ii-sol-writing">Writing:</label> <select class="form-control margin-bottom" id="q5ii-sol-writing" name="q5ii-sol-writing"><option label="Select..." value="badvalue">Select...</option> </select></div>
</div>
<div class="form-group" id="q6-work-xp">
<p><strong>Work Experience</strong></p>
<div id="q6i-canada"><label for="q6i">In the last ten years, how many years of skilled work experience in Canada do you have? </label>
<p>It must have been paid and full-time (or an equal amount in part-time).</p>
<p><strong>Note:</strong> In Canada, the National Occupational Classification (NOC) is the official list of all the jobs in the Canadian labour market. It describes each job according to skill type, group and level.</p>
<p>&quot;Skilled work&quot; in the NOC is:</p>
<ul>
<li>managerial jobs (NOC Skill Level 0)</li>
<li>professional jobs (NOC Skill Type A)</li>
<li>technical jobs and skilled trades/manual work (NOC Skill Type B)</li>
</ul>
<p>If you aren&rsquo;t sure of the NOC level for this job, you can find your NOC.</p>
<select class="form-control margin-bottom mb-3" id="q6i" name="q6i"><option label="Select..." value="badvalue">Select...</option><option value="A">None or less than a year</option><option value="B">1 year</option><option value="C">2 years</option><option value="D">3 years</option><option value="E">4 years</option><option value="F">5 years or more</option> </select></div>
<div id="q6ii-foreign"><label for="q6ii">In the last 10 years, how many total years of foreign skilled work experience do you have? </label>
<p>It must have been paid, full-time (or an equal amount in part-time), and in only one occupation (NOC skill type 0, A or B).</p>
<select class="form-control margin-bottom" id="q6ii" name="q6ii"><option label="Select..." value="badvalue">Select...</option><option value="A">None or less than a year</option><option value="B">1 year</option><option value="C">2 years</option><option value="D">3 years or more</option> </select></div>
</div>
<div class="form-group" id="q7-certificate"><label for="q7">Do you have a certificate of qualification from a Canadian province, territory or federal body?</label>
<p><strong>Note: </strong>A certificate of qualification lets people work in some skilled trades in Canada. Only the provinces, territories and a federal body can issue these certificates. To get one, a person must have them assess their training, trade experience and skills to and then pass a certification exam.</p>
<p>People usually have to go to the province or territory to be assessed. They may also need experience and training from an employer in Canada.</p>
<p>This isn&rsquo;t the same as a nomination from a province or territory.</p>
<select class="form-control margin-bottom" id="q7" name="q7"><option label="Select..." value="badvalue">Select...</option><option value="A">No</option><option value="B">Yes</option> </select></div>
<div class="form-group" id="q8-offer">
<p><strong>Additional Points</strong></p>
<label for="q8">Do you have a valid job offer supported by a Labour Market Impact Assessment (if needed)? </label>
<p>A valid job offer must be</p>
<ul>
<li>full-time</li>
<li>in a skilled job listed as Skill Type 0, or Skill Level A or B in the 2011 National Occupational Classification</li>
<li>supported by a Labour Market Impact Assessment (LMIA) or exempt from needing one</li>
<li>for one year from the time you become a permanent resident</li>
</ul>
<p>A job offer isn&rsquo;t valid if your employer is:</p>
<ul>
<li>an embassy, high commission or consulate in Canada or</li>
<li>on the list of ineligible employers.</li>
</ul>
<p>Whether an offer is valid or not also depends on different factors, depending on your case. See a full list of criteria for valid job offers.</p>
<select class="form-control margin-bottom" id="q8" name="q8"><option label="Select..." value="badvalue">Select...</option><option value="A">No</option><option value="B">Yes</option> </select></div>
<div class="form-group" id="q8-noc"><label for="q8a">Which NOC skill type or level is the job offer?</label>
<p>You can use our online tool to find out if you don&rsquo;t know.</p>
<select class="form-control margin-bottom" id="q8a" name="q8a"><option label="Select..." value="badvalue">Select...</option><option value="A">NOC Skill Type 00</option><option value="B">NOC Skill Level A or B or any Type 0 other than 00</option><option value="C">NOC Skill Level C or D</option> </select></div>
<div class="form-group" id="q9-nomination"><label for="q9">Do you have a nomination certificate from a province or territory?</label> <select class="form-control margin-bottom" id="q9" name="q9"><option label="Select..." value="badvalue">Select...</option><option value="A">No</option><option value="B">Yes</option> </select></div>
<div class="form-group" id="q10-sibling"><label for="q10i">Do you or your spouse or common law partner (if they will come with you to Canada) have at least one brother or sister living in Canada who is a citizen or permanent resident?</label>
<p><strong>Note: to answer yes, the brother or sister must be:</strong></p>
<ul>
<li>18 years old or older</li>
<li>related to you or your partner by blood, marriage, common-law partnership or adoption</li>
<li>have a parent in common with you or your partner</li>
</ul>
<p>A brother or sister is related to you by:</p>
<ul>
<li>blood (biological)</li>
<li>adoption</li>
<li>marriage (step-brother or step-sister)</li>
</ul>
<select class="form-control margin-bottom" id="q10i" name="q10i"><option label="Select..." value="badvalue">Select...</option><option value="A">No</option><option value="B">Yes</option> </select></div>
<div id="spouse_questions">
<div class="form-group" id="q10-s-education"><label for="q10">What is the highest level of education for which your spouse or common-law partner&#39;s has:</label>
<ul>
<li><strong>earned a Canadian degree, diploma or certificate; or</strong></li>
<li><strong>had an Educational Credential Assessment (ECA)? (ECAs must be from an approved agency, in the last five years)</strong></li>
</ul>
<p>To get the correct number of points, make sure you choose the answer that best reflects your case. For example:</p>
<p>If you have TWO Bachelor&rsquo;s degrees, or one Bachelor&rsquo;s AND a two year college diploma, choose &ndash; &ldquo;Two or more certificates, diplomas, or degrees. One must be for a program of three or more years.&rdquo;</p>
<select class="form-control margin-bottom" id="q10" name="q10"><option label="Select..." value="badvalue">Select...</option><option value="A">None, or less than secondary (high school)</option><option value="B">Secondary diploma (high school graduation)</option><option value="C">One-year program at a university, college, trade or technical school, or other institute</option><option value="D">Two-year program at a university, college, trade or technical school, or other institute</option><option value="E">Bachelor&#39;s degree (three or more year program at a university, college, trade or technical school, or other institute)</option><option value="F">Two or more certificates, diplomas or degrees. One must be for a program of three or more years</option><option value="G">Master&#39;s degree, or professional degree needed to practice in a licensed profession</option><option value="H">Doctoral level university degree (PhD)</option> </select></div>
<div class="form-group" id="q11-s-work-xp"><label for="q11">In the last ten years, how many years of skilled work experience in Canada does your spouse/common-law partner have? </label>
<p>It must have been paid, full-time (or an equal amount in part-time), and in one or more NOC 0, A or B jobs.</p>
<select class="form-control margin-bottom" id="q11" name="q11"><option label="Select..." value="badvalue">Select...</option><option value="A">None or less than a year</option><option value="B">1 year</option><option value="C">2 years</option><option value="D">3 years</option><option value="E">4 years</option><option value="F">5 years or more</option> </select></div>
<div class="form-group" id="q12-s-fol"><label for="q12i">Did your spouse or common-law partner take a language test? If so, which one?</label>
<p>Test results must be less than two years old.</p>
<select class="form-control margin-bottom" id="q12i" name="q12i"><option label="Select..." value="badvalue">Select...</option><option value="A">CELPIP-G</option><option value="B">IELTS</option><option value="C">TEF Canada</option><option value="D">TCF Canada</option><option value="E">not applicable</option> </select></div>
<div id="q12ii-s-fol">
<p><strong>Enter the test scores for:</strong></p>
<div class="form-group"><label for="q12ii-fol-speaking">Speaking:</label> <select class="form-control margin-bottom" id="q12ii-fol-speaking" name="q12ii-fol-speaking"><option label="Select..." value="badvalue">Select...</option> </select></div>
<div class="form-group"><label for="q12ii-fol-listening">Listening:</label> <select class="form-control margin-bottom" id="q12ii-fol-listening" name="q12ii-fol-listening"><option label="Select..." value="badvalue">Select...</option> </select></div>
<div class="form-group"><label for="q12ii-fol-reading">Reading:</label> <select class="form-control margin-bottom" id="q12ii-fol-reading" name="q12ii-fol-reading"><option label="Select..." value="badvalue">Select...</option> </select></div>
<div class="form-group"><label for="q12ii-fol-writing">Writing:</label> <select class="form-control margin-bottom" id="q12ii-fol-writing" name="q12ii-fol-writing"><option label="Select..." value="badvalue">Select...</option> </select></div>
</div>
</div>
<div class="form-group"><input class="form-control" id="LeadSource" name="LeadSource" readonly="readonly" type="hidden" value="Website-CRS Calculator" /></div>
<center><button class="btn btn-danger calculate-btn disabled" id="submit" type="submit">Calculate my score</button></center>
<input name="CRSForm" type="hidden" /> <input id="page" name="page" type="hidden" value="" /> <input id="UTMS" name="utm_source" type="hidden" value="" /> <input id="UTMM" name="utm_medium" type="hidden" value="" /> <input id="UTMC" name="utm_campaign" type="hidden" value="" /></form>
</div>
<div id="neg-results">&nbsp;</div>
<div id="results">
<div class="alert alert-secondary">
<h2>Your results</h2>
<p>All Express Entry candidates get a score out of 1,200, based on the four parts of the Comprehensive Ranking System formula.</p>
<p>We invite the highest-ranking candidates from the pool to apply as a permanent resident through regular &ldquo;rounds of invitations.&rdquo; See what minimum scores have been in the past.</p>

</div>
</div>
<div id="test">&nbsp;</div>
</div>


<p>&nbsp;</p>
<p><strong><u>What are the categories under Comprehensive Ranking System (CRS) Criteria?</u></strong></p>
<ul>
<li>Core / Human Capital Factors</li>
<li>Spouse/common-law partner Factors</li>
<li>Skill Transferability Factors</li>
<li>Additional Factors:
<ul>
<li>Provincial Nomination</li>
<li>Arranged Employment</li>
<li>French Language proficiency</li>
<li>Canadian Study Experience</li>
<li>Sibling Living in Canada</li>
</ul>
</li>
</ul>
<p>&nbsp;</p>
<p><strong><u>What are the maximum points earned for each factor of CRS Criteria?</u></strong></p>
<p></p>
<p><strong>CORE / HUMAN CAPITAL FACTORS</strong></p>
<p></p>
<table class="table table-bordered table-crs">
<tbody>
<tr>
<td>
<p><strong>Factors</strong></p>
</td>
<td>
<p><strong>Points - With a spouse or common-law partner</strong></p>
</td>
<td>
<p><strong>Points - Without a spouse or common-law partner</strong></p>
</td>
</tr>
<tr>
<td>
<p>Age</p>
</td>
<td>
<p>100</p>
</td>
<td>
<p>110</p>
</td>
</tr>
<tr>
<td>
<p>Level of Education</p>
</td>
<td>
<p>140</p>
</td>
<td>
<p>150</p>
</td>
</tr>
<tr>
<td>
<p>Language Proficiency</p>
</td>
<td>
<p>150</p>
</td>
<td>
<p>160</p>
</td>
</tr>
<tr>
<td>
<p>Canadian Work Experience</p>
</td>
<td>
<p>70</p>
</td>
<td>
<p>80</p>
</td>
</tr>
</tbody>
</table>
<p>&nbsp;</p>
<p><strong>SPOUSE/COMMON-LAW PARTNER FACTORS</strong></p>
<table class="table table-bordered table-crs">
<tbody>
<tr>
<td>
<p><strong>Factors</strong></p>
</td>
<td>
<p><strong>Points Per Factor</strong></p>
</td>
</tr>
<tr>
<td>
<p>Level of Education</p>
</td>
<td>
<p>10</p>
</td>

</tr>
<tr>
<td>
<p>Language Proficiency</p>
</td>
<td>
<p>20</p>
</td>
</tr>
<tr>
<td>
<p>Canadian Work Experience</p>
</td>
<td>
<p>10</p>
</td>
</tr>
</tbody>
</table>
<p>&nbsp;</p>
<p><strong>SKILL TRANSFERABILITY FACTORS</strong></p>
<table class="table table-bordered table-crs">
<tbody>
<tr>
<td>
<p><strong>Education</strong></p>
</td>
<td>
<p><strong>Points per factor (maximum 50 points)</strong></p>
</td>
</tr>
<tr>
<td>
<p>Good language proficiency and a post-secondary degree</p>
</td>
<td>
<p>50</p>
</td>
</tr>
<tr>
<td>
<p>Canadian work experience and a post-secondary degree</p>
</td>
<td>
<p>50</p>
</td>
</tr>
<tr>
<td>
<p><strong>Foreign work experience</strong></p>
</td>
<td>
<p><strong>Points per factor (maximum 50 points)</strong></p>
</td>
</tr>
<tr>
<td>
<p>Language proficiency with minimum CLB 7 and Foreign work experience (Native)</p>
</td>
<td>
<p>50</p>
</td>
</tr>
<tr>
<td>
<p>Canadian work experience and foreign work experience (Native/home country)</p>
</td>
<td>
<p>50</p>
</td>
</tr>
<tr>
<td>
<p><strong>Certificate of qualification (for professionals in trade occupations)</strong></p>
</td>
<td>
<p><strong>Points per factor (maximum 50 points)</strong></p>
</td>
</tr>
<tr>
<td>
<p>Good language proficiency and a certificate of qualification</p>
</td>
<td>
<p>50</p>
</td>
</tr>
</tbody>
</table>
<p>&nbsp;</p>
<p><strong>ADDITIONAL FACTORS</strong></p>
<table class="table table-bordered table-crs">
<tbody>
<tr>
<td>
<p><strong>Factors</strong></p>
</td>
<td>
<p><strong>Maximum Points Per factor</strong></p>
</td>
</tr>
<tr>
<td>
<p>Siblings in Canada (Permanent Resident or Citizen)</p>
</td>
<td>
<p>15</p>
</td>
</tr>
<tr>
<td>
<p>French Language Proficiency</p>
</td>
<td>
<p>50</p>
</td>
</tr>
<tr>
<td>
<p>Post-Secondary Education gained in Canada</p>
</td>
<td>
<p>30</p>
</td>
</tr>
<tr>
<td>
<p>Arranged Employment / Job Offer from Canada</p>
</td>
<td>
<p>200</p>
</td>
</tr>
<tr>
<td>
<p>Canada PNP nomination</p>
</td>
<td>
<p>600</p>
</td>
</tr>
</tbody>
</table>
<p>&nbsp;</p>
<p><strong><u>What is the point breakdown of each factor of CRS Criteria?</u></strong></p>
<p></p>
<p><strong>CORE / HUMAN CAPITAL FACTORS</strong></p>
<table class="table table-bordered table-crs">
<tbody>
<tr>
<td>
<p><strong>Age</strong></p>
</td>
<td>
<p><strong>Points - With a spouse or common-law partner (Maximum 100 Points)</strong></p>
</td>
<td>
<p><strong>Points &ndash; Without a spouse or common-law partner (Maximum 110 Points)</strong></p>
</td>
</tr>
<tr>
<td>
<p>Maximum 17 age</p>
</td>
<td>
<p>0</p>
</td>
<td>
<p>0</p>
</td>
</tr>
<tr>
<td>
<p>18 years of Age</p>
</td>
<td>
<p>90</p>
</td>
<td>
<p>99</p>
</td>
</tr>
<tr>
<td>
<p>19 years of Age</p>
</td>
<td>
<p>95</p>
</td>
<td>
<p>105</p>
</td>
</tr>
<tr>
<td>
<p>20 years to 29 years of Age</p>
</td>
<td>
<p>100</p>
</td>
<td>
<p>110</p>
</td>
</tr>
<tr>
<td>
<p>30 years of Age</p>
</td>
<td>
<p>95</p>
</td>
<td>
<p>105</p>
</td>
</tr>
<tr>
<td>
<p>31 years of Age</p>
</td>
<td>
<p>90</p>
</td>
<td>
<p>99</p>
</td>
</tr>
<tr>
<td>
<p>32 years of Age</p>
</td>
<td>
<p>85</p>
</td>
<td>
<p>94</p>
</td>
</tr>
<tr>
<td>
<p>33 years of Age</p>
</td>
<td>
<p>80</p>
</td>
<td>
<p>88</p>
</td>
</tr>
<tr>
<td>
<p>34 years of Age</p>
</td>
<td>
<p>75</p>
</td>
<td>
<p>83</p>
</td>
</tr>
<tr>
<td>
<p>35 years of Age</p>
</td>
<td>
<p>70</p>
</td>
<td>
<p>77</p>
</td>
</tr>
<tr>
<td>
<p>36 years of Age</p>
</td>
<td>
<p>65</p>
</td>
<td>
<p>72</p>
</td>
</tr>
<tr>
<td>
<p>37 years of Age</p>
</td>
<td>
<p>60</p>
</td>
<td>
<p>66</p>
</td>
</tr>
<tr>
<td>
<p>38 years of Age</p>
</td>
<td>
<p>55</p>
</td>
<td>
<p>61</p>
</td>
</tr>
<tr>
<td>
<p>39 years of Age</p>
</td>
<td>
<p>50</p>
</td>
<td>
<p>55</p>
</td>
</tr>
<tr>
<td>
<p>40 years of Age</p>
</td>

<td>
<p>45</p>
</td>
<td>
<p>50</p>
</td>
</tr>
<tr>
<td>
<p>41 years of Age</p>
</td>
<td>
<p>35</p>
</td>
<td>
<p>39</p>
</td>
</tr>
<tr>
<td>
<p>42 years of Age</p>
</td>
<td>
<p>25</p>
</td>
<td>
<p>28</p>
</td>
</tr>
<tr>
<td>
<p>43 years of Age</p>
</td>
<td>
<p>15</p>
</td>
<td>
<p>17</p>
</td>
</tr>
<tr>
<td>
<p>44 years of Age</p>
</td>
<td>
<p>5</p>
</td>
<td>
<p>6</p>
</td>
</tr>
<tr>
<td>
<p>45 years of age or more</p>
</td>
<td>
<p>0</p>
</td>
<td>
<p>0</p>
</td>
</tr>
</tbody>
</table>
<p>&nbsp;</p>
<table class="table table-bordered table-crs">
<tbody>
<tr>
<td>
<p><strong>Education</strong></p>
</td>
<td>
<p><strong>Points - With a spouse or common-law partner (Maximum 140 Points)</strong></p>
</td>
<td>
<p><strong>Points &ndash; Without a spouse or common-law partner (Maximum 150 Points)</strong></p>
</td>
</tr>
<tr>
<td>
<p>Less than High School</p>
</td>
<td>
<p>0</p>
</td>
<td>
<p>0</p>
</td>
</tr>
<tr>
<td>
<p>Secondary Diploma (High School)</p>
</td>
<td>
<p>28</p>
</td>
<td>
<p>30</p>
</td>
</tr>
<tr>
<td>
<p>One year degree, diploma, or certificate from a recognized institution</p>
</td>
<td>
<p>84</p>
</td>
<td>
<p>90</p>
</td>
</tr>
<tr>
<td>
<p>Two Year program from a recognized institution</p>
</td>
<td>
<p>91</p>
</td>
<td>
<p>98</p>
</td>
</tr>
<tr>
<td>
<p>Bachelor&rsquo;s Degree or a Three or more year program from a recognized institution</p>
</td>
<td>
<p>112</p>
</td>
<td>
<p>120</p>
</td>
</tr>
<tr>
<td>
<p>Two or more Diplomas, Certificates, or Degrees. <em>(One must be a three-year program)</em></p>
</td>
<td>
<p>119</p>
</td>
<td>
<p>128</p>
</td>
</tr>
<tr>
<td>
<p>Master&rsquo;s Degree or a Professional Degree <em>(Licensed Profession)</em></p>
</td>
<td>
<p>126</p>
</td>
<td>
<p>135</p>
</td>
</tr>
<tr>
<td>
<p>Doctoral Level Degree (Ph.D.)</p>
</td>
<td>
<p>140</p>
</td>
<td>
<p>150</p>
</td>
</tr>
</tbody>
</table>
<p>&nbsp;</p>
<table class="table table-bordered table-crs">
<tbody>
<tr>
<td>
<p><strong>CLB Level per ability &ndash; Reading, Writing, Speaking &amp; Listening (First Official Language)</strong></p>
</td>
<td>
<p><strong>Points - With a spouse or common-law partner (Maximum 128 Points)</strong></p>
</td>
<td>
<p><strong>Points &ndash; Without a spouse or common-law partner (Maximum 136 Points)</strong></p>
</td>
</tr>
<tr>
<td>
<p>Less than CLB 4</p>
</td>
<td>
<p>0</p>
</td>
<td>
<p>0</p>
</td>
</tr>
<tr>
<td>
<p>CLB 4 or CLB 5</p>
</td>
<td>
<p>6 per ability</p>
</td>
<td>
<p>6 per ability</p>
</td>
</tr>
<tr>
<td>
<p>CLB 6</p>
</td>
<td>
<p>8 per ability</p>
</td>
<td>
<p>9 per ability</p>
</td>
</tr>
<tr>
<td>
<p>CLB 7</p>
</td>
<td>
<p>16 per ability</p>
</td>
<td>
<p>17 per ability</p>
</td>
</tr>
<tr>
<td>
<p>CLB 8</p>
</td>
<td>
<p>22 per ability</p>
</td>
<td>
<p>23 per ability</p>
</td>
</tr>
<tr>
<td>
<p>CLB 9</p>
</td>
<td>
<p>29 per ability</p>
</td>
<td>
<p>31 per ability</p>
</td>
</tr>
<tr>
<td>
<p>CLB 10 or more</p>
</td>
<td>
<p>32 per ability</p>
</td>
<td>
<p>34 per ability</p>
</td>
</tr>
</tbody>
</table>
<p>&nbsp;</p>
<table class="table table-bordered table-crs">
<tbody>
<tr>
<td>
<p><strong>CLB Level per ability (Second Official Language)</strong></p>
</td>
<td>
<p><strong>Points - With a spouse or common-law partner (Maximum 22 Points)</strong></p>
</td>
<td>
<p><strong>Points &ndash; Without a spouse or common-law partner (Maximum 24 Points)</strong></p>
</td>
</tr>
<tr>
<td>
<p>CLB 4 or less than CLB 4</p>
</td>
<td>
<p>0</p>
</td>
<td>
<p>0</p>
</td>
</tr>
<tr>
<td>
<p>CLB 5 or CLB 6</p>
</td>
<td>
<p>1 per ability</p>
</td>
<td>
<p>1 per ability</p>
</td>
</tr>
<tr>
<td>
<p>CLB 7 or CLB 8</p>
</td>
<td>
<p>3 per ability</p>
</td>
<td>
<p>3 per ability</p>
</td>
</tr>
<tr>
<td>
<p>CLB 9 or more</p>
</td>
<td>
<p>6 per ability</p>
</td>
<td>
<p>6 per ability</p>
</td>
</tr>
</tbody>
</table>
<p>&nbsp;</p>
<table class="table table-bordered table-crs">
<tbody>
<tr>
<td>
<p><strong>Canadian Work Experience</strong></p>
</td>
<td>
<p><strong>Points - With a spouse or common-law partner (Maximum 70 Points)</strong></p>
</td>
<td>
<p><strong>Points &ndash; Without a spouse or common-law partner (Maximum 80 Points)</strong></p>
</td>
</tr>
<tr>
<td>
<p>None or less than one year</p>
</td>
<td>
<p>0</p>
</td>
<td>
<p>0</p>
</td>
</tr>
<tr>
<td>
<p>1 Year</p>
</td>
<td>
<p>35</p>
</td>
<td>
<p>40</p>
</td>
</tr>
<tr>
<td>
<p>2 Years</p>
</td>
<td>
<p>46</p>
</td>
<td>
<p>53</p>
</td>
</tr>
<tr>
<td>
<p>3 Years</p>
</td>
<td>
<p>56</p>
</td>
<td>
<p>64</p>
</td>
</tr>
<tr>
<td>
<p>4 Years</p>
</td>
<td>
<p>63</p>
</td>
<td>
<p>72</p>
</td>
</tr>
<tr>
<td>
<p>5 Years or more</p>
</td>
<td>
<p>70</p>
</td>
<td>
<p>80</p>
</td>
</tr>
</tbody>
</table>
<p>&nbsp;</p>
<p><strong>SPOUSE/COMMON-LAW PARTNER FACTORS</strong></p>
<table class="table table-bordered table-crs">
<tbody>
<tr>
<td>
<p><strong>Spouse or Common-Law Partner&rsquo;s Education</strong></p>
</td>
<td>
<p><strong>Points - With a spouse or common-law partner (Maximum 10 Points)</strong></p>
</td>
</tr>
<tr>
<td>
<p>Less than High School</p>
</td>
<td>
<p>0</p>
</td>
</tr>
<tr>
<td>
<p>Secondary Diploma (High School)</p>
</td>
<td>
<p>2</p>
</td>
</tr>
<tr>
<td>
<p>One year program from a recognized institution</p>
</td>
<td>
<p>6</p>
</td>
</tr>
<tr>
<td>
<p>Two Year program from a recognized institution</p>
</td>
<td>
<p>7</p>
</td>
</tr>
<tr>
<td>
<p>Bachelor&rsquo;s Degree or a Three or more year program from a recognized institution</p>
</td>
<td>
<p>8</p>
</td>
</tr>
<tr>
<td>
<p>Two or more Diplomas, Certificates, or Degrees. <em>(One must be a three-year program)</em></p>
</td>
<td>
<p>9</p>
</td>
</tr>
<tr>
<td>
<p>Master&rsquo;s Degree or a Professional Degree <em>(Licensed Profession)</em></p>
</td>
<td>
<p>10</p>
</td>
</tr>
<tr>
<td>
<p>Doctoral Level Degree (Ph.D.)</p>
</td>
<td>
<p>10</p>
</td>
</tr>
</tbody>
</table>
<p>&nbsp;</p>
<table class="table table-bordered table-crs">
<tbody>
<tr>
<td>
<p><strong>Spouse&rsquo;s CLB Level per ability - Reading, Writing, Speaking &amp; Listening</strong></p>
</td>
<td>
<p><strong>Points - With a spouse or common-law partner (Maximum 20 Points)</strong></p>
</td>
</tr>
<tr>
<td>
<p>CLB 4 or Less than CLB 4</p>
</td>
<td>
<p>0</p>
</td>
</tr>
<tr>
<td>
<p>CLB 5 or CLB 6</p>
</td>
<td>
<p>1 per ability</p>
</td>
</tr>
<tr>
<td>
<p>CLB 7 or CLB 8</p>
</td>
<td>
<p>3 per ability</p>
</td>
</tr>
<tr>
<td>
<p>CLB 9 or more</p>
</td>
<td>
<p>5 per ability</p>
</td>
</tr>
</tbody>
</table>
<p>&nbsp;</p>
<table class="table table-bordered table-crs">
<tbody>
<tr>
<td>
<p><strong>Spouse&rsquo;s Canadian Work Experience</strong></p>
</td>
<td>
<p><strong>Points &ndash; With a spouse or common-law partner (Maximum 10 Points)</strong></p>
</td>
</tr>
<tr>
<td>
<p>None or less than one year</p>
</td>
<td>
<p>0</p>
</td>
</tr>
<tr>
<td>
<p>1 Year</p>
</td>
<td>
<p>5</p>
</td>
</tr>
<tr>
<td>
<p>2 Years</p>
</td>
<td>
<p>7</p>
</td>
</tr>
<tr>
<td>
<p>3 Years</p>
</td>
<td>
<p>8</p>
</td>

</tr>
<tr>
<td>
<p>4 Years</p>
</td>
<td>
<p>9</p>
</td>
</tr>
<tr>
<td>
<p>5 Years or more</p>
</td>
<td>
<p>10</p>
</td>
</tr>
</tbody>
</table>
<p>&nbsp;</p>
<p><strong>SKILL TRANSFERABILITY FACTORS</strong></p>
<table class="table table-bordered table-crs">
<tbody>
<tr>
<td>
<p><strong>Post-Secondary Education with minimum CLB 7 Language Proficiency</strong></p>
</td>
<td>
<p><strong>Points for CLB 7 or more for all abilities (maximum 25 points)</strong></p>
</td>
<td>
<p><strong>Points for CLB 9 or more for all abilities (maximum 50 points)</strong></p>
</td>
</tr>
<tr>
<td>
<p>High School certificate or less</p>
</td>
<td>
<p>0</p>
</td>
<td>
<p>0</p>
</td>
</tr>
<tr>
<td>
<p>Post-secondary program of one year or more</p>
</td>
<td>
<p>13</p>
</td>
<td>
<p>25</p>
</td>
</tr>
<tr>
<td>
<p>Two or more Post-secondary programs and a minimum of one program must be of three years duration or more</p>
</td>
<td>
<p>25</p>
</td>
<td>
<p>50</p>
</td>
</tr>
<tr>
<td>
<p>Master&rsquo;s Degree or a Professional Degree (Licensed Profession)</p>
</td>
<td>
<p>25</p>
</td>
<td>
<p>50</p>
</td>
</tr>
<tr>
<td>
<p>Doctoral Level Degree (Ph.D.)</p>
</td>
<td>
<p>25</p>
</td>
<td>
<p>50</p>
</td>
</tr>
</tbody>
</table>
<p>&nbsp;</p>
<table class="table table-bordered table-crs">
<tbody>
<tr>
<td>
<p><strong>Post-Secondary Education with Canadian Work Experience</strong></p>
</td>
<td>
<p><strong>Points for more than 1 year of Canadian Work Experience (maximum 25 points)</strong></p>
</td>
<td>
<p><strong>Points for more than 2 years of Canadian Work Experience (maximum 50 points)</strong></p>
</td>
</tr>
<tr>
<td>
<p>High School certificate or less</p>
</td>
<td>
<p>0</p>
</td>
<td>
<p>0</p>
</td>
</tr>
<tr>
<td>
<p>Post-secondary program of one year or more</p>
</td>
<td>
<p>13</p>
</td>
<td>
<p>25</p>
</td>
</tr>
<tr>
<td>
<p>Two or more Post-secondary programs and a minimum of one program must be of three years duration or more</p>
</td>
<td>
<p>25</p>
</td>
<td>
<p>50</p>
</td>
</tr>
<tr>
<td>
<p>Master&rsquo;s Degree or a Professional Degree (Licensed Profession)</p>
</td>
<td>
<p>25</p>
</td>
<td>
<p>50</p>
</td>
</tr>
<tr>
<td>
<p>Doctoral Level Degree (Ph.D.)</p>
</td>
<td>
<p>25</p>
</td>
<td>
<p>50</p>
</td>
</tr>
</tbody>
</table>
<p>&nbsp;</p>
<table class="table table-bordered table-crs">
<tbody>
<tr>
<td>
<p><strong>Foreign Experience (Home Country)</strong></p>
</td>
<td>
<p><strong>Points for foreign Experience + CLB 7 or more (maximum 25 points)</strong></p>
</td>
<td>
<p><strong>Points for foreign Experience + CLB 9 or more (maximum 50 points)</strong></p>
</td>
</tr>
<tr>
<td>
<p>1 or 2 years of Experience</p>
</td>
<td>
<p>13</p>
</td>
<td>
<p>25</p>
</td>
</tr>
<tr>
<td>
<p>3 years or more of Experience</p>
</td>
<td>
<p>25</p>
</td>
<td>
<p>50</p>
</td>
</tr>
</tbody>
</table>
<p>&nbsp;</p>
<table class="table table-bordered table-crs">
<tbody>
<tr>
<td>
<p><strong>Foreign Experience (Home Country) &amp; Canadian Experience</strong></p>
</td>
<td>
<p><strong>Points for foreign Experience + more than 1 year of Canadian Experience (maximum 25 points)</strong></p>
</td>
<td>
<p><strong>Points for foreign Experience + more than 2 years of Canadian Experience (maximum 50 points)</strong></p>
</td>
</tr>
<tr>
<td>
<p>1 or 2 years of Experience</p>
</td>
<td>
<p>13</p>
</td>
<td>
<p>25</p>
</td>
</tr>
<tr>
<td>
<p>3 years or more of Experience</p>
</td>
<td>
<p>25</p>
</td>
<td>
<p>50</p>
</td>
</tr>
</tbody>
</table>
<p>&nbsp;</p>
<table class="table table-bordered table-crs">
<tbody>
<tr>
<td>
<p><strong>Certificate of Qualification (For professionals in trade occupations) with Good CLB</strong></p>
</td>
<td>
<p><strong>Points for Certificate of Qualification + CLB 5 or more (maximum 25 points)</strong></p>
</td>
<td>
<p><strong>Points for Certificate of Qualification + CLB 7 or more (maximum 50 points)</strong></p>
</td>
</tr>
<tr>
<td>
<p>With a Certification of Qualification</p>
</td>
<td>
<p>25</p>
</td>
<td>
<p>50</p>
</td>
</tr>
</tbody>
</table>
<p>&nbsp;</p>
<p><strong>ADDITIONAL FACTORS</strong></p>
<table class="table table-bordered table-crs">
<tbody>
<tr>
<td>
<p><strong>Factors</strong></p>
</td>
<td>
<p><strong>Points Per factor</strong></p>
</td>
</tr>
<tr>
<td>
<p>Siblings in Canada (Permanent Resident or Citizen)</p>
</td>
<td>
<p>15</p>
</td>
</tr>
<tr>
<td>
<p>NCLC 7 or more in French Language and minimum CLB 4 (Or No English Test)</p>
</td>
<td>
<p>25</p>
</td>
</tr>
<tr>
<td>
<p>NCLC 7 or more in French Language and minimum CLB 5 or higher</p>
</td>
<td>
<p>50</p>
</td>
</tr>
<tr>
<td>
<p>Post-Secondary Education gained in Canada one or two years</p>
</td>
<td>
<p>15</p>
</td>
</tr>
<tr>
<td>
<p>Post-Secondary Education gained in Canada three years or more</p>
</td>
<td>
<p>30</p>
</td>
</tr>
<tr>
<td>
<p>Arranged Employment / Job Offer from Canada in NOC Type 00</p>
</td>
<td>
<p>200</p>
</td>
</tr>
<tr>
<td>
<p>Arranged Employment / Job Offer from Canada in NOC Type 0, A or B</p>
</td>
<td>
<p>50</p>
</td>
</tr>
<tr>
<td>
<p>Canada PNP nomination</p>
</td>
<td>
<p>600</p>
</td>
</tr>
</tbody>
</table>
<p>&nbsp;</p>
<p><strong><u>How can Abhinav help you in Canada Express Entry &amp; CRS?</u></strong></p>
<p>With more than 27 years of pioneering Experience in the entire spectrum of Canada Immigration, Abhinav specializes in the Canada Express Entry process and documentation. We excel in <a href="canada-visa.php"><strong>Canada PR Visa</strong></a> counseling and guidance, profile assessment, NOC selection, documentation preparation, IELTS coaching, ECA support, EOI submission, CRS points improvement, ITA application submission, job offer, visa services, and settlement services.</p>
<p>&nbsp;</p>
<p></p>
<p><strong><u>FREQUENTLY ASKED QUESTIONS</u></strong></p>
<p>&nbsp;</p>
<ol>
<li>
<p><strong><u>How is CRS points different from the eligibility points?</u></strong></p>
<p>CRS points are dedicated to selecting a suitable candidate for <a href="canada-immigration.php"><strong>Canadian Immigration</strong></a> which considers factors such as Age, Experience, Education, language proficiency, spouse factors, arranged employment, and foreign or Canadian education and work experience. In contrast, the Canada Eligibility points system is a preliminary stage to become eligible for the Canada Express Entry program, which involves the factors such as age, Experience, Education, language proficiency &amp; adaptability.</p>
<p>&nbsp;</p>
</li>
<li>
<p><strong><u>What is the minimum IELTS required for Canada Express Entry and CRS?</u></strong></p>
<p>Under the Canada Express Entry, an applicant must score a minimum of CLB 7 which means the applicant must score a minimum of 6.0 bands in each component of Reading, Listening, Writing, and Speaking in IELTS General. However, the applicant must score more than CLB 7 to improve the chances of getting selected by authorities.</p>
<p>&nbsp;</p>
</li>
<li>
<p><strong><u>How to improve CRS Scores?</u></strong></p>
<p>There are several measures to improve CRS points under the express entry:</p>
</li></ol>
<ul>
<li>You can reappear for the IELTS examination and improve your IELTS score, which will reflect in CRS</li>
<li>Change primary applicant or acquire spousal points from qualification</li>
<li>Apply for Canada PNP and achieve PNP nomination, which will grant 600 additional CRS points</li>
<li>Gain Canadian Experience and Education which will reflect in CRS</li>
<li>Try to get a job offer from Canadian employers and earn 50 to 200 CRS points</li>
</ul>
<p>&nbsp;</p>
<ol>
<li>
<p><strong><u>What are the factors to consider in the Comprehensive Ranking System (CRS)?</u></strong></p>
<p>Applicants must demonstrate high points in Age, Experience (Foreign), Canadian Experience, Education (Foreign), Canadian Education, Language Proficiency (English or French), arranged employment, spousal qualification, spousal language proficiency, and certification of qualification. The higher the points scored in each factor, the higher is your chance of getting selected.</p>
</li>
</ol>
<p>&nbsp;</p>
</div>
         </div>
		 <div class="col-md-4 col-sm-4 col-xs-12">
		 <?php include('enquiry-form.php')?>
		 </div>
                
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>