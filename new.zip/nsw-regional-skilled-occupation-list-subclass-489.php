<?php include 'inc/header.php'; ?>

<div class="page-area">
  <div class="breadcumb-overlay"></div>
  <div class="container">
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="breadcrumb">
          <div class="bread-inner">
            <div class="section-headline white-headline">
              <h2>NSW Regional Skilled Occupation List -  <span class="color"> Subclass 489</span></h2>
            </div>
            <ul class="breadcrumb-bg">
              <li class="home-bread"><a href="index.php">Home</a></li>
              <li>NSW Regional Skilled Occupation List - Subclass 489</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="team-area bg-color pd-35">
  <div class="container">
    <!-- section head -->
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="section-headline text-center">
          <h3>NSW Regional Skilled Occupation List -  <span class="color"> Subclass 489</span></h3>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-8 col-sm-8 col-xs-12" style="box-shadow: 5px 3px 10px rgb(0 0 0 / 10%);">
        <div class='text-justify innerpage-text'>
          <p>Under the Provisional Skilled Regional NSW Sponsorship - Subclass 489, one can happily live and work up to 4 years in regional New South Wales, thus providing a pathway to permanent residency. To be eligible for <a href="../australia-visa.html" target="_blank">Australia PR</a>, the visa holder must either live for at least 2 years and work for at least a year in a specified region of NSW.<br />
            <br />
            The employment market of NSW works closely with the participating RDA (Regional Development Authorities) committees in NSW to execute the subclass-489 program. Under this scheme, the RDAs that choose to participate in the selection and nomination of candidates whose profile is in high demand from the NSW 489 Regional Skilled Occupation List.<br />
            <br />
            However, the participating RDAs have their own list of eligible occupations list. The NSW Regional Areas List Under Skilled Regional Nominated Migration 489, are:<br />
            &nbsp;</p>
          <ul>
            <li>Central West</li>
            <li>Far South Coast</li>
            <li>Mid North Coast</li>
            <li>Murray</li>
            <li>Northern Inland</li>
            <li>Northern Rivers (temporarily closed)</li>
            <li>Orana (temporarily closed)</li>
            <li>Riverina</li>
            <li>Southern Inland</li>
          </ul>
          <p><br />
            The below mentioned NSW 489 occupation list 2018 includes all those occupations which are eligible for Skilled Regional Provisional Visa. You can match your profile against the available job-list and must get in touch with right authorities in NSW to show your interest in applying for a visa. Those with better ranking and honed skillsets will have an absolute chance of being invited to work in the New South Wales region.<br />
            <br />
            <strong>Eligible occupations are marked with a tick. Please note: regional areas may have additional requirements for certain occupations. Please check the relevant regional website for more information.</strong><br />
            &nbsp;</p>
          <div class='clearfix'></div>
        </div>
      </div>
      <div class="col-md-4 col-sm-4 col-xs-12">
        <?php include('enquiry-form.php')?>
      </div>
    </div>
  </div>
</div>
</div>
</div>
<?php include 'inc/footer.php'; ?>
