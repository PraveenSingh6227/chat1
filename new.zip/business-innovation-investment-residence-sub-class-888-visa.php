<?php include 'inc/header.php'; ?>
<div class="page-area">
    <div class="breadcumb-overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="breadcrumb">
                    <div class="bread-inner">
                        <div class="section-headline white-headline">
                            <h2>Australia Business -  <span class="color">  Subclass 888 Visa</span></h2>
                        </div>
                        <ul class="breadcrumb-bg">
                            <li class="home-bread"><a href="index.php">Home</a></li>
                            <li>Australia Business - Subclass 888 Visa</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="team-area bg-color pd-35">
    <div class="container">
        <!-- section head -->
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-headline text-center">
                    <h3>Australia Business -  <span class="color">  Subclass 888 Visa</span></h3>
                </div>
            </div>
        </div>
        <div class="row">
		 <div class="col-md-8 col-sm-8 col-xs-12" style="box-shadow: 5px 3px 10px rgb(0 0 0 / 10%);">
<div class='text-justify innerpage-text'><p><strong>Business Innovation and Investment Residence subclass&nbsp;888 visa</strong>&nbsp;is a second stage visa of business innovation and investment program.<br />
<br />
<strong>Salient Features</strong></p>
<ul>
<li>This visa is granted on fulfilling preconditions of temporary visa under subclass 188</li>
<li>There are 2 categories in this visa
<ul>
<li>Business owners for those who own and run their visa in Australia</li>
<li>Investors who have sustained investment in the qualified venues and specified region of Australia and have strong intent to maintain their investment in the country after the maturity of original program goals</li>
</ul>
</li>
<li>You can
<ul>
<li>Own and run business or investment permanently in the country</li>
<li>Live and work permanently</li>
 <li>Include family members</li>
</ul>
</li>
</ul>
<p><br />
<strong>Pre-requisites Require for Subclass 888</strong></p>
<ul>
<li>Must be holder of temporary business innovation and investment visa</li>
<li>Have been sponsored by Aussie province or region</li>
<li>Have fulfilled all pre conditions of original temporary arrangement</li>
<li>Have fulfilled category specific requirements like
<ul>
<li>Business innovation
<ul>
<li>Created atleast 2 full time jobs for Aussie citizens or Permanent residents or NZ passport holders</li>
<li>Played an active role in management of main business (or 2 main stay) established for a minimum of 2 years preceding to application</li>
<li>Have complied with all statutory and regulatory requirements for each of establishments</li>
<li>In a year preceding to application achieved</li>
</ul>
</li>
</ul>
</li>
<li>A turnover of a minimum of AUD 300000</li>
<li>A net business asset value of AUD 200000 of main (or 2 mainstay) business and a net business and asset value of AUD 600000</li>
<li>Owned share of the establishments in specified ratio pattern
<ul>
<li>Investor.
<ul>
<li>Maintained qualified investment for a minimum of 4 years</li>
<li>Complied with all statutory and regulatory requirements in relation to your investment</li>
<li>Intend to continue with investment</li>
</ul>
</li>
</ul>
</li>
</ul>
</div>
</div>
		 <div class="col-md-4 col-sm-4 col-xs-12">
		 <?php include('enquiry-form.php')?>
		 </div>
                
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>