<?php include 'inc/header.php'; ?>

<div class="page-area">
  <div class="breadcumb-overlay"></div>
  <div class="container">
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="breadcrumb">
          <div class="bread-inner">
            <div class="section-headline white-headline">
              <h2>Victoria State Sponsorship  <span class="color"> Skilled Occupation List</span></h2>
            </div>
            <ul class="breadcrumb-bg">
              <li class="home-bread"><a href="index.php">Home</a></li>
              <li>Victoria State Sponsorship Skilled Occupation List</li>
            </ul>
          </div>
        </div>
      </div>
    </div>
  </div>
</div>
<div class="team-area bg-color pd-35">
  <div class="container">
    <!-- section head -->
    <div class="row">
      <div class="col-md-12 col-sm-12 col-xs-12">
        <div class="section-headline text-center">
          <h3>Victoria State Sponsorship  <span class="color"> Skilled Occupation List</span></h3>
        </div>
      </div>
    </div>
    <div class="row">
      <div class="col-md-8 col-sm-8 col-xs-12" style="box-shadow: 5px 3px 10px rgb(0 0 0 / 10%);">
        <div class='text-justify innerpage-text'>
          <h2>Occupations eligible to apply for Victorian state visa nomination</h2>
          <h2>Engineering and Building</h2>
          <table border="1" bordercolor="#CCCCCC" cellpadding="8" cellspacing="0" height="100%" width="90%">
            <thead>
              <tr bgcolor="#F00" style="color:#FFF">
                <th>ANZSCO code</th>
                <th>Occupation</th>
                <th>Minimum IELTS&nbsp;(or equivalent) requirement</th>
                <th>Minimum work experience</th>
                <th>Specialisations and other requirements</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>312112</td>
                <td>Building Associate</td>
                <td>7.0 in each band</td>
                <td>Two years</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>233211</td>
                <td>Civil Engineer</td>
                <td>7.0 in each band</td>
                <td>Two years</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>312211</td>
                <td>Civil Engineering Draftsperson</td>
                <td>7.0 in each band</td>
                <td>Two years</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>233311</td>
                <td>Electrical Engineer</td>
                <td>7.0 in each band</td>
                <td>Two years</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>312311</td>
                <td>Electrical Engineering Draftsperson</td>
                <td>7.0 in each band</td>
                <td>Two years</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>133211</td>
                <td>Engineering Manager</td>
                <td>7.0 in each band</td>
                <td>Two years</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>233512</td>
                <td>Mechanical Engineer</td>
                <td>7.0 in each band</td>
                <td>Two years</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>312511</td>
                <td>Mechanical Engineering Draftsperson</td>
                <td>7.0 in each band</td>
                <td>Two years</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>233611</td>
                <td>Mining Engineer (excluding Petroleum)</td>
                <td>7.0 in each band</td>
                <td>Two years</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>133513</td>
                <td>Production Manager (Mining)</td>
                <td>7.0 in each band</td>
                <td>Two years</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>233513</td>
                <td>Production or Plant Engineer</td>
                <td>7.0 in each band</td>
                <td>Two years</td>
                <td>&nbsp;</td>
              </tr>
            </tbody>
          </table>
          <h2>Biotechnology and Science</h2>
          <table border="1" bordercolor="#CCCCCC" cellpadding="8" cellspacing="0" height="100%" width="90%">
            <thead>
              <tr bgcolor="#F00" style="color:#FFF">
                <th>ANZSCO code</th>
                <th>Occupation</th>
                <th>Minimum IELTS&nbsp;(or equivalent)&nbsp;requirement</th>
                <th>Minimum work experience</th>
                <th>Specialisations and other requirements</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>132511</td>
                <td>Research and Development Manager</td>
                <td>7.0 in each band</td>
                <td>Two years</td>
                <td>Must have experience in the Science industry.<br />
                  <br />
                  Must have experience in the complete product life cycle.</td>
              </tr>
              <tr>
                <td>224112</td>
                <td>Mathematician</td>
                <td>6.0 in each band</td>
                <td>Two years</td>
                <td>Must have two year&rsquo;s experience in the Science industry.</td>
              </tr>
              <tr>
                <td>234111</td>
                <td>Agricultural Consultant</td>
                <td>6.0 in each band</td>
                <td>Two years</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>234112</td>
                <td>Agricultural Scientist</td>
                <td>6.0 in each band</td>
                <td>Two years</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>234211</td>
                <td>Chemist</td>
                <td>7.0 in each band</td>
                <td>Five years</td>
                <td>Higher education transcripts required.</td>
              </tr>
              <tr>
                <td>233914</td>
                <td>Engineering Technologist</td>
                <td>7.0 in each band</td>
                <td>Two years</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>234599</td>
                <td>Life Scientists nec</td>
                <td>6.0 in each band</td>
                <td>Five years</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>234999</td>
                <td>Natural and Physical Science Professionals nec</td>
                <td>6.0 in each band</td>
                <td>Five years</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>234914</td>
                <td>Physicist</td>
                <td>6.0 in each band</td>
                <td>Five years</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>224113</td>
                <td>Statistician</td>
                <td>6.0 in each band</td>
                <td>Two years</td>
                <td>Must have two year&rsquo;s experience in the Science industry.</td>
              </tr>
              <tr>
                <td>234711</td>
                <td>Veterinarian</td>
                <td>7.0 in each band</td>
                <td>Three years</td>
                <td>Must be registered with the Veterinary Practitioners Registration Board of Victoria.&nbsp;</td>
              </tr>
            </tbody>
          </table>
          <h2>Human Resources Management</h2>
          <table border="1" bordercolor="#CCCCCC" cellpadding="8" cellspacing="0" height="100%" width="90%">
            <thead>
              <tr bgcolor="#F00" style="color:#FFF">
                <th>ANZSCO code</th>
                <th>Occupation</th>
                <th>Minimum IELTS&nbsp;(or equivalent) requirement</th>
                <th>Minimum work experience</th>
                <th>Specialisations and other requirements</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>132311</td>
                <td>Human Resource Manager</td>
                <td>6.0 in each band</td>
                <td>Five years</td>
                <td>&nbsp;</td>
              </tr>
            </tbody>
          </table>
          <h2>Tourism and Hospitality</h2>
          <table border="1" bordercolor="#CCCCCC" cellpadding="8" cellspacing="0" height="100%" width="90%">
            <thead>
              <tr bgcolor="#F00" style="color:#FFF">
                <th>ANZSCO code</th>
                <th>Occupation</th>
                <th>Minimum IELTS&nbsp;(or equivalent)&nbsp;requirement</th>
                <th>Minimum work experience</th>
                <th>Specialisations and other requirements</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>351311</td>
                <td>Chef</td>
                <td>6.0 in each band</td>
                <td>Five years</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>141311</td>
                <td>Hotel or Motel Manager</td>
                <td>6.0 in each band</td>
                <td>Five years</td>
                <td>Must have experience in a large, international firm and managerial experience.</td>
              </tr>
              <tr>
                <td colspan="6">See the Trades section for information on Hospitality Trades.&nbsp;</td>
              </tr>
            </tbody>
          </table>
          <h2>Health</h2>
          <table border="1" bordercolor="#CCCCCC" cellpadding="8" cellspacing="0" height="100%" width="90%">
            <thead>
              <tr bgcolor="#F00" style="color:#FFF">
                <th>ANZSCO code</th>
                <th>Occupation</th>
                <th>Minimum IELTS&nbsp;(or equivalent)&nbsp;requirement&nbsp;</th>
                <th>Minimum work experience</th>
                <th>Specialisations and other requirements</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>224213&nbsp;</td>
                <td>Health Information Manager&nbsp;</td>
                <td>7.0 in each band&nbsp;</td>
                <td>Two years&nbsp;</td>
                <td>Must have a qualification accredited by the Health Information Management Association of Australia.<br />
                  <br />
                  Higher education transcripts and certificates required. &nbsp;</td>
              </tr>
              <tr>
                <td>254111</td>
                <td>Midwife</td>
                <td>7.0 in each band</td>
                <td>Two years</td>
                <td>Must have registration (or approval in principle) from the Nursing and Midwifery Board of Australia.</td>
              </tr>
              <tr>
                <td>254411</td>
                <td>Nurse Practitioner</td>
                <td>7.0 in each band</td>
                <td>Two years</td>
                <td>Must have registration (or approval in principle) from the Nursing and Midwifery Board of Australia.</td>
              </tr>
              <tr>
                <td>254412</td>
                <td>Registered Nurse (Aged Care)</td>
                <td>7.0 in each band</td>
                <td>Two years</td>
                <td>Must have registration (or approval in principle) from the Nursing and Midwifery Board of Australia.</td>
              </tr>
              <tr>
                <td>254413</td>
                <td>Registered Nurse (Child and Family Health)</td>
                <td>7.0 in each band</td>
                <td>Two years</td>
                <td>Must have registration (or approval in principle) from the Nursing and Midwifery Board of Australia.<br />
                  <br />
                  Must be registered as both a nurse and a midwife.</td>
              </tr>
              <tr>
                <td>254414</td>
                <td>Registered Nurse (Community Health)</td>
                <td>7.0 in each band</td>
                <td>Two years</td>
                <td>Must have registration (or approval in principle) from the Nursing and Midwifery Board of Australia.</td>
              </tr>
              <tr>
                <td>254415</td>
                <td>Registered Nurse (Critical Care and Emergency)</td>
                <td>7.0 in each band</td>
                <td>Two years</td>
                <td>Must have registration (or approval in principle) from the Nursing and Midwifery Board of Australia.</td>
              </tr>
              <tr>
                <td>254416</td>
                <td>Registered Nurse (Developmental Disability)</td>
                <td>7.0 in each band</td>
                <td>Two years</td>
                <td>Must have registration (or approval in principle) from the Nursing and Midwifery Board of Australia.</td>
              </tr>
              <tr>
                <td>254417</td>
                <td>Registered Nurse (Disability and Rehabilitation)</td>
                <td>7.0 in each band</td>
                <td>Two years</td>
                <td>Must have registration (or approval in principle) from the Nursing and Midwifery Board of Australia.</td>
              </tr>
              <tr>
                <td>254418</td>
                <td>Registered Nurse (Medical)</td>
                <td>7.0 in each band</td>
                <td>Two years</td>
                <td>Must have registration (or approval in principle) from the Nursing and Midwifery Board of Australia.</td>
              </tr>
              <tr>
                <td>254421</td>
                <td>Registered Nurse (Medical Practice)</td>
                <td>7.0 in each band</td>
                <td>Two years</td>
                <td>Must have registration (or approval in principle) from the Nursing and Midwifery Board of Australia.</td>
              </tr>
              <tr>
                <td>254422</td>
                <td>Registered Nurse (Mental Health)</td>
                <td>7.0 in each band</td>
                <td>Two years</td>
                <td>Must have registration (or approval in principle) from the Nursing and Midwifery Board of Australia.</td>
              </tr>
              <tr>
                <td>254423</td>
                <td>Registered Nurse (Perioperative)</td>
                <td>7.0 in each band</td>
                <td>Two years</td>
                <td>Must have registration (or approval in principle) from the Nursing and Midwifery Board of Australia.</td>
              </tr>
              <tr>
                <td>254424</td>
                <td>Registered Nurse (Surgical)</td>
                <td>7.0 in each band</td>
                <td>Two years</td>
                <td>Must have registration (or approval in principle) from the Nursing and Midwifery Board of Australia.</td>
              </tr>
              <tr>
                <td>254499</td>
                <td>Registered Nurses nec</td>
                <td>7.0 in each band</td>
                <td>Two years</td>
                <td>Must have registration (or approval in principle) from the Nursing and Midwifery Board of Australia.</td>
              </tr>
              <tr>
                <td>272311</td>
                <td>Clinical Psychologist</td>
                <td>7.0 in each band&nbsp;(Academic IELTS only)</td>
                <td>Two years</td>
                <td>Must have general registration with the Psychology Board of Australia.</td>
              </tr>
              <tr>
                <td>251111</td>
                <td>Dietitian</td>
                <td>6.0 in each band</td>
                <td>Two years</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>252411</td>
                <td>Occupational Therapist</td>
                <td>7.0 in each band</td>
                <td>Ten years</td>
                <td>Must have experience in mental health care.&nbsp;</td>
              </tr>
              <tr>
                <td>252511</td>
                <td>Physiotherapist</td>
                <td>7.0 in each band</td>
                <td>Two years</td>
                <td>Must have registration (or approval in principle) from the Physiotherapy Board of Australia.</td>
              </tr>
              <tr>
                <td>252611</td>
                <td>Podiatrist</td>
                <td>7.0 in each band</td>
                <td>Two years</td>
                <td>Must have registration (or approval in principle) from the Podiatry Board of Australia.</td>
              </tr>
              <tr>
                <td>272511</td>
                <td>Social Worker</td>
                <td>7.0 in each band</td>
                <td>Two years</td>
                <td>Preferred specialisations:
                  <ul style="padding-left:15px">
                    <li>Mental Health Workers</li>
                    <li>Skilled Children and Family Workers</li>
                    <li>Child Protection (must have a minimum of two years statutory child protection practice and Australian Association of Social Workers accreditation).</li>
                  </ul></td>
              </tr>
              <tr>
                <td>251214</td>
                <td>Sonographer</td>
                <td>7.0 in each band</td>
                <td>Two years</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>252712</td>
                <td>Speech Pathologist</td>
                <td>6.0 in each band</td>
                <td>Two years</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>234914&nbsp;</td>
                <td>Physicist (Medical only)&nbsp;</td>
                <td>7.0 in each band&nbsp;</td>
                <td>Two years&nbsp;</td>
                <td>Must have experience in diagnostic imaging or radiation oncology.</td>
              </tr>
              <tr>
                <td>251213 &nbsp;</td>
                <td>Nuclear Medicine Technologist</td>
                <td>7.0 in each band&nbsp;</td>
                <td>Two years&nbsp;</td>
                <td>Must have registration (or approval in principle) from the&nbsp;Medical Radiation Practice Board of Australia.&nbsp;</td>
              </tr>
            </tbody>
          </table>
          <h2>Education</h2>
          <table border="1" bordercolor="#CCCCCC" cellpadding="8" cellspacing="0" height="100%" width="90%">
            <thead>
              <tr bgcolor="#F00" style="color:#FFF">
                <th>ANZSCO code</th>
                <th>Occupation</th>
                <th>Minimum IELTS&nbsp;(or equivalent)&nbsp;requirement</th>
                <th>Minimum work experience</th>
                <th>Specialisations and other requirements</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>241111</td>
                <td>Early Childhood (Pre-primary School) Teacher</td>
                <td>Overall: 7.5<br />
                  Speaking: 8.0<br />
                  Listening: 8.0<br />
                  Reading: 7.0<br />
                  Writing: 7.0</td>
                <td>Two years</td>
                <td>Must have ACECQA certification.</td>
              </tr>
              <tr>
                <td id="_td2_0" style="style:">134111&nbsp;</td>
                <td>Child Care Centre Manager&nbsp;</td>
                <td>Overall: 7.5<br />
                  Speaking: 8.0<br />
                  Listening: 8.0<br />
                  Reading: 7.0<br />
                  Writing: 7.0</td>
                <td>&nbsp;Two years</td>
                <td>Must have ACECQA certification (note that certification focuses on education qualifications not management qualifications).</td>
              </tr>
              <tr>
                <td>241213&nbsp;</td>
                <td>Primary School Teacher&nbsp;</td>
                <td>Overall: 7.5<br />
                  Speaking: 8.0<br />
                  Listening: 8.0<br />
                  Reading: 7.0<br />
                  Writing: 7.0&nbsp;</td>
                <td>&nbsp;Two years</td>
                <td>Must be registered with the Victorian Institute of Teaching.<br />
                  <br />
                  Must have experience teaching at least one of the following languages:
                  <ul style="padding-left:15px">
                    <li><span style="BACKGROUND-COLOR: transparent">Chinese</span></li>
                    <li><span style="BACKGROUND-COLOR: transparent">Indonesian</span></li>
                    <li><span style="BACKGROUND-COLOR: transparent">Japanese</span></li>
                    <li><span style="BACKGROUND-COLOR: transparent">Korean</span></li>
                    <li><span style="BACKGROUND-COLOR: transparent">French</span></li>
                    <li><span style="BACKGROUND-COLOR: transparent">German</span></li>
                    <li><span style="BACKGROUND-COLOR: transparent">Italian</span></li>
                    <li><span style="BACKGROUND-COLOR: transparent">Greek</span></li>
                    <li><span style="BACKGROUND-COLOR: transparent">Spanish</span></li>
                    <li><span style="BACKGROUND-COLOR: transparent">Turkish</span></li>
                    <li><span style="BACKGROUND-COLOR: transparent">Arabic</span></li>
                    <li><span style="BACKGROUND-COLOR: transparent">Vietnamese.</span></li>
                  </ul></td>
              </tr>
              <tr>
                <td>241411&nbsp;</td>
                <td>Secondary School Teacher&nbsp;</td>
                <td>Overall: 7.5<br />
                  Speaking: 8.0<br />
                  Listening: 8.0<br />
                  Reading: 7.0<br />
                  Writing: 7.0&nbsp;</td>
                <td>&nbsp;Two years</td>
                <td>Must be registered with the Victorian Institute of Teaching.<br />
                  <br />
                  Must specialise in at least one of the following fields:&nbsp;
                  <ul style="padding-left:15px">
                    <li><span style="BACKGROUND-COLOR: transparent">Mathematics or Physics</span></li>
                    <li><span style="BACKGROUND-COLOR: transparent">Technology (Food, Metal, Wood or Auto)&nbsp;</span></li>
                    <li><span style="BACKGROUND-COLOR: transparent">Languages &nbsp;</span></li>
                    <li><span style="BACKGROUND-COLOR: transparent">General science&nbsp;</span></li>
                    <li><span style="BACKGROUND-COLOR: transparent">Special education&nbsp;</span></li>
                    <li><span style="BACKGROUND-COLOR: transparent">Information technology.</span><span style="BACKGROUND-COLOR: transparent">&nbsp;</span></li>
                  </ul></td>
              </tr>
              <tr>
                <td>242211&nbsp;</td>
                <td>Vocational Education Teacher&nbsp;</td>
                <td>7.0 overall, with at least 6.5 in each band.</td>
                <td>Two years (in vocational teaching)</td>
                <td>Must have a teaching qualification and a vocational qualification.<br />
                  <br />
                  Must specialise in at least one of the following fields:&nbsp;
                  <ul style="padding-left:15px">
                    <li><span style="BACKGROUND-COLOR: transparent">Horticulture&nbsp;</span></li>
                    <li><span style="BACKGROUND-COLOR: transparent">Arboriculture&nbsp;</span></li>
                    <li><span style="BACKGROUND-COLOR: transparent">Building and design&nbsp;</span></li>
                    <li><span style="BACKGROUND-COLOR: transparent">Dogger and Rigger (Crane Licenses)</span></li>
                    <li><span style="BACKGROUND-COLOR: transparent">Electrical Instrumentation&nbsp;</span></li>
                    <li><span style="BACKGROUND-COLOR: transparent">Electrical Supply Industry Transmission, Distribution and Cable Jointing</span></li>
                    <li><span style="BACKGROUND-COLOR: transparent">Gas Distribution&nbsp;</span></li>
                    <li><span style="BACKGROUND-COLOR: transparent">Aged Care.</span></li>
                  </ul></td>
              </tr>
              <tr>
                <td>272412&nbsp;</td>
                <td>Interpreter&nbsp;</td>
                <td>6.0 in each band&nbsp;</td>
                <td>Two years&nbsp;</td>
                <td>Must have NAATI &ldquo;professional&rdquo; accreditation.</td>
              </tr>
            </tbody>
          </table>
          <h2>Trades</h2>
          <table border="1" bordercolor="#CCCCCC" cellpadding="8" cellspacing="0" height="100%" width="90%">
            <thead>
              <tr bgcolor="#F00" style="color:#FFF">
                <th>ANZSCO code</th>
                <th>Occupation</th>
                <th>Minimum IELTS&nbsp;(or equivalent)<span style="background-color: transparent;">&nbsp;requirement</span></th>
                <th>Minimum work experience</th>
                <th>Specialisations and other requirements</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td colspan="5">Construction Trades&nbsp;</td>
              </tr>
              <tr>
                <td>334112&nbsp;</td>
                <td>Airconditioning and Mechanical Services Plumber&nbsp;</td>
                <td>&nbsp;6.0 in each band</td>
                <td>Five years&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>394111&nbsp;</td>
                <td>Cabinetmaker&nbsp;</td>
                <td>&nbsp;6.0 in each band</td>
                <td>Five years&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>334113&nbsp;</td>
                <td>Drainer&nbsp;</td>
                <td>&nbsp;6.0 in each band</td>
                <td>Five years&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>334114&nbsp;</td>
                <td>Gasfitter&nbsp;</td>
                <td>&nbsp;6.0 in each band</td>
                <td>Five years&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>334115&nbsp;</td>
                <td>Roof Plumber&nbsp;</td>
                <td>&nbsp;6.0 in each band</td>
                <td>Five years&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td colspan="5">Engineering Trades&nbsp;</td>
              </tr>
              <tr>
                <td>322311&nbsp;</td>
                <td>Metal Fabricator&nbsp;</td>
                <td>&nbsp;6.0 in each band</td>
                <td>Five years&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>322211&nbsp;</td>
                <td>Sheetmetal Trades Worker&nbsp;</td>
                <td>&nbsp;6.0 in each band</td>
                <td>Five years&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>322313&nbsp;</td>
                <td>Welder (First Class)&nbsp;</td>
                <td>&nbsp;6.0 in each band</td>
                <td>Five years&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>323214&nbsp;</td>
                <td>Metal Machinist (First Class)&nbsp;</td>
                <td>&nbsp;6.0 in each band</td>
                <td>Five years&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td colspan="5">Electrical/Electronic/Communications Trades&nbsp;</td>
              </tr>
              <tr>
                <td>342111&nbsp;</td>
                <td>Airconditioning and Refrigeration Mechanic</td>
                <td>&nbsp;6.0 in each band</td>
                <td>Five years&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>342211&nbsp;</td>
                <td>Electrical Linesworker&nbsp;</td>
                <td>&nbsp;6.0 in each band</td>
                <td>Five years&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>342313&nbsp;</td>
                <td>Electronic Equipment Trades Worker&nbsp;</td>
                <td>&nbsp;6.0 in each band</td>
                <td>Five years&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>342413&nbsp;</td>
                <td>Telecommunications Linesworker&nbsp;</td>
                <td>&nbsp;6.0 in each band</td>
                <td>Five years&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>342414&nbsp;</td>
                <td>Telecommunications Technician&nbsp;</td>
                <td>&nbsp;6.0 in each band</td>
                <td>Five years&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td colspan="5">Hospitality Trades&nbsp;</td>
              </tr>
              <tr>
                <td>351111&nbsp;</td>
                <td>Baker&nbsp;</td>
                <td>&nbsp;6.0 in each band</td>
                <td>Five years&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>351411&nbsp;</td>
                <td>Cook&nbsp;</td>
                <td>&nbsp;6.0 in each band</td>
                <td>Five years&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
              <tr>
                <td>351112&nbsp;</td>
                <td>Pastrycook&nbsp;</td>
                <td>&nbsp;6.0 in each band</td>
                <td>Five years&nbsp;</td>
                <td>&nbsp;</td>
              </tr>
            </tbody>
          </table>
          <p>&nbsp;</p>
        </div>
      </div>
      <div class="col-md-4 col-sm-4 col-xs-12">
        <?php include('enquiry-form.php')?>
      </div>
    </div>
  </div>
</div>
</div>
</div>
<?php include 'inc/footer.php'; ?>
