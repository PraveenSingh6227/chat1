<?php include 'inc/header.php'; ?>
<div class="vision-bg-area">
    <div class="breadcumb-overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="breadcrumb">
                    <div class="bread-inner">
                        <div class="section-headline white-headline">
                            <h2>VISION <span class="color">AND MISSION</span></h2>
                        </div>
                        <ul class="breadcrumb-bg">
                            <li class="home-bread"><a href="index.php">Home</a></li>
                            <li class="home-bread"><a href="about.php">About us</a></li>
                            <li>Vision, Mission and Values</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="team-area vision-area bg-color pd-35">
    <div class="container">
        <!-- section head -->
        <div class="row pd-35">
            <div class="col-md-4 col-sm-4 col-xs-12">
                <div class="vison-bg" style="background-image: url('img/about/vision.jpg');"></div>
            </div>
            <div class="col-md-8 col-sm-8 col-xs-12">
                <div class="section-headline">
                    <h3><span class="color">Our</span> Vision</h3>                    
                </div>
                <p>Excel in what we do and build a safe and secure environment for our community.</p>
                <p>We believe we have the opportunity – and the responsibility – to be a force for good in the world.</p>
                <p>And – just as importantly – we believe that doing good makes us a better business.</p>
                <p>The best way – and the only way – to do business. We’re convinced that the businesses that thrive in the future will be those that serve society today.</p>
            </div>
        </div>
        <div class="row inverse pd-35">           
            <div class="col-md-8 col-sm-8 col-xs-12 text-right">
                <div class="section-headline">
                    <h3><span class="color">Our</span> Mission</h3>                   
                </div>
                <p>“Our mission is to achieve sustainable environmental ­improvements in fluid handling systems.”</p><p>
                We ensure maximum safety and the ultimate in quality with the energy efficient products and services we offer.</p><p>
                Satisfied customers are always at the heart of what we think and do.</p><p>
                Dedicated, well-trained professionals, flat hierarchies and short lines of decision-making keep us agile. We focus on
                customer responsiveness and delivering efficient and excellent service.</p>
            </div>
             <div class="col-md-4 col-sm-4 col-xs-12">
                <div class="vison-bg" style="background-image: url('img/about/mission.png');"></div>
            </div>
        </div>
        <div class="row pd-35">
            <div class="col-md-4 col-sm-4 col-xs-12">
                <div class="vison-bg" style="background-image: url('img/about/values.jpg');"></div>
            </div>
            <div class="col-md-8 col-sm-8 col-xs-12">
                <div class="section-headline">
                    <h3><span class="color">Our</span> Values</h3>                    
                </div>
                <p><strong>Sustainable</strong>
                “We strongly believe that preserving our environment is a constant source of true value creation.”</p><p><strong>Proactive</strong> “We act upon our profound convictions because we share the concerns about the current state of our planet.”</p><p><strong>Responsible</strong>
                “We are convinced that honesty, trustworthiness and ethically sound behaviour help to build long-lasting relationships.”</p><p><strong>Ecological</strong>
                “We understand that acting in an environmentally friendly way is essential to continuously serve our customers.”</p>
            </div>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>