<?php include 'inc/header.php'; ?>
<div class="page-area">
    
    <div class="breadcumb-overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="breadcrumb">
                    <div class="bread-inner">
                        <div class="section-headline white-headline">
                            <h2>Refund <span class="color">Policy</span></h2>
                        </div>
                        <ul class="breadcrumb-bg">
                             <li class="home-bread"><a href="index.php">Home</a></li>
                            <li>Refund Policy</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="team-area bg-color pd-35">
    <div class="container">
        <!-- section head -->
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="section-headline text-center">
                    <h3><span class="color"> Refund Policy</span></h3>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="team-member">
                <p>
                    
                    
                    
                    
                    An Advisor-Client or consultant-client association is and will continue to be subject to a completely new contract of engagement (COE) decided and inked between both the parties, namely, PRIME IMMIGRATION  LLP ; client. The terms & condition and refund policy of this type of an agreed and linked contract of engagement /agreement, for using the services of the immigration consultancy and its capacity as an advisor, is fully autonomous of the terms & condition.
                </p>
                    
                    
                    
   



</div>


            </div>
        </div>
    </div>
</div>



<div class="services-area bg-color area-padding">
            <div class="container">
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="section-headline text-center">
                            <h3>What We <span class="color">Offer You</span></h3>
                            <p>What we are offering to customers</p>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="services-all">
                        <!-- Start services -->
                        <div class="col-md-4 col-sm-6 col-xs-12">
                           <div class="single-services">
                                <div class="service-inner">
                                    <a class="service-icon" href="#">
                                        <i class="flaticon-presentation-17"></i>
                                    </a>
                                    <div class="service-content">
                                        <h4><a href="#">Job Assistance</a></h4>
                                        <p>The world today has become a small place. Everyone has a lot of opportunities to work in different countries during their lifetime. <br><br><br></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="single-services">
                                <div class="service-inner">
                                    <a class="service-icon" href="#">
                                        <i class="flaticon-notes"></i>
                                    </a>
                                    <div class="service-content">
                                        <h4><a href="#">Business Visa</a></h4>
                                        <p>The world has now become a small place. Global trade is now a reality in every corner of the world. You witness and buy products everyday which are manufactured and traded by people of different nationalities.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Start services -->
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="single-services">
                                <div class="service-inner">
                                    <a class="service-icon" href="#">
                                        <i class="flaticon-graph-3"></i>
                                       </a>
                                    <div class="service-content">
                                        <h4><a href="#">Student Visa</a></h4>
                                        <p>Studying abroad is one decision in a student’s life that can change their life forever. Millions of students go to different countries every year to study for different courses.<br><br></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Start services -->
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="single-services">
                                <div class="service-inner">
                                    <a class="service-icon" href="#">
                                       <i class="flaticon-graph"></i>
                                    </a>
                                    <div class="service-content">
                                        <h4><a href="#">Tourist Visa Service</a></h4>
                                        <p>We proudly present ourselves as tourist visa expert Consultants. Over the past few years of dealing with tourist visa cases for more than 20 countries, we have perfected the art of making and filing a winning visa application.</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Start services -->
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="single-services">
                                <div class="service-inner">
                                    <a class="service-icon" href="#">
                                       <i class="flaticon-barcode-1"></i>
                                    </a>
                                    <div class="service-content">
                                        <h4><a href="#">Canada PR</a></h4>
                                        <p>If you have been planning to migrate to Canada and it has been one of your dreams from some time, you have come to the right place. <br><br><br></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <!-- Start services -->
                        <div class="col-md-4 col-sm-6 col-xs-12">
                            <div class="single-services">
                                <div class="service-inner">
                                    <a class="service-icon" href="#">
                                       <i class="flaticon-pie-chart-1"></i>
                                    </a>
                                    <div class="service-content">
                                        <h4><a href="#">Counselling Service</a></h4>
                                        <p>Whenever you plan to study or migrate abroad, it is the biggest decision of your life. We must take all measures possible to make sure that we make the right decision for our future.<br><br></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                        
                    </div>
                </div>
            </div>
        </div>
                <!-- Single team member -->
                
                </div>
            </div>
        </div>
    </div>
</div>
<?php include 'inc/footer.php'; ?>