<?php include 'inc/header.php'; ?>
<div class="contact-us-area">
    <div class="breadcumb-overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="breadcrumb">
                    <div class="bread-inner">
                        <div class="section-headline white-headline">
                            <h2>Pay  <span class="color">Now</span></h2>
                        </div>
                        <ul class="breadcrumb-bg">
                            <li class="home-bread"><a href="index.php">Home</a></li>
                            <li>Pay Now</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<div class="contact-page area-padding">
    <div class="container">
        <div class="row">
            <div class="col-md-7 col-sm-7 col-xs-12">
                <div class="contact-head">
                    
                    <h3>Account Holder <span class="color">Details</span></h3>

                    <img src="img/logo/bank.png" alt="">
                    <br><br>
                    <p><b>Current Account Name :</b> Prime immigration llp <br>
<b>Registered Mobile Number :</b> 8368539783 </p>
                    <div class="contact-icon">

                       
<p><b>Account Name :</b> Prime immigration llp<br>
<b>Account Number :</b> 258368539782<br>
<b>Account Type :</b> Current Account<br>
<b>IFSC Code :</b> INDB0000036<br>
<b>MICR Code :</b> 110234006<br></p>

<p><b>UPI (Holder Name)/ Application :</b> Prime immigration LLP <br>
<b>UPI and Application Phone Number :</b> 8368539783
(Google pay,Phone pay,Paytm)<br></p>

                       
                    </div>
                </div>
            </div>
            <!-- End contact icon -->
            <div class="col-md-5 col-sm-5 col-xs-12">
                <div class="contact-form">
                   
                   <img src="img/logo/scan.jpg" alt="">
                </div>
            </div>
            <!-- End contact Form -->
        </div>
    </div>
</div>
<!-- Start contact Area -->

</div>
<!-- Start Footer bottom Area -->
<?php include 'inc/footer.php'; ?>
