<?php include 'inc/header.php'; ?>
<div class="page-area">
    <div class="breadcumb-overlay"></div>
    <div class="container">
        <div class="row">
            <div class="col-md-12 col-sm-12 col-xs-12">
                <div class="breadcrumb">
                    <div class="bread-inner">
                        <div class="section-headline white-headline">
                            <h2>Our <span class="color">Services</span></h2>
                        </div>
                        <ul class="breadcrumb-bg">
                            <li class="home-bread"><a href="index.php">Home</a></li>
                            <li>Our Services</li>
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Start Service area -->
<div class="services-area bg-color area-padding">
	<div class="container">
		<div class="row">
			<div class="col-md-12 col-sm-12 col-xs-12">
				<div class="section-headline text-center">
					<h3>Our <span class="color">Services</span></h3>
				    <p>We are proud to offer the highest standards of workmanship and servicing. Our own fully qualified and trained technicians maintain the heat pumps and ducted systems that we install.</p>
				</div>
			</div>
		</div>
        <div class="row">
            <div class="services-all">
            	<!-- Start services -->
				<div class="col-md-4 col-sm-6 col-xs-12">
				   <div class="single-services">
						<div class="service-inner">
						    <a class="service-icon" href="#">
                                <i class="flaticon-presentation-17"></i>
                            </a>
                            <div class="service-content">
                                <h4><a href="#">The Heat Pump Specialists</a></h4>
                                <p>Whilst Prime Immigration LLP’s offer a wide range of great products and services, we are still the specialists in heat pumps. Our advice, products, installation and support for your new system is second to none.</p>
                            </div>
						</div>
					</div>
				</div>
			    <div class="col-md-4 col-sm-6 col-xs-12">
					<div class="single-services">
					    <div class="service-inner">
                            <a class="service-icon" href="#">
                                <i class="flaticon-notes"></i>
                            </a>
                            <div class="service-content">
                                <h4><a href="#">Expert Advice and Detailed Quotes</a></h4>
                                <p>With over 15 years’ experience in the industry we understand what is required to find the best solution for your home or business, whatever the size. To ensure energy efficiency and comfort we tailor a solution for your space, and provide you with a detailed quote, explained in straightforward terms</p>
                            </div>
						</div>
					</div>
				</div>
				<!-- Start services -->
				<div class="col-md-4 col-sm-6 col-xs-12">
					<div class="single-services">
                        <div class="service-inner">
                            <a class="service-icon" href="#">
                                <i class="flaticon-graph-3"></i>
                               </a>
                            <div class="service-content">
                                <h4><a href="#">Full Service and Maintenance</a></h4>
                                <p>All Prime Immigration LLP’s products have a strong reputation for quality and reliability, meaning that we are able to provide full service and maintenance on all of the systems that we install. You can rest assured that in the unlikely event of a breakdown we’ll be there to help. Our technicians are fully qualified and expertly trained, offering you the highest standards of workmanship and servicing.</p>
                            </div>
						</div>
					</div>
				</div>
				<!-- Start services -->
				<div class="col-md-4 col-sm-6 col-xs-12">
					<div class="single-services">
					    <div class="service-inner">
                            <a class="service-icon" href="#">
                               <i class="flaticon-graph"></i>
                            </a>
                            <div class="service-content">
                                <h4><a href="#">Trustworthy and Reliable</a></h4>
                                <p>We have an excellent reputation in the industry and recognize the importance of customer satisfaction. We are committed to providing honest, trustworthy and reliable support for your new system.</p>
                            </div>
						</div>
					</div>
				</div>
				<!-- Start services -->
				<div class="col-md-4 col-sm-6 col-xs-12">
					<div class="single-services">
					    <div class="service-inner">
                            <a class="service-icon" href="#">
                               <i class="flaticon-barcode-1"></i>
                            </a>
                            <div class="service-content">
                                <h4><a href="#">Fast, Efficient and Friendly Customer Service</a></h4>
                                <p>We pride ourselves on our fast, efficient and friendly service. We work hard to ensure that your system is installed with as little disruption to your home or business as possible.</p>
                            </div>
						</div>
					</div>
				</div>
				<!-- Start services -->
				<div class="col-md-4 col-sm-6 col-xs-12">
					<div class="single-services">
					    <div class="service-inner">
                            <a class="service-icon" href="#">
                               <i class="flaticon-pie-chart-1"></i>
                            </a>
                            <div class="service-content">
                                <h4><a href="#">Only Quality Brands</a></h4>
                                <p>Prime Immigration LLP’s only sell leading well recognized brands that our customers can trust. We have access to a comprehensive product range and technical resources from our suppliers, ensuring that you get the best solution for your budget.</p>
                            </div>
						</div>
					</div>
				</div>
            </div>
		</div>
	</div>
</div>
<!-- End Service area -->
<?php include 'inc/footer.php'; ?>